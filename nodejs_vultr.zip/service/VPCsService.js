'use strict';


/**
 * Create a VPC
 * Create a new VPC in a `region`. VPCs should use [RFC1918 private address space](https://tools.ietf.org/html/rfc1918):      10.0.0.0    - 10.255.255.255  (10/8 prefix)     172.16.0.0  - 172.31.255.255  (172.16/12 prefix)     192.168.0.0 - 192.168.255.255 (192.168/16 prefix) 
 *
 * body Vpcs_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * returns inline_response_200_2
 **/
exports.createVpc = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "vpc" : {
    "date_created" : "date_created",
    "v4_subnet_mask" : 0,
    "description" : "description",
    "v4_subnet" : "v4_subnet",
    "id" : "id",
    "region" : "region"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Delete a VPC
 * Delete a VPC.
 *
 * vpcId String The [VPC ID](#operation/list-vpcs).
 * no response value expected for this operation
 **/
exports.deleteVpc = function(vpcId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Get a VPC
 * Get information about a VPC.
 *
 * vpcId String The [VPC ID](#operation/list-vpcs).
 * returns inline_response_200_2
 **/
exports.getVpc = function(vpcId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "vpc" : {
    "date_created" : "date_created",
    "v4_subnet_mask" : 0,
    "description" : "description",
    "v4_subnet" : "v4_subnet",
    "id" : "id",
    "region" : "region"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * List VPCs
 * Get a list of all VPCs in your account.
 *
 * per_page Integer Number of items requested per page. Default is 100 and Max is 500. (optional)
 * cursor String Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination). (optional)
 * returns inline_response_200_3
 **/
exports.listVpcs = function(per_page,cursor) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "meta" : {
    "total" : 0,
    "links" : {
      "next" : "next",
      "prev" : "prev"
    }
  },
  "vpcs" : [ {
    "date_created" : "date_created",
    "v4_subnet_mask" : 0,
    "description" : "description",
    "v4_subnet" : "v4_subnet",
    "id" : "id",
    "region" : "region"
  }, {
    "date_created" : "date_created",
    "v4_subnet_mask" : 0,
    "description" : "description",
    "v4_subnet" : "v4_subnet",
    "id" : "id",
    "region" : "region"
  } ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Update a VPC
 * Update information for a VPC.
 *
 * body Vpcs_vpcid_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * vpcId String The [VPC ID](#operation/list-vpcs).
 * no response value expected for this operation
 **/
exports.updateVpc = function(body,vpcId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

