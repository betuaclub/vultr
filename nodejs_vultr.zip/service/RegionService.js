'use strict';


/**
 * List available plans in region
 * Get a list of the available plans in Region `region-id`. Not all plans are available in all regions.
 *
 * regionId String The [Region id](#operation/list-regions).
 * type String Filter the results by type.  | **Type** | **Description** | |----------|-----------------| | all | All available types | | vc2 | Cloud Compute | | vdc | Dedicated Cloud | | vhf | High Frequency Compute | | vhp | High Performance | | voc | All Optimized Cloud types | | voc-g | General Purpose Optimized Cloud | | voc-c | CPU Optimized Cloud | | voc-m | Memory Optimized Cloud | | voc-s | Storage Optimized Cloud | | vbm | Bare Metal | | vcg | Cloud GPU |  (optional)
 * returns inline_response_200_30
 **/
exports.listAvailablePlansRegion = function(regionId,type) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "available_plans" : [ "available_plans", "available_plans" ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * List Regions
 * List all Regions at Vultr.
 *
 * per_page Integer Number of items requested per page. Default is 100 and Max is 500. (optional)
 * cursor String Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination). (optional)
 * returns inline_response_200_29
 **/
exports.listRegions = function(per_page,cursor) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "regions" : [ {
    "continent" : "continent",
    "country" : "country",
    "city" : "city",
    "options" : [ "options", "options" ],
    "id" : "id"
  }, {
    "continent" : "continent",
    "country" : "country",
    "city" : "city",
    "options" : [ "options", "options" ],
    "id" : "id"
  } ],
  "meta" : {
    "total" : 0,
    "links" : {
      "next" : "next",
      "prev" : "prev"
    }
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

