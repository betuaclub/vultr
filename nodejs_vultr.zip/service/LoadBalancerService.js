'use strict';


/**
 * Create Load Balancer
 * Create a new Load Balancer in a particular `region`.
 *
 * body Loadbalancers_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * returns inline_response_202_2
 **/
exports.createLoadBalancer = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "load_balancer" : {
    "generic_info" : {
      "sticky_sessions" : {
        "cookie_name" : "cookie_name"
      },
      "private_network" : "private_network",
      "ssl_redirect" : true,
      "proxy_protocol" : true,
      "vpc" : "vpc",
      "balancing_algorithm" : "balancing_algorithm"
    },
    "instances" : [ "instances", "instances" ],
    "firewall_rules" : [ {
      "port" : 9,
      "id" : "id",
      "source" : "source",
      "ip_type" : "ip_type"
    }, {
      "port" : 9,
      "id" : "id",
      "source" : "source",
      "ip_type" : "ip_type"
    } ],
    "date_created" : "date_created",
    "has_ssl" : true,
    "label" : "label",
    "health_check" : {
      "path" : "path",
      "response_timeout" : 1,
      "healthy_threshold" : 5,
      "protocol" : "protocol",
      "check_interval" : 6,
      "port" : 0,
      "unhealthy_threshold" : 5
    },
    "forward_rules" : [ {
      "backend_portocol" : "backend_portocol",
      "frontend_protocol" : "frontend_protocol",
      "id" : "id",
      "frontend_port" : 2,
      "backend_port" : 7
    }, {
      "backend_portocol" : "backend_portocol",
      "frontend_protocol" : "frontend_protocol",
      "id" : "id",
      "frontend_port" : 2,
      "backend_port" : 7
    } ],
    "ipv4" : "ipv4",
    "ipv6" : "ipv6",
    "http2" : true,
    "id" : "id",
    "region" : "region",
    "status" : "status"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Create Forwarding Rule
 * Create a new forwarding rule for a Load Balancer.
 *
 * body Loadbalancerid_forwardingrules_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * loadBalancerId String The [Load Balancer id](#operation/list-load-balancers).
 * no response value expected for this operation
 **/
exports.createLoadBalancerForwardingRules = function(body,loadBalancerId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Delete Load Balancer
 * Delete a Load Balancer.
 *
 * loadBalancerId String The [Load Balancer id](#operation/list-load-balancers).
 * no response value expected for this operation
 **/
exports.deleteLoadBalancer = function(loadBalancerId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Delete Forwarding Rule
 * Delete a Forwarding Rule on a Load Balancer.
 *
 * loadBalancerId String The [Load Balancer id](#operation/list-load-balancers).
 * forwardingRuleId String The [Forwarding Rule id](#operation/list-load-balancer-forwarding-rules).
 * no response value expected for this operation
 **/
exports.deleteLoadBalancerForwardingRule = function(loadBalancerId,forwardingRuleId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Get Load Balancer
 * Get information for a Load Balancer.
 *
 * loadBalancerId String The [Load Balancer id](#operation/list-load-balancers).
 * returns inline_response_202_2
 **/
exports.getLoadBalancer = function(loadBalancerId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "load_balancer" : {
    "generic_info" : {
      "sticky_sessions" : {
        "cookie_name" : "cookie_name"
      },
      "private_network" : "private_network",
      "ssl_redirect" : true,
      "proxy_protocol" : true,
      "vpc" : "vpc",
      "balancing_algorithm" : "balancing_algorithm"
    },
    "instances" : [ "instances", "instances" ],
    "firewall_rules" : [ {
      "port" : 9,
      "id" : "id",
      "source" : "source",
      "ip_type" : "ip_type"
    }, {
      "port" : 9,
      "id" : "id",
      "source" : "source",
      "ip_type" : "ip_type"
    } ],
    "date_created" : "date_created",
    "has_ssl" : true,
    "label" : "label",
    "health_check" : {
      "path" : "path",
      "response_timeout" : 1,
      "healthy_threshold" : 5,
      "protocol" : "protocol",
      "check_interval" : 6,
      "port" : 0,
      "unhealthy_threshold" : 5
    },
    "forward_rules" : [ {
      "backend_portocol" : "backend_portocol",
      "frontend_protocol" : "frontend_protocol",
      "id" : "id",
      "frontend_port" : 2,
      "backend_port" : 7
    }, {
      "backend_portocol" : "backend_portocol",
      "frontend_protocol" : "frontend_protocol",
      "id" : "id",
      "frontend_port" : 2,
      "backend_port" : 7
    } ],
    "ipv4" : "ipv4",
    "ipv6" : "ipv6",
    "http2" : true,
    "id" : "id",
    "region" : "region",
    "status" : "status"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Get Forwarding Rule
 * Get information for a Forwarding Rule on a Load Balancer.
 *
 * loadBalancerId String The [Load Balancer id](#operation/list-load-balancers).
 * forwardingRuleId String The [Forwarding Rule id](#operation/list-load-balancer-forwarding-rules).
 * returns inline_response_200_33
 **/
exports.getLoadBalancerForwardingRule = function(loadBalancerId,forwardingRuleId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "forwarding_rule" : {
    "frontend_protocol" : "frontend_protocol",
    "id" : "id",
    "frontend_port" : 0,
    "backend_protocol" : "backend_protocol",
    "backend_port" : 6
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Get Firewall Rule
 * Get a firewall rule for a Load Balancer.
 *
 * loadbalancerId String 
 * firewallRuleId String 
 * returns loadbalancer-firewall-rule
 **/
exports.getLoadbalancerFirewallRule = function(loadbalancerId,firewallRuleId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "port" : 0,
  "id" : "id",
  "source" : "source",
  "ip_type" : "ip_type"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * List Forwarding Rules
 * List the fowarding rules for a Load Balancer.
 *
 * loadBalancerId String The [Load Balancer id](#operation/list-load-balancers).
 * per_page Integer Number of items requested per page. Default is 100 and Max is 500. (optional)
 * cursor String Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination). (optional)
 * returns inline_response_200_32
 **/
exports.listLoadBalancerForwardingRules = function(loadBalancerId,per_page,cursor) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "forwarding_rules" : [ {
    "frontend_protocol" : "frontend_protocol",
    "id" : "id",
    "frontend_port" : 0,
    "backend_protocol" : "backend_protocol",
    "backend_port" : 6
  }, {
    "frontend_protocol" : "frontend_protocol",
    "id" : "id",
    "frontend_port" : 0,
    "backend_protocol" : "backend_protocol",
    "backend_port" : 6
  } ],
  "meta" : {
    "total" : 0,
    "links" : {
      "next" : "next",
      "prev" : "prev"
    }
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * List Load Balancers
 * List the Load Balancers in your account.
 *
 * per_page Integer Number of items requested per page. Default is 100 and Max is 500.  (optional)
 * cursor String Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination). (optional)
 * returns inline_response_200_31
 **/
exports.listLoadBalancers = function(per_page,cursor) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "meta" : {
    "total" : 0,
    "links" : {
      "next" : "next",
      "prev" : "prev"
    }
  },
  "load_balancers" : [ {
    "generic_info" : {
      "sticky_sessions" : {
        "cookie_name" : "cookie_name"
      },
      "private_network" : "private_network",
      "ssl_redirect" : true,
      "proxy_protocol" : true,
      "vpc" : "vpc",
      "balancing_algorithm" : "balancing_algorithm"
    },
    "instances" : [ "instances", "instances" ],
    "firewall_rules" : [ {
      "port" : 9,
      "id" : "id",
      "source" : "source",
      "ip_type" : "ip_type"
    }, {
      "port" : 9,
      "id" : "id",
      "source" : "source",
      "ip_type" : "ip_type"
    } ],
    "date_created" : "date_created",
    "has_ssl" : true,
    "label" : "label",
    "health_check" : {
      "path" : "path",
      "response_timeout" : 1,
      "healthy_threshold" : 5,
      "protocol" : "protocol",
      "check_interval" : 6,
      "port" : 0,
      "unhealthy_threshold" : 5
    },
    "forward_rules" : [ {
      "backend_portocol" : "backend_portocol",
      "frontend_protocol" : "frontend_protocol",
      "id" : "id",
      "frontend_port" : 2,
      "backend_port" : 7
    }, {
      "backend_portocol" : "backend_portocol",
      "frontend_protocol" : "frontend_protocol",
      "id" : "id",
      "frontend_port" : 2,
      "backend_port" : 7
    } ],
    "ipv4" : "ipv4",
    "ipv6" : "ipv6",
    "http2" : true,
    "id" : "id",
    "region" : "region",
    "status" : "status"
  }, {
    "generic_info" : {
      "sticky_sessions" : {
        "cookie_name" : "cookie_name"
      },
      "private_network" : "private_network",
      "ssl_redirect" : true,
      "proxy_protocol" : true,
      "vpc" : "vpc",
      "balancing_algorithm" : "balancing_algorithm"
    },
    "instances" : [ "instances", "instances" ],
    "firewall_rules" : [ {
      "port" : 9,
      "id" : "id",
      "source" : "source",
      "ip_type" : "ip_type"
    }, {
      "port" : 9,
      "id" : "id",
      "source" : "source",
      "ip_type" : "ip_type"
    } ],
    "date_created" : "date_created",
    "has_ssl" : true,
    "label" : "label",
    "health_check" : {
      "path" : "path",
      "response_timeout" : 1,
      "healthy_threshold" : 5,
      "protocol" : "protocol",
      "check_interval" : 6,
      "port" : 0,
      "unhealthy_threshold" : 5
    },
    "forward_rules" : [ {
      "backend_portocol" : "backend_portocol",
      "frontend_protocol" : "frontend_protocol",
      "id" : "id",
      "frontend_port" : 2,
      "backend_port" : 7
    }, {
      "backend_portocol" : "backend_portocol",
      "frontend_protocol" : "frontend_protocol",
      "id" : "id",
      "frontend_port" : 2,
      "backend_port" : 7
    } ],
    "ipv4" : "ipv4",
    "ipv6" : "ipv6",
    "http2" : true,
    "id" : "id",
    "region" : "region",
    "status" : "status"
  } ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * List Firewall Rules
 * List the firewall rules for a Load Balancer.
 *
 * loadbalancerId String 
 * per_page String Number of items requested per page. Default is 100 and Max is 500. (optional)
 * cursor String Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination). (optional)
 * returns loadbalancer-firewall-rule
 **/
exports.listLoadbalancerFirewallRules = function(loadbalancerId,per_page,cursor) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "port" : 0,
  "id" : "id",
  "source" : "source",
  "ip_type" : "ip_type"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Update Load Balancer
 * Update information for a Load Balancer. All attributes are optional. If not set, the attributes will retain their original values.
 *
 * body Loadbalancers_loadbalancerid_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * loadBalancerId String The [Load Balancer id](#operation/list-load-balancers).
 * no response value expected for this operation
 **/
exports.updateLoadBalancer = function(body,loadBalancerId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

