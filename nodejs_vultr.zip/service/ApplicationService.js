'use strict';


/**
 * List Applications
 * Get a list of all available Applications.
 *
 * type String Filter the results by type.  |   | Type | Description | | - | ------ | ------------- | |   | all | All available application types | |   | marketplace | Marketplace applications | |   | one-click | Vultr One-Click applications | (optional)
 * per_page Integer Number of items requested per page. Default is 100 and Max is 500. (optional)
 * cursor String Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination). (optional)
 * returns inline_response_200_14
 **/
exports.listApplications = function(type,per_page,cursor) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "meta" : {
    "total" : 0,
    "links" : {
      "next" : "next",
      "prev" : "prev"
    }
  },
  "applications" : [ {
    "vendor" : "vendor",
    "name" : "name",
    "deploy_name" : "deploy_name",
    "short_name" : "short_name",
    "id" : 0,
    "type" : "type",
    "image_id" : "image_id"
  }, {
    "vendor" : "vendor",
    "name" : "name",
    "deploy_name" : "deploy_name",
    "short_name" : "short_name",
    "id" : 0,
    "type" : "type",
    "image_id" : "image_id"
  } ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

