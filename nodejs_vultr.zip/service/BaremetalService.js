'use strict';


/**
 * Create Bare Metal Instance
 * Create a new Bare Metal instance in a `region` with the desired `plan`. Choose one of the following to deploy the instance:  * `os_id` * `snapshot_id` * `app_id` * `image_id`  Supply other attributes as desired.
 *
 * body Baremetals_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * returns inline_response_202_3
 **/
exports.createBaremetal = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "baremetal" : {
    "gateway_v4" : "gateway_v4",
    "os" : "os",
    "main_ip" : "main_ip",
    "date_created" : "date_created",
    "os_id" : 6,
    "default_password" : "default_password",
    "label" : "label",
    "cpu_count" : 0,
    "v6_main_ip" : "v6_main_ip",
    "tags" : [ "tags", "tags" ],
    "v6_network_size" : 5,
    "disk" : "disk",
    "v6_network" : "v6_network",
    "mac_address" : 5,
    "id" : "id",
    "tag" : "tag",
    "region" : "region",
    "image_id" : "image_id",
    "plan" : "plan",
    "app_id" : 1,
    "netmask_v4" : "netmask_v4",
    "ram" : "ram",
    "status" : "status"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Delete Bare Metal
 * Delete a Bare Metal instance.
 *
 * baremetalId String The [Bare Metal id](#operation/list-baremetals).
 * no response value expected for this operation
 **/
exports.deleteBaremetal = function(baremetalId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Bare Metal Bandwidth
 * Get bandwidth information for the Bare Metal instance.<br><br>The `bandwidth` object in a successful response contains objects representing a day in the month. The date is denoted by the nested object keys. Days begin and end in the UTC timezone. Bandwidth utilization data contained within the date object is refreshed periodically. We do not recommend using this endpoint to gather real-time metrics.
 *
 * baremetalId String The [Bare Metal id](#operation/list-baremetals).
 * returns inline_response_200_40
 **/
exports.getBandwidthBaremetal = function(baremetalId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bandwidth" : {
    "2020-10-10" : {
      "incoming_bytes" : 0,
      "outgoing_bytes" : 6
    }
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Get Bare Metal User Data
 * Get the user-supplied, base64 encoded [user data](https://www.vultr.com/docs/manage-instance-user-data-with-the-vultr-metadata-api/) for a Bare Metal.
 *
 * baremetalId String The [Bare Metal id](#operation/list-baremetals).
 * returns inline_response_200_41
 **/
exports.getBareMetalUserdata = function(baremetalId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "user_data" : {
    "data" : "data"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Get VNC URL for a Bare Metal
 * Get the VNC URL for a Bare Metal
 *
 * baremetalId String The [Bare Metal id](#operation/list-baremetals).
 * returns inline_response_200_53
 **/
exports.getBareMetalVnc = function(baremetalId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "vnc" : {
    "url" : "url"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Get Available Bare Metal Upgrades
 * Get available upgrades for a Bare Metal
 *
 * baremetalId String The [Bare Metal id](#operation/list-baremetals).
 * type String Filter upgrade by type:  - all (applications, plans) - applications - os (optional)
 * returns inline_response_200_52
 **/
exports.getBareMetalsUpgrades = function(baremetalId,type) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "upgrades" : {
    "os" : [ "", "" ],
    "applications" : [ "", "" ]
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Get Bare Metal
 * Get information for a Bare Metal instance.
 *
 * baremetalId String The [Bare Metal id](#operation/list-baremetals).
 * returns inline_response_200_37
 **/
exports.getBaremetal = function(baremetalId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bare_metal" : {
    "gateway_v4" : "gateway_v4",
    "os" : "os",
    "main_ip" : "main_ip",
    "date_created" : "date_created",
    "os_id" : 6,
    "default_password" : "default_password",
    "label" : "label",
    "cpu_count" : 0,
    "v6_main_ip" : "v6_main_ip",
    "tags" : [ "tags", "tags" ],
    "v6_network_size" : 5,
    "disk" : "disk",
    "v6_network" : "v6_network",
    "mac_address" : 5,
    "id" : "id",
    "tag" : "tag",
    "region" : "region",
    "image_id" : "image_id",
    "plan" : "plan",
    "app_id" : 1,
    "netmask_v4" : "netmask_v4",
    "ram" : "ram",
    "status" : "status"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Bare Metal IPv4 Addresses
 * Get the IPv4 information for the Bare Metal instance.
 *
 * baremetalId String The [Bare Metal id](#operation/list-baremetals).
 * returns inline_response_200_38
 **/
exports.getIpv4Baremetal = function(baremetalId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "ipv4s" : [ {
    "netmask" : "netmask",
    "mac_address" : "mac_address",
    "ip" : "ip",
    "type" : "type",
    "reverse" : "reverse",
    "gateway" : "gateway"
  }, {
    "netmask" : "netmask",
    "mac_address" : "mac_address",
    "ip" : "ip",
    "type" : "type",
    "reverse" : "reverse",
    "gateway" : "gateway"
  } ],
  "meta" : {
    "total" : 0,
    "links" : {
      "next" : "next",
      "prev" : "prev"
    }
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Bare Metal IPv6 Addresses
 * Get the IPv6 information for the Bare Metal instance.
 *
 * baremetalId String The [Bare Metal id](#operation/list-baremetals).
 * returns inline_response_200_39
 **/
exports.getIpv6Baremetal = function(baremetalId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "ipv6s" : [ {
    "network_size" : 0,
    "ip" : "ip",
    "type" : "type",
    "network" : "network"
  }, {
    "network_size" : 0,
    "ip" : "ip",
    "type" : "type",
    "network" : "network"
  } ],
  "meta" : {
    "total" : 0,
    "links" : {
      "next" : "next",
      "prev" : "prev"
    }
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Halt Bare Metal
 * Halt the Bare Metal instance.
 *
 * baremetalId String The [Bare Metal id](#operation/list-baremetals).
 * no response value expected for this operation
 **/
exports.haltBaremetal = function(baremetalId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Halt Bare Metals
 * Halt Bare Metals.
 *
 * body Baremetals_halt_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * no response value expected for this operation
 **/
exports.haltBaremetals = function(body) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * List Bare Metal Instances
 * List all Bare Metal instances in your account.
 *
 * per_page Integer Number of items requested per page. Default is 100 and Max is 500.  (optional)
 * cursor String Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination). (optional)
 * returns inline_response_200_36
 **/
exports.listBaremetals = function(per_page,cursor) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "meta" : {
    "total" : 0,
    "links" : {
      "next" : "next",
      "prev" : "prev"
    }
  },
  "bare_metals" : [ {
    "gateway_v4" : "gateway_v4",
    "os" : "os",
    "main_ip" : "main_ip",
    "date_created" : "date_created",
    "os_id" : 6,
    "default_password" : "default_password",
    "label" : "label",
    "cpu_count" : 0,
    "v6_main_ip" : "v6_main_ip",
    "tags" : [ "tags", "tags" ],
    "v6_network_size" : 5,
    "disk" : "disk",
    "v6_network" : "v6_network",
    "mac_address" : 5,
    "id" : "id",
    "tag" : "tag",
    "region" : "region",
    "image_id" : "image_id",
    "plan" : "plan",
    "app_id" : 1,
    "netmask_v4" : "netmask_v4",
    "ram" : "ram",
    "status" : "status"
  }, {
    "gateway_v4" : "gateway_v4",
    "os" : "os",
    "main_ip" : "main_ip",
    "date_created" : "date_created",
    "os_id" : 6,
    "default_password" : "default_password",
    "label" : "label",
    "cpu_count" : 0,
    "v6_main_ip" : "v6_main_ip",
    "tags" : [ "tags", "tags" ],
    "v6_network_size" : 5,
    "disk" : "disk",
    "v6_network" : "v6_network",
    "mac_address" : 5,
    "id" : "id",
    "tag" : "tag",
    "region" : "region",
    "image_id" : "image_id",
    "plan" : "plan",
    "app_id" : 1,
    "netmask_v4" : "netmask_v4",
    "ram" : "ram",
    "status" : "status"
  } ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Reboot Bare Metals
 * Reboot Bare Metals.
 *
 * body Baremetals_reboot_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * no response value expected for this operation
 **/
exports.rebootBareMetals = function(body) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Reboot Bare Metal
 * Reboot the Bare Metal instance.
 *
 * baremetalId String The [Bare Metal id](#operation/list-baremetals).
 * no response value expected for this operation
 **/
exports.rebootBaremetal = function(baremetalId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Reinstall Bare Metal
 * Reinstall the Bare Metal instance.  **Note:** This action may take a few extra seconds to complete.
 *
 * baremetalId String The [Bare Metal id](#operation/list-baremetals).
 * returns inline_response_200_37
 **/
exports.reinstallBaremetal = function(baremetalId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bare_metal" : {
    "gateway_v4" : "gateway_v4",
    "os" : "os",
    "main_ip" : "main_ip",
    "date_created" : "date_created",
    "os_id" : 6,
    "default_password" : "default_password",
    "label" : "label",
    "cpu_count" : 0,
    "v6_main_ip" : "v6_main_ip",
    "tags" : [ "tags", "tags" ],
    "v6_network_size" : 5,
    "disk" : "disk",
    "v6_network" : "v6_network",
    "mac_address" : 5,
    "id" : "id",
    "tag" : "tag",
    "region" : "region",
    "image_id" : "image_id",
    "plan" : "plan",
    "app_id" : 1,
    "netmask_v4" : "netmask_v4",
    "ram" : "ram",
    "status" : "status"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Start Bare Metals
 * Start Bare Metals.
 *
 * body Baremetals_start_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * no response value expected for this operation
 **/
exports.startBareMetals = function(body) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Start Bare Metal
 * Start the Bare Metal instance.
 *
 * baremetalId String The [Bare Metal id](#operation/list-baremetals).
 * no response value expected for this operation
 **/
exports.startBaremetal = function(baremetalId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Update Bare Metal
 * Update a Bare Metal instance. All attributes are optional. If not set, the attributes will retain their original values.  **Note:** Changing `os_id`, `app_id` or `image_id` may take a few extra seconds to complete.
 *
 * body Baremetals_baremetalid_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * baremetalId String The [Bare Metal id](#operation/list-baremetals).
 * returns inline_response_200_37
 **/
exports.updateBaremetal = function(body,baremetalId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bare_metal" : {
    "gateway_v4" : "gateway_v4",
    "os" : "os",
    "main_ip" : "main_ip",
    "date_created" : "date_created",
    "os_id" : 6,
    "default_password" : "default_password",
    "label" : "label",
    "cpu_count" : 0,
    "v6_main_ip" : "v6_main_ip",
    "tags" : [ "tags", "tags" ],
    "v6_network_size" : 5,
    "disk" : "disk",
    "v6_network" : "v6_network",
    "mac_address" : 5,
    "id" : "id",
    "tag" : "tag",
    "region" : "region",
    "image_id" : "image_id",
    "plan" : "plan",
    "app_id" : 1,
    "netmask_v4" : "netmask_v4",
    "ram" : "ram",
    "status" : "status"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

