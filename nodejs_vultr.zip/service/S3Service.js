'use strict';


/**
 * Create Object Storage
 * Create new Object Storage. The `cluster_id` attribute is required.
 *
 * body Objectstorage_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * returns inline_response_202_1
 **/
exports.createObjectStorage = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "object_storage" : {
    "s3_secret_key" : "s3_secret_key",
    "cluster_id" : 0,
    "s3_access_key" : "s3_access_key",
    "date_created" : "date_created",
    "s3_hostname" : "s3_hostname",
    "id" : "id",
    "label" : "label",
    "region" : "region",
    "status" : "status"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Delete Object Storage
 * Delete an Object Storage.
 *
 * objectStorageId String The [Object Storage id](#operation/list-object-storages).
 * no response value expected for this operation
 **/
exports.deleteObjectStorage = function(objectStorageId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Get Object Storage
 * Get information about an Object Storage.
 *
 * objectStorageId String The [Object Storage id](#operation/list-object-storages).
 * returns inline_response_202_1
 **/
exports.getObjectStorage = function(objectStorageId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "object_storage" : {
    "s3_secret_key" : "s3_secret_key",
    "cluster_id" : 0,
    "s3_access_key" : "s3_access_key",
    "date_created" : "date_created",
    "s3_hostname" : "s3_hostname",
    "id" : "id",
    "label" : "label",
    "region" : "region",
    "status" : "status"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Get All Clusters
 * Get a list of all Object Storage Clusters.
 *
 * per_page Integer Number of items requested per page. Default is 100 and Max is 500. (optional)
 * cursor String Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination). (optional)
 * returns inline_response_200_23
 **/
exports.listObjectStorageClusters = function(per_page,cursor) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "meta" : {
    "total" : 0,
    "links" : {
      "next" : "next",
      "prev" : "prev"
    }
  },
  "clusters" : [ {
    "hostname" : "hostname",
    "id" : 0,
    "region" : "region",
    "deploy" : "deploy"
  }, {
    "hostname" : "hostname",
    "id" : 0,
    "region" : "region",
    "deploy" : "deploy"
  } ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * List Object Storages
 * Get a list of all Object Storage in your account.
 *
 * per_page Integer Number of items requested per page. Default is 100 and Max is 500. (optional)
 * cursor String Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination). (optional)
 * returns inline_response_200_22
 **/
exports.listObjectStorages = function(per_page,cursor) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "meta" : {
    "total" : 0,
    "links" : {
      "next" : "next",
      "prev" : "prev"
    }
  },
  "object_storages" : [ {
    "s3_secret_key" : "s3_secret_key",
    "cluster_id" : 0,
    "s3_access_key" : "s3_access_key",
    "date_created" : "date_created",
    "s3_hostname" : "s3_hostname",
    "id" : "id",
    "label" : "label",
    "region" : "region",
    "status" : "status"
  }, {
    "s3_secret_key" : "s3_secret_key",
    "cluster_id" : 0,
    "s3_access_key" : "s3_access_key",
    "date_created" : "date_created",
    "s3_hostname" : "s3_hostname",
    "id" : "id",
    "label" : "label",
    "region" : "region",
    "status" : "status"
  } ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Regenerate Object Storage Keys
 * Regenerate the keys for an Object Storage.
 *
 * objectStorageId String The [Object Storage id](#operation/list-object-storages).
 * returns inline_response_201_3
 **/
exports.regenerateObjectStorageKeys = function(objectStorageId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "s3_credentials" : {
    "s3_secret_key" : "s3_secret_key",
    "s3_access_key" : "s3_access_key",
    "s3_hostname" : "s3_hostname"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Update Object Storage
 * Update the label for an Object Storage.
 *
 * body Objectstorage_objectstorageid_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * objectStorageId String The [Object Storage id](#operation/list-object-storages).
 * no response value expected for this operation
 **/
exports.updateObjectStorage = function(body,objectStorageId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

