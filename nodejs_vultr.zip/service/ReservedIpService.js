'use strict';


/**
 * Attach Reserved IP
 * Attach a Reserved IP to an compute instance or a baremetal instance - `instance_id`.
 *
 * body Reservedip_attach_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * reservedIp String The [Reserved IP id](#operation/list-reserved-ips)
 * no response value expected for this operation
 **/
exports.attachReservedIp = function(body,reservedIp) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Convert Instance IP to Reserved IP
 * Convert the `ip_address` of an existing [instance](#operation/list-instances) into a Reserved IP.
 *
 * body Reservedips_convert_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * returns inline_response_200_11
 **/
exports.convertReservedIp = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "reserved_ip" : {
    "subnet" : "subnet",
    "instance_id" : "instance_id",
    "id" : "id",
    "subnet_size" : 0,
    "label" : "label",
    "region" : "region",
    "ip_type" : "ip_type"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Create Reserved IP
 * Create a new Reserved IP. The `region` and `ip_type` attributes are required.
 *
 * body Reservedips_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * returns inline_response_200_11
 **/
exports.createReservedIp = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "reserved_ip" : {
    "subnet" : "subnet",
    "instance_id" : "instance_id",
    "id" : "id",
    "subnet_size" : 0,
    "label" : "label",
    "region" : "region",
    "ip_type" : "ip_type"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Delete Reserved IP
 * Delete a Reserved IP.
 *
 * reservedIp String The [Reserved IP id](#operation/list-reserved-ips).
 * no response value expected for this operation
 **/
exports.deleteReservedIp = function(reservedIp) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Detach Reserved IP
 * Detach a Reserved IP.
 *
 * reservedIp String The [Reserved IP id](#operation/list-reserved-ips)
 * no response value expected for this operation
 **/
exports.detachReservedIp = function(reservedIp) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Get Reserved IP
 * Get information about a Reserved IP.
 *
 * reservedIp String The [Reserved IP id](#operation/list-reserved-ips).
 * returns inline_response_200_11
 **/
exports.getReservedIp = function(reservedIp) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "reserved_ip" : {
    "subnet" : "subnet",
    "instance_id" : "instance_id",
    "id" : "id",
    "subnet_size" : 0,
    "label" : "label",
    "region" : "region",
    "ip_type" : "ip_type"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * List Reserved IPs
 * List all Reserved IPs in your account.
 *
 * per_page Integer Number of items requested per page. Default is 100 and Max is 500. (optional)
 * cursor String Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination). (optional)
 * returns inline_response_200_12
 **/
exports.listReservedIps = function(per_page,cursor) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "reserved_ips" : [ {
    "subnet" : "subnet",
    "instance_id" : "instance_id",
    "id" : "id",
    "subnet_size" : 0,
    "label" : "label",
    "region" : "region",
    "ip_type" : "ip_type"
  }, {
    "subnet" : "subnet",
    "instance_id" : "instance_id",
    "id" : "id",
    "subnet_size" : 0,
    "label" : "label",
    "region" : "region",
    "ip_type" : "ip_type"
  } ],
  "meta" : {
    "total" : 0,
    "links" : {
      "next" : "next",
      "prev" : "prev"
    }
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Update Reserved IP
 * Update information on a Reserved IP.
 *
 * body Reservedips_reservedip_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * reservedIp String The [Reserved IP id](#operation/list-reserved-ips).
 * returns inline_response_200_11
 **/
exports.patchReservedIpsReservedIp = function(body,reservedIp) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "reserved_ip" : {
    "subnet" : "subnet",
    "instance_id" : "instance_id",
    "id" : "id",
    "subnet_size" : 0,
    "label" : "label",
    "region" : "region",
    "ip_type" : "ip_type"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

