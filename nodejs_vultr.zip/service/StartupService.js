'use strict';


/**
 * Create Startup Script
 * Create a new Startup Script. The `name` and `script` attributes are required, and scripts are base-64 encoded.
 *
 * body Startupscripts_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * returns inline_response_200_5
 **/
exports.createStartupScript = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "startup_script" : {
    "date_modified" : "date_modified",
    "date_created" : "date_created",
    "name" : "name",
    "id" : "id",
    "type" : "type",
    "script" : "script"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Delete Startup Script
 * Delete a Startup Script.
 *
 * startupId String The [Startup Script id](#operation/list-startup-scripts).
 * no response value expected for this operation
 **/
exports.deleteStartupScript = function(startupId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Get Startup Script
 * Get information for a Startup Script.
 *
 * startupId String The [Startup Script id](#operation/list-startup-scripts).
 * returns inline_response_200_5
 **/
exports.getStartupScript = function(startupId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "startup_script" : {
    "date_modified" : "date_modified",
    "date_created" : "date_created",
    "name" : "name",
    "id" : "id",
    "type" : "type",
    "script" : "script"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * List Startup Scripts
 * Get a list of all Startup Scripts.
 *
 * per_page Integer Number of items requested per page. Default is 100 and Max is 500. (optional)
 * cursor String Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination). (optional)
 * returns inline_response_200_6
 **/
exports.listStartupScripts = function(per_page,cursor) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "startup_scripts" : [ {
    "date_modified" : "date_modified",
    "date_created" : "date_created",
    "name" : "name",
    "id" : "id",
    "type" : "type",
    "script" : "script"
  }, {
    "date_modified" : "date_modified",
    "date_created" : "date_created",
    "name" : "name",
    "id" : "id",
    "type" : "type",
    "script" : "script"
  } ],
  "meta" : {
    "total" : 0,
    "links" : {
      "next" : "next",
      "prev" : "prev"
    }
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Update Startup Script
 * Update a Startup Script. The attributes `name` and `script` are optional. If not set, the attributes will retain their original values. The `script` attribute is base-64 encoded. New deployments will use the updated script, but this action does not update previously deployed instances.
 *
 * body Startupscripts_startupid_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * startupId String The [Startup Script id](#operation/list-startup-scripts).
 * no response value expected for this operation
 **/
exports.updateStartupScript = function(body,startupId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

