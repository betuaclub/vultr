'use strict';


/**
 * Create Kubernetes Cluster
 * Create Kubernetes Cluster
 *
 * body Kubernetes_clusters_body Request Body (optional)
 * returns inline_response_201_5
 **/
exports.createKubernetesCluster = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "vke_cluster" : {
    "endpoint" : "endpoint",
    "cluster_subnet" : "cluster_subnet",
    "service_subnet" : "service_subnet",
    "date_created" : "date_created",
    "ip" : "ip",
    "node_pools" : [ {
      "nodes" : [ {
        "date_created" : "date_created",
        "id" : "id",
        "label" : "label"
      }, {
        "date_created" : "date_created",
        "id" : "id",
        "label" : "label"
      } ],
      "date_updated" : "date_updated",
      "auto_scaler" : true,
      "date_created" : "date_created",
      "node_quantity" : 0,
      "max_nodes" : 1,
      "id" : "id",
      "label" : "label",
      "tag" : "tag",
      "plan" : "plan",
      "min_nodes" : 6,
      "status" : "status"
    }, {
      "nodes" : [ {
        "date_created" : "date_created",
        "id" : "id",
        "label" : "label"
      }, {
        "date_created" : "date_created",
        "id" : "id",
        "label" : "label"
      } ],
      "date_updated" : "date_updated",
      "auto_scaler" : true,
      "date_created" : "date_created",
      "node_quantity" : 0,
      "max_nodes" : 1,
      "id" : "id",
      "label" : "label",
      "tag" : "tag",
      "plan" : "plan",
      "min_nodes" : 6,
      "status" : "status"
    } ],
    "id" : "id",
    "label" : "label",
    "region" : "region",
    "version" : "version",
    "status" : "status"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Create NodePool
 * Create NodePool for a Existing Kubernetes Cluster
 *
 * body Vkeid_nodepools_body Request Body (optional)
 * vkeId String The [VKE ID](#operation/list-kubernetes-clusters).
 * returns inline_response_201_6
 **/
exports.createNodepools = function(body,vkeId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "node_pool" : {
    "nodes" : [ {
      "date_created" : "date_created",
      "id" : "id",
      "label" : "label"
    }, {
      "date_created" : "date_created",
      "id" : "id",
      "label" : "label"
    } ],
    "date_updated" : "date_updated",
    "auto_scaler" : true,
    "date_created" : "date_created",
    "node_quantity" : 0,
    "max_nodes" : 1,
    "id" : "id",
    "label" : "label",
    "tag" : "tag",
    "plan" : "plan",
    "min_nodes" : 6,
    "status" : "status"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Delete Kubernetes Cluster
 * Delete Kubernetes Cluster
 *
 * vkeId String The [VKE ID](#operation/list-kubernetes-clusters).
 * no response value expected for this operation
 **/
exports.deleteKubernetesCluster = function(vkeId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Delete VKE Cluster and All Related Resources
 * Delete Kubernetes Cluster and all related resources. 
 *
 * vkeId String 
 * no response value expected for this operation
 **/
exports.deleteKubernetesClusterVkeIdDeleteWithLinkedResources = function(vkeId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Delete Nodepool
 * Delete a NodePool from a Kubernetes Cluster
 *
 * vkeId String The [VKE ID](#operation/list-kubernetes-clusters).
 * nodepoolId String The [NodePool ID](#operation/get-nodepools).
 * no response value expected for this operation
 **/
exports.deleteNodepool = function(vkeId,nodepoolId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Delete NodePool Instance
 * Delete a single nodepool instance from a given Nodepool
 *
 * vkeId String The [VKE ID](#operation/list-kubernetes-clusters).
 * nodepoolId String The [NodePool ID](#operation/get-nodepools).
 * nodeId String The [Instance ID](#operation/list-instances).
 * no response value expected for this operation
 **/
exports.deleteNodepoolInstance = function(vkeId,nodepoolId,nodeId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Get Kubernetes Available Upgrades
 * Get the available upgrades for the specified Kubernetes cluster.
 *
 * vkeId String The [VKE ID](#operation/list-kubernetes-clusters).
 * returns inline_response_200_56
 **/
exports.getKubernetesAvailableUpgrades = function(vkeId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "available_upgrades" : [ "available_upgrades", "available_upgrades" ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Get Kubernetes Cluster
 * Get Kubernetes Cluster
 *
 * vkeId String The [VKE ID](#operation/list-kubernetes-clusters).
 * returns inline_response_201_5
 **/
exports.getKubernetesClusters = function(vkeId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "vke_cluster" : {
    "endpoint" : "endpoint",
    "cluster_subnet" : "cluster_subnet",
    "service_subnet" : "service_subnet",
    "date_created" : "date_created",
    "ip" : "ip",
    "node_pools" : [ {
      "nodes" : [ {
        "date_created" : "date_created",
        "id" : "id",
        "label" : "label"
      }, {
        "date_created" : "date_created",
        "id" : "id",
        "label" : "label"
      } ],
      "date_updated" : "date_updated",
      "auto_scaler" : true,
      "date_created" : "date_created",
      "node_quantity" : 0,
      "max_nodes" : 1,
      "id" : "id",
      "label" : "label",
      "tag" : "tag",
      "plan" : "plan",
      "min_nodes" : 6,
      "status" : "status"
    }, {
      "nodes" : [ {
        "date_created" : "date_created",
        "id" : "id",
        "label" : "label"
      }, {
        "date_created" : "date_created",
        "id" : "id",
        "label" : "label"
      } ],
      "date_updated" : "date_updated",
      "auto_scaler" : true,
      "date_created" : "date_created",
      "node_quantity" : 0,
      "max_nodes" : 1,
      "id" : "id",
      "label" : "label",
      "tag" : "tag",
      "plan" : "plan",
      "min_nodes" : 6,
      "status" : "status"
    } ],
    "id" : "id",
    "label" : "label",
    "region" : "region",
    "version" : "version",
    "status" : "status"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Get Kubernetes Cluster Kubeconfig
 * Get Kubernetes Cluster Kubeconfig
 *
 * vkeId String The [VKE ID](#operation/list-kubernetes-clusters).
 * returns inline_response_200_58
 **/
exports.getKubernetesClustersConfig = function(vkeId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "kube_config" : "kube_config"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Get Kubernetes Resources
 * Get the block storage volumes and load balancers deployed by the specified Kubernetes cluster.
 *
 * vkeId String The [VKE ID](#operation/list-kubernetes-clusters).
 * returns inline_response_200_55
 **/
exports.getKubernetesResources = function(vkeId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "resources" : {
    "load_balancer" : [ {
      "date_created" : "date_created",
      "id" : "id",
      "label" : "label",
      "status" : "status"
    }, {
      "date_created" : "date_created",
      "id" : "id",
      "label" : "label",
      "status" : "status"
    } ],
    "block_storage" : [ {
      "date_created" : "date_created",
      "id" : "id",
      "label" : "label",
      "status" : "status"
    }, {
      "date_created" : "date_created",
      "id" : "id",
      "label" : "label",
      "status" : "status"
    } ]
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Get Kubernetes Versions
 * Get a list of supported Kubernetes versions
 *
 * returns inline_response_200_59
 **/
exports.getKubernetesVersions = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "versions" : [ "versions", "versions" ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Get NodePool
 * Get Nodepool from a Kubernetes Cluster
 *
 * vkeId String The [VKE ID](#operation/list-kubernetes-clusters).
 * nodepoolId String The [NodePool ID](#operation/get-nodepools).
 * returns inline_response_201_6
 **/
exports.getNodepool = function(vkeId,nodepoolId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "node_pool" : {
    "nodes" : [ {
      "date_created" : "date_created",
      "id" : "id",
      "label" : "label"
    }, {
      "date_created" : "date_created",
      "id" : "id",
      "label" : "label"
    } ],
    "date_updated" : "date_updated",
    "auto_scaler" : true,
    "date_created" : "date_created",
    "node_quantity" : 0,
    "max_nodes" : 1,
    "id" : "id",
    "label" : "label",
    "tag" : "tag",
    "plan" : "plan",
    "min_nodes" : 6,
    "status" : "status"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * List NodePools
 * List all available NodePools on a Kubernetes Cluster
 *
 * vkeId String The [VKE ID](#operation/list-kubernetes-clusters).
 * returns inline_response_200_57
 **/
exports.getNodepools = function(vkeId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "node_pools" : [ {
    "nodes" : [ {
      "date_created" : "date_created",
      "id" : "id",
      "label" : "label"
    }, {
      "date_created" : "date_created",
      "id" : "id",
      "label" : "label"
    } ],
    "date_updated" : "date_updated",
    "auto_scaler" : true,
    "date_created" : "date_created",
    "node_quantity" : 0,
    "max_nodes" : 1,
    "id" : "id",
    "label" : "label",
    "tag" : "tag",
    "plan" : "plan",
    "min_nodes" : 6,
    "status" : "status"
  }, {
    "nodes" : [ {
      "date_created" : "date_created",
      "id" : "id",
      "label" : "label"
    }, {
      "date_created" : "date_created",
      "id" : "id",
      "label" : "label"
    } ],
    "date_updated" : "date_updated",
    "auto_scaler" : true,
    "date_created" : "date_created",
    "node_quantity" : 0,
    "max_nodes" : 1,
    "id" : "id",
    "label" : "label",
    "tag" : "tag",
    "plan" : "plan",
    "min_nodes" : 6,
    "status" : "status"
  } ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * List all Kubernetes Clusters
 * List all Kubernetes clusters currently deployed
 *
 * returns inline_response_200_54
 **/
exports.listKubernetesClusters = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "vke_clusters" : [ {
    "endpoint" : "endpoint",
    "cluster_subnet" : "cluster_subnet",
    "service_subnet" : "service_subnet",
    "date_created" : "date_created",
    "ip" : "ip",
    "node_pools" : [ {
      "nodes" : [ {
        "date_created" : "date_created",
        "id" : "id",
        "label" : "label"
      }, {
        "date_created" : "date_created",
        "id" : "id",
        "label" : "label"
      } ],
      "date_updated" : "date_updated",
      "auto_scaler" : true,
      "date_created" : "date_created",
      "node_quantity" : 0,
      "max_nodes" : 1,
      "id" : "id",
      "label" : "label",
      "tag" : "tag",
      "plan" : "plan",
      "min_nodes" : 6,
      "status" : "status"
    }, {
      "nodes" : [ {
        "date_created" : "date_created",
        "id" : "id",
        "label" : "label"
      }, {
        "date_created" : "date_created",
        "id" : "id",
        "label" : "label"
      } ],
      "date_updated" : "date_updated",
      "auto_scaler" : true,
      "date_created" : "date_created",
      "node_quantity" : 0,
      "max_nodes" : 1,
      "id" : "id",
      "label" : "label",
      "tag" : "tag",
      "plan" : "plan",
      "min_nodes" : 6,
      "status" : "status"
    } ],
    "id" : "id",
    "label" : "label",
    "region" : "region",
    "version" : "version",
    "status" : "status"
  }, {
    "endpoint" : "endpoint",
    "cluster_subnet" : "cluster_subnet",
    "service_subnet" : "service_subnet",
    "date_created" : "date_created",
    "ip" : "ip",
    "node_pools" : [ {
      "nodes" : [ {
        "date_created" : "date_created",
        "id" : "id",
        "label" : "label"
      }, {
        "date_created" : "date_created",
        "id" : "id",
        "label" : "label"
      } ],
      "date_updated" : "date_updated",
      "auto_scaler" : true,
      "date_created" : "date_created",
      "node_quantity" : 0,
      "max_nodes" : 1,
      "id" : "id",
      "label" : "label",
      "tag" : "tag",
      "plan" : "plan",
      "min_nodes" : 6,
      "status" : "status"
    }, {
      "nodes" : [ {
        "date_created" : "date_created",
        "id" : "id",
        "label" : "label"
      }, {
        "date_created" : "date_created",
        "id" : "id",
        "label" : "label"
      } ],
      "date_updated" : "date_updated",
      "auto_scaler" : true,
      "date_created" : "date_created",
      "node_quantity" : 0,
      "max_nodes" : 1,
      "id" : "id",
      "label" : "label",
      "tag" : "tag",
      "plan" : "plan",
      "min_nodes" : 6,
      "status" : "status"
    } ],
    "id" : "id",
    "label" : "label",
    "region" : "region",
    "version" : "version",
    "status" : "status"
  } ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Recycle a NodePool Instance
 * Recycle a specific NodePool Instance
 *
 * vkeId String The [VKE ID](#operation/list-kubernetes-clusters).
 * nodepoolId String The [NodePool ID](#operation/get-nodepools).
 * nodeId String Node ID
 * no response value expected for this operation
 **/
exports.recycleNodepoolInstance = function(vkeId,nodepoolId,nodeId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Start Kubernetes Cluster Upgrade
 * Start a Kubernetes cluster upgrade.
 *
 * body Vkeid_upgrades_body Request Body (optional)
 * vkeId String The [VKE ID](#operation/list-kubernetes-clusters).
 * no response value expected for this operation
 **/
exports.startKubernetesClusterUpgrade = function(body,vkeId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Update Kubernetes Cluster
 * Update Kubernetes Cluster
 *
 * body Clusters_vkeid_body Request Body (optional)
 * vkeId String The [VKE ID](#operation/list-kubernetes-clusters).
 * no response value expected for this operation
 **/
exports.updateKubernetesCluster = function(body,vkeId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Update Nodepool
 * Update a Nodepool on a Kubernetes Cluster
 *
 * body Nodepools_nodepoolid_body Request Body (optional)
 * vkeId String The [VKE ID](#operation/list-kubernetes-clusters).
 * nodepoolId String The [NodePool ID](#operation/get-nodepools).
 * returns inline_response_201_6
 **/
exports.updateNodepool = function(body,vkeId,nodepoolId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "node_pool" : {
    "nodes" : [ {
      "date_created" : "date_created",
      "id" : "id",
      "label" : "label"
    }, {
      "date_created" : "date_created",
      "id" : "id",
      "label" : "label"
    } ],
    "date_updated" : "date_updated",
    "auto_scaler" : true,
    "date_created" : "date_created",
    "node_quantity" : 0,
    "max_nodes" : 1,
    "id" : "id",
    "label" : "label",
    "tag" : "tag",
    "plan" : "plan",
    "min_nodes" : 6,
    "status" : "status"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Update Nodepool
 * Update a Nodepool on a Kubernetes Cluster
 *
 * body Nodepools_nodepoolid_body Request Body (optional)
 * vkeId String The [VKE ID](#operation/list-kubernetes-clusters).
 * nodepoolId String The [NodePool ID](#operation/get-nodepools).
 * returns inline_response_201_6
 **/
exports.updateNodepool = function(body,vkeId,nodepoolId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "node_pool" : {
    "nodes" : [ {
      "date_created" : "date_created",
      "id" : "id",
      "label" : "label"
    }, {
      "date_created" : "date_created",
      "id" : "id",
      "label" : "label"
    } ],
    "date_updated" : "date_updated",
    "auto_scaler" : true,
    "date_created" : "date_created",
    "node_quantity" : 0,
    "max_nodes" : 1,
    "id" : "id",
    "label" : "label",
    "tag" : "tag",
    "plan" : "plan",
    "min_nodes" : 6,
    "status" : "status"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

