'use strict';


/**
 * Get Account Info
 * Get your Vultr account, permission, and billing information.
 *
 * returns inline_response_200_15
 **/
exports.getAccount = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "account" : {
    "acls" : [ "acls", "acls" ],
    "balance" : 0.8008281904610115,
    "pending_charges" : 6.027456183070403,
    "name" : "name",
    "last_payment_date" : "last_payment_date",
    "email" : "email",
    "last_payment_amount" : 1.4658129805029452
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

