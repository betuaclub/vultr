'use strict';


/**
 * Get a Backup
 * Get the information for the Backup.
 *
 * backupId String The [Backup id](#operation/list-backups).
 * returns inline_response_200_49
 **/
exports.getBackup = function(backupId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "backup" : {
    "size" : 0,
    "date_created" : "date_created",
    "description" : "description",
    "id" : "id",
    "status" : "status"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * List Backups
 * Get information about Backups in your account.
 *
 * instance_id String Filter the backup list by [Instance id](#operation/list-instances). (optional)
 * per_page Integer Number of items requested per page. Default is 100 and Max is 500. (optional)
 * cursor String Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination). (optional)
 * returns inline_response_200_16
 **/
exports.listBackups = function(instance_id,per_page,cursor) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "meta" : {
    "total" : 0,
    "links" : {
      "next" : "next",
      "prev" : "prev"
    }
  },
  "backups" : [ {
    "size" : 0,
    "date_created" : "date_created",
    "description" : "description",
    "id" : "id",
    "status" : "status"
  }, {
    "size" : 0,
    "date_created" : "date_created",
    "description" : "description",
    "id" : "id",
    "status" : "status"
  } ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

