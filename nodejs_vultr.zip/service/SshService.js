'use strict';


/**
 * Create SSH key
 * Create a new SSH Key for use with future instances. This does not update any running instances.
 *
 * body Sshkeys_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * returns inline_response_200_7
 **/
exports.createSshKey = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "ssh_key" : {
    "date_created" : "date_created",
    "name" : "name",
    "ssh_key" : "ssh_key",
    "id" : "id"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Delete SSH Key
 * Delete an SSH Key.
 *
 * sshKeyId String The [SSH Key id](#operation/list-ssh-keys).
 * no response value expected for this operation
 **/
exports.deleteSshKey = function(sshKeyId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Get SSH Key
 * Get information about an SSH Key.
 *
 * sshKeyId String The [SSH Key id](#operation/list-ssh-keys).
 * returns inline_response_200_7
 **/
exports.getSshKey = function(sshKeyId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "ssh_key" : {
    "date_created" : "date_created",
    "name" : "name",
    "ssh_key" : "ssh_key",
    "id" : "id"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * List SSH Keys
 * List all SSH Keys in your account.
 *
 * per_page Integer Number of items requested per page. Default is 100 and Max is 500.  (optional)
 * cursor String Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination). (optional)
 * returns inline_response_200_8
 **/
exports.listSshKeys = function(per_page,cursor) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "ssh_keys" : [ {
    "date_created" : "date_created",
    "name" : "name",
    "ssh_key" : "ssh_key",
    "id" : "id"
  }, {
    "date_created" : "date_created",
    "name" : "name",
    "ssh_key" : "ssh_key",
    "id" : "id"
  } ],
  "meta" : {
    "total" : 0,
    "links" : {
      "next" : "next",
      "prev" : "prev"
    }
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Update SSH Key
 * Update an SSH Key. The attributes `name` and `ssh_key` are optional. If not set, the attributes will retain their original values. New deployments will use the updated key, but this action does not update previously deployed instances.
 *
 * body Sshkeys_sshkeyid_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * sshKeyId String The [SSH Key id](#operation/list-ssh-keys).
 * no response value expected for this operation
 **/
exports.updateSshKey = function(body,sshKeyId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

