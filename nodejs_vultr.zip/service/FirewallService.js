'use strict';


/**
 * Create Firewall Group
 * Create a new Firewall Group.
 *
 * body Firewalls_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * returns inline_response_201
 **/
exports.createFirewallGroup = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "firewall_group" : {
    "date_modified" : "date_modified",
    "date_created" : "date_created",
    "description" : "description",
    "id" : "id",
    "max_rule_count" : 1,
    "instance_count" : 0,
    "rule_count" : 6
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Delete Firewall Group
 * Delete a Firewall Group.
 *
 * firewallGroupId String The [Firewall Group id](#operation/list-firewall-groups).
 * no response value expected for this operation
 **/
exports.deleteFirewallGroup = function(firewallGroupId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Delete Firewall Rule
 * Delete a Firewall Rule.
 *
 * firewallGroupId String The [Firewall Group id](#operation/list-firewall-groups).
 * firewallRuleId String The [Firewall Rule id](#operation/list-firewall-group-rules).
 * no response value expected for this operation
 **/
exports.deleteFirewallGroupRule = function(firewallGroupId,firewallRuleId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Get Firewall Group
 * Get information for a Firewall Group.
 *
 * firewallGroupId String The [Firewall Group id](#operation/list-firewall-groups).
 * returns inline_response_201
 **/
exports.getFirewallGroup = function(firewallGroupId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "firewall_group" : {
    "date_modified" : "date_modified",
    "date_created" : "date_created",
    "description" : "description",
    "id" : "id",
    "max_rule_count" : 1,
    "instance_count" : 0,
    "rule_count" : 6
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Get Firewall Rule
 * Get a Firewall Rule.
 *
 * firewallGroupId String The [Firewall Group id](#operation/list-firewall-groups).
 * firewallRuleId String The [Firewall Rule id](#operation/list-firewall-group-rules).
 * returns inline_response_201_1
 **/
exports.getFirewallGroupRule = function(firewallGroupId,firewallRuleId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "firewall_rule" : {
    "subnet" : "subnet",
    "protocol" : "protocol",
    "notes" : "notes",
    "port" : "port",
    "action" : "action",
    "id" : 0,
    "subnet_size" : 6,
    "source" : "source",
    "type" : "type",
    "ip_type" : "ip_type"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * List Firewall Rules
 * Get the Firewall Rules for a Firewall Group.
 *
 * firewallGroupId String The [Firewall Group id](#operation/list-firewall-groups).
 * per_page Integer Number of items requested per page. Default is 100 and Max is 500. (optional)
 * cursor String Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination). (optional)
 * returns inline_response_200_19
 **/
exports.listFirewallGroupRules = function(firewallGroupId,per_page,cursor) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "firewall_rules" : [ {
    "subnet" : "subnet",
    "protocol" : "protocol",
    "notes" : "notes",
    "port" : "port",
    "action" : "action",
    "id" : 0,
    "subnet_size" : 6,
    "source" : "source",
    "type" : "type",
    "ip_type" : "ip_type"
  }, {
    "subnet" : "subnet",
    "protocol" : "protocol",
    "notes" : "notes",
    "port" : "port",
    "action" : "action",
    "id" : 0,
    "subnet_size" : 6,
    "source" : "source",
    "type" : "type",
    "ip_type" : "ip_type"
  } ],
  "meta" : {
    "total" : 0,
    "links" : {
      "next" : "next",
      "prev" : "prev"
    }
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * List Firewall Groups
 * Get a list of all Firewall Groups.
 *
 * per_page Integer Number of items requested per page. Default is 100 and Max is 500. (optional)
 * cursor String Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination). (optional)
 * returns inline_response_200_18
 **/
exports.listFirewallGroups = function(per_page,cursor) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "firewall_groups" : [ {
    "date_modified" : "date_modified",
    "date_created" : "date_created",
    "description" : "description",
    "id" : "id",
    "max_rule_count" : 1,
    "instance_count" : 0,
    "rule_count" : 6
  }, {
    "date_modified" : "date_modified",
    "date_created" : "date_created",
    "description" : "description",
    "id" : "id",
    "max_rule_count" : 1,
    "instance_count" : 0,
    "rule_count" : 6
  } ],
  "meta" : {
    "total" : 0,
    "links" : {
      "next" : "next",
      "prev" : "prev"
    }
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Create Firewall Rules
 * Create a Firewall Rule for a Firewall Group. The attributes `ip_type`, `protocol`, `subnet`, and `subnet_size` are required.
 *
 * body Firewallgroupid_rules_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * firewallGroupId String The [Firewall Group id](#operation/list-firewall-groups).
 * returns inline_response_201_1
 **/
exports.postFirewallsFirewallGroupIdRules = function(body,firewallGroupId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "firewall_rule" : {
    "subnet" : "subnet",
    "protocol" : "protocol",
    "notes" : "notes",
    "port" : "port",
    "action" : "action",
    "id" : 0,
    "subnet_size" : 6,
    "source" : "source",
    "type" : "type",
    "ip_type" : "ip_type"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Update Firewall Group
 * Update information for a Firewall Group.
 *
 * body Firewalls_firewallgroupid_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * firewallGroupId String The [Firewall Group id](#operation/list-firewall-groups).
 * no response value expected for this operation
 **/
exports.updateFirewallGroup = function(body,firewallGroupId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

