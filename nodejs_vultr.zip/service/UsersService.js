'use strict';


/**
 * Create User
 * Create a new User. The `email`, `name`, and `password` attributes are required.
 *
 * body Users_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * returns user
 **/
exports.createUser = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "user" : {
    "password" : "password",
    "acls" : [ "acls", "acls" ],
    "api_enabled" : true,
    "name" : "name",
    "id" : "id",
    "email" : "email"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Delete User
 * Delete a User.
 *
 * userId String The [User id](#operation/list-users).
 * no response value expected for this operation
 **/
exports.deleteUser = function(userId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Get User
 * Get information about a User.
 *
 * userId String The [User id](#operation/list-users).
 * returns user
 **/
exports.getUser = function(userId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "user" : {
    "password" : "password",
    "acls" : [ "acls", "acls" ],
    "api_enabled" : true,
    "name" : "name",
    "id" : "id",
    "email" : "email"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Get Users
 * Get a list of all Users in your account.
 *
 * per_page BigDecimal Number of items requested per page. Default is 100 and Max is 500. (optional)
 * cursor String Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination). (optional)
 * returns inline_response_200_4
 **/
exports.listUsers = function(per_page,cursor) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "meta" : {
    "total" : 0,
    "links" : {
      "next" : "next",
      "prev" : "prev"
    }
  },
  "users" : [ {
    "user" : {
      "password" : "password",
      "acls" : [ "acls", "acls" ],
      "api_enabled" : true,
      "name" : "name",
      "id" : "id",
      "email" : "email"
    }
  }, {
    "user" : {
      "password" : "password",
      "acls" : [ "acls", "acls" ],
      "api_enabled" : true,
      "name" : "name",
      "id" : "id",
      "email" : "email"
    }
  } ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Update User
 * Update information for a User. All attributes are optional. If not set, the attributes will retain their original values.
 *
 * body Users_userid_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * userId String The [User id](#operation/list-users).
 * no response value expected for this operation
 **/
exports.updateUser = function(body,userId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

