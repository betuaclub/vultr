'use strict';


/**
 * Create a Private Network
 * Create a new Private Network in a `region`.  **Deprecated**: Use [Create VPC](#operation/create-vpc) instead.      Private networks should use [RFC1918 private address space](https://tools.ietf.org/html/rfc1918):      10.0.0.0    - 10.255.255.255  (10/8 prefix)     172.16.0.0  - 172.31.255.255  (172.16/12 prefix)     192.168.0.0 - 192.168.255.255 (192.168/16 prefix) 
 *
 * body Privatenetworks_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * returns inline_response_200
 **/
exports.createNetwork = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "network" : {
    "date_created" : "date_created",
    "v4_subnet_mask" : 0,
    "description" : "description",
    "v4_subnet" : "v4_subnet",
    "id" : "id",
    "region" : "region"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Delete a private network
 * Delete a Private Network.<br><br>**Deprecated**: Use [Delete VPC](#operation/delete-vpc) instead.
 *
 * networkId String The [Network id](#operation/list-networks).
 * no response value expected for this operation
 **/
exports.deleteNetwork = function(networkId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Get a private network
 * Get information about a Private Network.<br><br>**Deprecated**: Use [Get VPC](#operation/get-vpc) instead. 
 *
 * networkId String The [Network id](#operation/list-networks).
 * returns inline_response_200
 **/
exports.getNetwork = function(networkId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "network" : {
    "date_created" : "date_created",
    "v4_subnet_mask" : 0,
    "description" : "description",
    "v4_subnet" : "v4_subnet",
    "id" : "id",
    "region" : "region"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * List Private Networks
 * Get a list of all Private Networks in your account.<br><br>**Deprecated**: Use [List VPCs](#operation/list-vpcs) instead.
 *
 * per_page Integer Number of items requested per page. Default is 100 and Max is 500. (optional)
 * cursor String Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination). (optional)
 * returns inline_response_200_1
 **/
exports.listNetworks = function(per_page,cursor) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "meta" : {
    "total" : 0,
    "links" : {
      "next" : "next",
      "prev" : "prev"
    }
  },
  "networks" : [ {
    "date_created" : "date_created",
    "v4_subnet_mask" : 0,
    "description" : "description",
    "v4_subnet" : "v4_subnet",
    "id" : "id",
    "region" : "region"
  }, {
    "date_created" : "date_created",
    "v4_subnet_mask" : 0,
    "description" : "description",
    "v4_subnet" : "v4_subnet",
    "id" : "id",
    "region" : "region"
  } ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Update a Private Network
 * Update information for a Private Network.<br><br>**Deprecated**: Use [Update VPC](#operation/update-vpc) instead.
 *
 * body Privatenetworks_networkid_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * networkId String The [Network id](#operation/list-networks).
 * no response value expected for this operation
 **/
exports.updateNetwork = function(body,networkId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

