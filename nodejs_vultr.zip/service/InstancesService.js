'use strict';


/**
 * Attach ISO to Instance
 * Attach an ISO to an Instance.
 *
 * body Iso_attach_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * instanceId String 
 * returns inline_response_202_5
 **/
exports.attachInstanceIso = function(body,instanceId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "iso_status" : {
    "iso_id" : "iso_id",
    "state" : "state"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Attach Private Network to Instance
 * Attach Private Network to an Instance.<br><br>**Deprecated**: use [Attach VPC to Instance](#operation/attach-instance-vpc) instead.
 *
 * body Privatenetworks_attach_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * instanceId String The [Instance ID](#operation/list-instances).
 * no response value expected for this operation
 **/
exports.attachInstanceNetwork = function(body,instanceId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Attach VPC to Instance
 * Attach a VPC to an Instance.
 *
 * body Vpcs_attach_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * instanceId String The [Instance ID](#operation/list-instances).
 * no response value expected for this operation
 **/
exports.attachInstanceVpc = function(body,instanceId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Create Instance
 * Create a new VPS Instance in a `region` with the desired `plan`. Choose one of the following to deploy the instance:  * `os_id` * `iso_id` * `snapshot_id` * `app_id` * `image_id`  Supply other attributes as desired.
 *
 * body Instances_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * returns inline_response_202_4
 **/
exports.createInstance = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "instance" : {
    "firewall_group_id" : "firewall_group_id",
    "os_id" : 2,
    "server_status" : "server_status",
    "internal_ip" : "internal_ip",
    "allowed_bandwidth" : 5,
    "features" : [ "features", "features" ],
    "hostname" : "hostname",
    "vcpu_count" : 1,
    "id" : "id",
    "tag" : "tag",
    "app_id" : 7,
    "plan" : "plan",
    "netmask_v4" : "netmask_v4",
    "ram" : 0,
    "gateway_v4" : "gateway_v4",
    "kvm" : "kvm",
    "os" : "os",
    "main_ip" : "main_ip",
    "power_status" : "power_status",
    "date_created" : "date_created",
    "default_password" : "default_password",
    "label" : "label",
    "tags" : [ "tags", "tags" ],
    "disk" : 6,
    "v6_networks" : [ {
      "network_size" : 5,
      "main_ip" : "main_ip",
      "network" : "network"
    }, {
      "network_size" : 5,
      "main_ip" : "main_ip",
      "network" : "network"
    } ],
    "region" : "region",
    "image_id" : "image_id",
    "status" : "status"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Set Instance Backup Schedule
 * Set the backup schedule for an Instance in UTC. The `type` is required.
 *
 * body Instanceid_backupschedule_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * instanceId String The [Instance ID](#operation/list-instances).
 * no response value expected for this operation
 **/
exports.createInstanceBackupSchedule = function(body,instanceId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Create IPv4
 * Create an IPv4 address for an Instance.
 *
 * body Instanceid_ipv4_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * instanceId String The [Instance ID](#operation/list-instances).
 * returns Object
 **/
exports.createInstanceIpv4 = function(body,instanceId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = { };
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Create Instance Reverse IPv4
 * Create a reverse IPv4 entry for an Instance. The `ip` and `reverse` attributes are required. 
 *
 * body Ipv4_reverse_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * instanceId String The [Instance ID](#operation/list-instances).
 * no response value expected for this operation
 **/
exports.createInstanceReverseIpv4 = function(body,instanceId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Create Instance Reverse IPv6
 * Create a reverse IPv6 entry for an Instance. The `ip` and `reverse` attributes are required. IP address must be in full, expanded format.
 *
 * body Ipv6_reverse_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * instanceId String The [Instance ID](#operation/list-instances).
 * no response value expected for this operation
 **/
exports.createInstanceReverseIpv6 = function(body,instanceId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Delete Instance
 * Delete an Instance.
 *
 * instanceId String The [Instance ID](#operation/list-instances).
 * no response value expected for this operation
 **/
exports.deleteInstance = function(instanceId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Delete IPv4 Address
 * Delete an IPv4 address from an Instance.
 *
 * instanceId String The [Instance ID](#operation/list-instances).
 * ipv4 String The IPv4 address.
 * no response value expected for this operation
 **/
exports.deleteInstanceIpv4 = function(instanceId,ipv4) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Delete Instance Reverse IPv6
 * Delete the reverse IPv6 for an Instance.
 *
 * instanceId String The [Instance ID](#operation/list-instances).
 * ipv6 String The IPv6 address.
 * no response value expected for this operation
 **/
exports.deleteInstanceReverseIpv6 = function(instanceId,ipv6) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Detach ISO from instance
 * Detach the ISO from an Instance.
 *
 * instanceId String The [Instance ID](#operation/list-instances).
 * returns inline_response_202_6
 **/
exports.detachInstanceIso = function(instanceId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "iso_status" : {
    "state" : "state"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Detach Private Network from Instance.
 * Detach Private Network from an Instance.<br><br>**Deprecated**: use [Detach VPC from Instance](#operation/detach-instance-vpc) instead.
 *
 * body Privatenetworks_detach_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * instanceId String The [Instance ID](#operation/list-instances).
 * no response value expected for this operation
 **/
exports.detachInstanceNetwork = function(body,instanceId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Detach VPC from Instance
 * Detach a VPC from an Instance.
 *
 * body Vpcs_detach_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * instanceId String The [Instance ID](#operation/list-instances).
 * no response value expected for this operation
 **/
exports.detachInstanceVpc = function(body,instanceId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Get Instance
 * Get information about an Instance.
 *
 * instanceId String The [Instance ID](#operation/list-instances).
 * returns inline_response_202_4
 **/
exports.getInstance = function(instanceId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "instance" : {
    "firewall_group_id" : "firewall_group_id",
    "os_id" : 2,
    "server_status" : "server_status",
    "internal_ip" : "internal_ip",
    "allowed_bandwidth" : 5,
    "features" : [ "features", "features" ],
    "hostname" : "hostname",
    "vcpu_count" : 1,
    "id" : "id",
    "tag" : "tag",
    "app_id" : 7,
    "plan" : "plan",
    "netmask_v4" : "netmask_v4",
    "ram" : 0,
    "gateway_v4" : "gateway_v4",
    "kvm" : "kvm",
    "os" : "os",
    "main_ip" : "main_ip",
    "power_status" : "power_status",
    "date_created" : "date_created",
    "default_password" : "default_password",
    "label" : "label",
    "tags" : [ "tags", "tags" ],
    "disk" : 6,
    "v6_networks" : [ {
      "network_size" : 5,
      "main_ip" : "main_ip",
      "network" : "network"
    }, {
      "network_size" : 5,
      "main_ip" : "main_ip",
      "network" : "network"
    } ],
    "region" : "region",
    "image_id" : "image_id",
    "status" : "status"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Get Instance Backup Schedule
 * Get the backup schedule for an Instance.
 *
 * instanceId String The [Instance ID](#operation/list-instances).
 * returns inline_response_200_47
 **/
exports.getInstanceBackupSchedule = function(instanceId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "backup_schedule" : {
    "dom" : 1,
    "hour" : 0,
    "next_scheduled_time_utc" : "next_scheduled_time_utc",
    "type" : "type",
    "dow" : 6,
    "enabled" : true
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Instance Bandwidth
 * Get bandwidth information about an Instance.<br><br>The `bandwidth` object in a successful response contains objects representing a day in the month. The date is denoted by the nested object keys. Days begin and end in the UTC timezone. The bandwidth utilization data contained within the date object is refreshed periodically. We do not recommend using this endpoint to gather real-time metrics.
 *
 * instanceId String The [Instance ID](#operation/list-instances).
 * returns inline_response_200_40
 **/
exports.getInstanceBandwidth = function(instanceId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bandwidth" : {
    "2020-10-10" : {
      "incoming_bytes" : 0,
      "outgoing_bytes" : 6
    }
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * List Instance IPv4 Information
 * List the IPv4 information for an Instance.
 *
 * instanceId String The [Instance ID](#operation/list-instances).
 * public_network Boolean If `true`, includes information about the public network adapter (such as MAC address) with the `main_ip` entry. (optional)
 * per_page Integer Number of items requested per page. Default is 100 and Max is 500.  (optional)
 * cursor String Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination). (optional)
 * returns inline_response_200_38
 **/
exports.getInstanceIpv4 = function(instanceId,public_network,per_page,cursor) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "ipv4s" : [ {
    "netmask" : "netmask",
    "mac_address" : "mac_address",
    "ip" : "ip",
    "type" : "type",
    "reverse" : "reverse",
    "gateway" : "gateway"
  }, {
    "netmask" : "netmask",
    "mac_address" : "mac_address",
    "ip" : "ip",
    "type" : "type",
    "reverse" : "reverse",
    "gateway" : "gateway"
  } ],
  "meta" : {
    "total" : 0,
    "links" : {
      "next" : "next",
      "prev" : "prev"
    }
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Get Instance IPv6 Information
 * Get the IPv6 information for an VPS Instance.
 *
 * instanceId String The [Instance ID](#operation/list-instances).
 * returns inline_response_200_39
 **/
exports.getInstanceIpv6 = function(instanceId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "ipv6s" : [ {
    "network_size" : 0,
    "ip" : "ip",
    "type" : "type",
    "network" : "network"
  }, {
    "network_size" : 0,
    "ip" : "ip",
    "type" : "type",
    "network" : "network"
  } ],
  "meta" : {
    "total" : 0,
    "links" : {
      "next" : "next",
      "prev" : "prev"
    }
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Get Instance ISO Status
 * Get the ISO status for an Instance.
 *
 * instanceId String The [Instance ID](#operation/list-instances).
 * returns inline_response_200_46
 **/
exports.getInstanceIsoStatus = function(instanceId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "iso_status" : {
    "iso_id" : "iso_id",
    "state" : "state"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Get Instance neighbors
 * Get a list of other instances in the same location as this Instance.
 *
 * instanceId String The [Instance ID](#operation/list-instances).
 * returns inline_response_200_43
 **/
exports.getInstanceNeighbors = function(instanceId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "neighbors" : [ "neighbors", "neighbors" ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Get Available Instance Upgrades
 * Get available upgrades for an Instance
 *
 * instanceId String The [Instance ID](#operation/list-instances).
 * type String Filter upgrade by type:  - all (applications, os, plans) - applications - os - plans (optional)
 * returns inline_response_200_51
 **/
exports.getInstanceUpgrades = function(instanceId,type) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "upgrades" : {
    "os" : [ "", "" ],
    "plans" : [ "", "" ],
    "applications" : [ "", "" ]
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Get Instance User Data
 * Get the user-supplied, base64 encoded [user data](https://www.vultr.com/docs/manage-instance-user-data-with-the-vultr-metadata-api/) for an Instance.
 *
 * instanceId String The [Instance ID](#operation/list-instances).
 * returns inline_response_200_50
 **/
exports.getInstanceUserdata = function(instanceId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "user_data" : {
    "data" : "data"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Halt Instance
 * Halt an Instance.
 *
 * instanceId String The [Instance ID](#operation/list-instances).
 * no response value expected for this operation
 **/
exports.haltInstance = function(instanceId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Halt Instances
 * Halt Instances.
 *
 * body Instances_halt_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * no response value expected for this operation
 **/
exports.haltInstances = function(body) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * List Instance IPv6 Reverse
 * List the reverse IPv6 information for an Instance.
 *
 * instanceId String The [Instance ID](#operation/list-instances).
 * returns inline_response_200_48
 **/
exports.listInstanceIpv6Reverse = function(instanceId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "reverse_ipv6s" : [ {
    "ip" : "ip",
    "reverse" : "reverse"
  }, {
    "ip" : "ip",
    "reverse" : "reverse"
  } ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * List instance Private Networks
 * **Deprecated**: use [List Instance VPCs](#operation/list-instance-vpcs) instead.<br><br>List the private networks for an Instance.
 *
 * instanceId String The [Instance ID](#operation/list-instances).
 * per_page Integer Number of items requested per page. Default is 100 and Max is 500. (optional)
 * cursor String Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination). (optional)
 * returns inline_response_200_44
 **/
exports.listInstancePrivateNetworks = function(instanceId,per_page,cursor) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "meta" : {
    "total" : 0,
    "links" : {
      "next" : "next",
      "prev" : "prev"
    }
  },
  "private_networks" : [ {
    "mac_address" : "mac_address",
    "id" : "id",
    "ip_address" : "ip_address"
  }, {
    "mac_address" : "mac_address",
    "id" : "id",
    "ip_address" : "ip_address"
  } ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * List instance VPCs
 * List the VPCs for an Instance.
 *
 * instanceId String The [Instance ID](#operation/list-instances).
 * per_page Integer Number of items requested per page. Default is 100 and Max is 500. (optional)
 * cursor String Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination). (optional)
 * returns inline_response_200_45
 **/
exports.listInstanceVpcs = function(instanceId,per_page,cursor) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "meta" : {
    "total" : 0,
    "links" : {
      "next" : "next",
      "prev" : "prev"
    }
  },
  "private_networks" : [ {
    "date_created" : "date_created",
    "v4_subnet_mask" : 0,
    "description" : "description",
    "v4_subnet" : "v4_subnet",
    "id" : "id",
    "region" : "region"
  }, {
    "date_created" : "date_created",
    "v4_subnet_mask" : 0,
    "description" : "description",
    "v4_subnet" : "v4_subnet",
    "id" : "id",
    "region" : "region"
  } ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * List Instances
 * List all VPS instances in your account.
 *
 * per_page Integer Number of items requested per page. Default is 100 and Max is 500. (optional)
 * cursor String Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination). (optional)
 * tag String Filter by specific tag. (optional)
 * label String Filter by label. (optional)
 * main_ip String Filter by main ip address. (optional)
 * region String Filter by [Region id](#operation/list-regions). (optional)
 * returns inline_response_200_42
 **/
exports.listInstances = function(per_page,cursor,tag,label,main_ip,region) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "instances" : [ {
    "firewall_group_id" : "firewall_group_id",
    "os_id" : 2,
    "server_status" : "server_status",
    "internal_ip" : "internal_ip",
    "allowed_bandwidth" : 5,
    "features" : [ "features", "features" ],
    "hostname" : "hostname",
    "vcpu_count" : 1,
    "id" : "id",
    "tag" : "tag",
    "app_id" : 7,
    "plan" : "plan",
    "netmask_v4" : "netmask_v4",
    "ram" : 0,
    "gateway_v4" : "gateway_v4",
    "kvm" : "kvm",
    "os" : "os",
    "main_ip" : "main_ip",
    "power_status" : "power_status",
    "date_created" : "date_created",
    "default_password" : "default_password",
    "label" : "label",
    "tags" : [ "tags", "tags" ],
    "disk" : 6,
    "v6_networks" : [ {
      "network_size" : 5,
      "main_ip" : "main_ip",
      "network" : "network"
    }, {
      "network_size" : 5,
      "main_ip" : "main_ip",
      "network" : "network"
    } ],
    "region" : "region",
    "image_id" : "image_id",
    "status" : "status"
  }, {
    "firewall_group_id" : "firewall_group_id",
    "os_id" : 2,
    "server_status" : "server_status",
    "internal_ip" : "internal_ip",
    "allowed_bandwidth" : 5,
    "features" : [ "features", "features" ],
    "hostname" : "hostname",
    "vcpu_count" : 1,
    "id" : "id",
    "tag" : "tag",
    "app_id" : 7,
    "plan" : "plan",
    "netmask_v4" : "netmask_v4",
    "ram" : 0,
    "gateway_v4" : "gateway_v4",
    "kvm" : "kvm",
    "os" : "os",
    "main_ip" : "main_ip",
    "power_status" : "power_status",
    "date_created" : "date_created",
    "default_password" : "default_password",
    "label" : "label",
    "tags" : [ "tags", "tags" ],
    "disk" : 6,
    "v6_networks" : [ {
      "network_size" : 5,
      "main_ip" : "main_ip",
      "network" : "network"
    }, {
      "network_size" : 5,
      "main_ip" : "main_ip",
      "network" : "network"
    } ],
    "region" : "region",
    "image_id" : "image_id",
    "status" : "status"
  } ],
  "meta" : {
    "total" : 0,
    "links" : {
      "next" : "next",
      "prev" : "prev"
    }
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Set Default Reverse DNS Entry
 * Set a reverse DNS entry for an IPv4 address
 *
 * body Reverse_default_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * instanceId String The [Instance ID](#operation/list-instances).
 * no response value expected for this operation
 **/
exports.postInstancesInstanceIdIpv4ReverseDefault = function(body,instanceId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Reboot Instance
 * Reboot an Instance.
 *
 * instanceId String The [Instance ID](#operation/list-instances).
 * no response value expected for this operation
 **/
exports.rebootInstance = function(instanceId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Reboot instances
 * Reboot Instances.
 *
 * body Instances_reboot_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * no response value expected for this operation
 **/
exports.rebootInstances = function(body) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Reinstall Instance
 * Reinstall an Instance using an optional `hostname`.  **Note:** This action may take a few extra seconds to complete.
 *
 * body Instanceid_reinstall_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * instanceId String The [Instance ID](#operation/list-instances).
 * returns inline_response_202_4
 **/
exports.reinstallInstance = function(body,instanceId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "instance" : {
    "firewall_group_id" : "firewall_group_id",
    "os_id" : 2,
    "server_status" : "server_status",
    "internal_ip" : "internal_ip",
    "allowed_bandwidth" : 5,
    "features" : [ "features", "features" ],
    "hostname" : "hostname",
    "vcpu_count" : 1,
    "id" : "id",
    "tag" : "tag",
    "app_id" : 7,
    "plan" : "plan",
    "netmask_v4" : "netmask_v4",
    "ram" : 0,
    "gateway_v4" : "gateway_v4",
    "kvm" : "kvm",
    "os" : "os",
    "main_ip" : "main_ip",
    "power_status" : "power_status",
    "date_created" : "date_created",
    "default_password" : "default_password",
    "label" : "label",
    "tags" : [ "tags", "tags" ],
    "disk" : 6,
    "v6_networks" : [ {
      "network_size" : 5,
      "main_ip" : "main_ip",
      "network" : "network"
    }, {
      "network_size" : 5,
      "main_ip" : "main_ip",
      "network" : "network"
    } ],
    "region" : "region",
    "image_id" : "image_id",
    "status" : "status"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Restore Instance
 * Restore an Instance from either `backup_id` or `snapshot_id`.
 *
 * body Instanceid_restore_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * instanceId String The [Instance ID](#operation/list-instances).
 * returns inline_response_202_7
 **/
exports.restoreInstance = function(body,instanceId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "status" : {
    "restore_id" : "restore_id",
    "restore_type" : "restore_type",
    "status" : "status"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Start instance
 * Start an Instance.
 *
 * instanceId String The [Instance ID](#operation/list-instances).
 * no response value expected for this operation
 **/
exports.startInstance = function(instanceId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Start instances
 * Start Instances.
 *
 * body Instances_start_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * no response value expected for this operation
 **/
exports.startInstances = function(body) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Update Instance
 * Update information for an Instance. All attributes are optional. If not set, the attributes will retain their original values.  **Note:** Changing `os_id`, `app_id` or `image_id` may take a few extra seconds to complete.
 *
 * body Instances_instanceid_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * instanceId String The [Instance ID](#operation/list-instances).
 * returns inline_response_202_4
 **/
exports.updateInstance = function(body,instanceId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "instance" : {
    "firewall_group_id" : "firewall_group_id",
    "os_id" : 2,
    "server_status" : "server_status",
    "internal_ip" : "internal_ip",
    "allowed_bandwidth" : 5,
    "features" : [ "features", "features" ],
    "hostname" : "hostname",
    "vcpu_count" : 1,
    "id" : "id",
    "tag" : "tag",
    "app_id" : 7,
    "plan" : "plan",
    "netmask_v4" : "netmask_v4",
    "ram" : 0,
    "gateway_v4" : "gateway_v4",
    "kvm" : "kvm",
    "os" : "os",
    "main_ip" : "main_ip",
    "power_status" : "power_status",
    "date_created" : "date_created",
    "default_password" : "default_password",
    "label" : "label",
    "tags" : [ "tags", "tags" ],
    "disk" : 6,
    "v6_networks" : [ {
      "network_size" : 5,
      "main_ip" : "main_ip",
      "network" : "network"
    }, {
      "network_size" : 5,
      "main_ip" : "main_ip",
      "network" : "network"
    } ],
    "region" : "region",
    "image_id" : "image_id",
    "status" : "status"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

