'use strict';


/**
 * List Bare Metal Plans
 * Get a list of all Bare Metal plans at Vultr.  The response is an array of JSON `plan` objects, with unique `id` with sub-fields in the general format of:    <type>-<number of cores>-<memory size>-<optional modifier>  For example: `vc2-24c-96gb-sc1`  More about the sub-fields:  * `<type>`: The Vultr type code. For example, `vc2`, `vhf`, `vdc`, etc. * `<number of cores>`: The number of cores, such as `4c` for \"4 cores\", `8c` for \"8 cores\", etc. * `<memory size>`: Size in GB, such as `32gb`. * `<optional modifier>`: Some plans include a modifier for internal identification purposes, such as CPU type or location surcharges.  > Note: This information about plan id format is for general education. Vultr may change the sub-field format or values at any time. You should not attempt to parse the plan ID sub-fields in your code for any specific purpose. 
 *
 * per_page String Number of items requested per page. Default is 100 and Max is 500. (optional)
 * cursor String Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination). (optional)
 * returns inline_response_200_35
 **/
exports.listMetalPlans = function(per_page,cursor) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "plans" : [ {
    "disk" : "disk",
    "monthly_cost" : 5,
    "bandwidth" : 5,
    "cpu_model" : "cpu_model",
    "locations" : [ "locations", "locations" ],
    "disk_count" : 2,
    "id" : "id",
    "cpu_threads" : 6,
    "type" : "type",
    "cpu_count" : 0,
    "ram" : 1
  }, {
    "disk" : "disk",
    "monthly_cost" : 5,
    "bandwidth" : 5,
    "cpu_model" : "cpu_model",
    "locations" : [ "locations", "locations" ],
    "disk_count" : 2,
    "id" : "id",
    "cpu_threads" : 6,
    "type" : "type",
    "cpu_count" : 0,
    "ram" : 1
  } ],
  "meta" : {
    "total" : 0,
    "links" : {
      "next" : "next",
      "prev" : "prev"
    }
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * List Plans
 * Get a list of all VPS plans at Vultr.  The response is an array of JSON `plan` objects, with unique `id` with sub-fields in the general format of:    <type>-<number of cores>-<memory size>-<optional modifier>  For example: `vc2-24c-96gb-sc1`  More about the sub-fields:  * `<type>`: The Vultr type code. For example, `vc2`, `vhf`, `vdc`, etc. * `<number of cores>`: The number of cores, such as `4c` for \"4 cores\", `8c` for \"8 cores\", etc. * `<memory size>`: Size in GB, such as `32gb`. * `<optional modifier>`: Some plans include a modifier for internal identification purposes, such as CPU type or location surcharges.  > Note: This information about plan id format is for general education. Vultr may change the sub-field format or values at any time. You should not attempt to parse the plan ID sub-fields in your code for any specific purpose. 
 *
 * type String Filter the results by type.  | **Type** | **Description** | |----------|-----------------| | all | All available types | | vc2 | Cloud Compute | | vdc | Dedicated Cloud | | vhf | High Frequency Compute | | vhp | High Performance | | voc | All Optimized Cloud types | | voc-g | General Purpose Optimized Cloud | | voc-c | CPU Optimized Cloud | | voc-m | Memory Optimized Cloud | | voc-s | Storage Optimized Cloud | | vcg | Cloud GPU | (optional)
 * per_page Integer Number of items requested per page. Default is 100 and Max is 500. (optional)
 * cursor String Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination). (optional)
 * os String Filter the results by operating system.  |   | Type | Description | | - | ------ | ------------- | |   | windows | All available plans that support windows | (optional)
 * returns inline_response_200_34
 **/
exports.listPlans = function(type,per_page,cursor,os) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "plans" : [ {
    "disk" : 1,
    "vcpu_count" : 0,
    "monthly_cost" : 5,
    "bandwidth" : 5,
    "name" : "name",
    "locations" : [ "locations", "locations" ],
    "disk_count" : 2,
    "id" : "id",
    "type" : "type",
    "ram" : 6
  }, {
    "disk" : 1,
    "vcpu_count" : 0,
    "monthly_cost" : 5,
    "bandwidth" : 5,
    "name" : "name",
    "locations" : [ "locations", "locations" ],
    "disk_count" : 2,
    "id" : "id",
    "type" : "type",
    "ram" : 6
  } ],
  "meta" : {
    "total" : 0,
    "links" : {
      "next" : "next",
      "prev" : "prev"
    }
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

