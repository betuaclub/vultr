'use strict';


/**
 * Create ISO
 * Create a new ISO in your account from `url`.
 *
 * body Iso_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * returns inline_response_201_2
 **/
exports.createIso = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "iso" : {
    "sha512sum" : "sha512sum",
    "filename" : "filename",
    "size" : 0,
    "date_created" : "date_created",
    "md5sum" : "md5sum",
    "id" : "id",
    "status" : "status"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Delete ISO
 * Delete an ISO.
 *
 * isoId String The [ISO id](#operation/list-isos).
 * no response value expected for this operation
 **/
exports.deleteIso = function(isoId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Get ISO
 * Get information for an ISO.
 *
 * isoId String The [ISO id](#operation/list-isos).
 * returns inline_response_201_2
 **/
exports.isoGet = function(isoId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "iso" : {
    "sha512sum" : "sha512sum",
    "filename" : "filename",
    "size" : 0,
    "date_created" : "date_created",
    "md5sum" : "md5sum",
    "id" : "id",
    "status" : "status"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * List ISOs
 * Get the ISOs in your account.
 *
 * per_page Integer Number of items requested per page. Default is 100 and Max is 500. (optional)
 * cursor String Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination). (optional)
 * returns inline_response_200_20
 **/
exports.listIsos = function(per_page,cursor) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "meta" : {
    "total" : 0,
    "links" : {
      "next" : "next",
      "prev" : "prev"
    }
  },
  "isos" : [ {
    "sha512sum" : "sha512sum",
    "filename" : "filename",
    "size" : 0,
    "date_created" : "date_created",
    "md5sum" : "md5sum",
    "id" : "id",
    "status" : "status"
  }, {
    "sha512sum" : "sha512sum",
    "filename" : "filename",
    "size" : 0,
    "date_created" : "date_created",
    "md5sum" : "md5sum",
    "id" : "id",
    "status" : "status"
  } ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * List Public ISOs
 * List all Vultr Public ISOs.
 *
 * returns inline_response_200_21
 **/
exports.listPublicIsos = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "meta" : {
    "total" : 0,
    "links" : {
      "next" : "next",
      "prev" : "prev"
    }
  },
  "public_isos" : [ {
    "md5sum" : "md5sum",
    "name" : "name",
    "description" : "description",
    "id" : "id"
  }, {
    "md5sum" : "md5sum",
    "name" : "name",
    "description" : "description",
    "id" : "id"
  } ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

