'use strict';


/**
 * Create Snapshot
 * Create a new Snapshot for `instance_id`.
 *
 * body Snapshots_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * returns inline_response_200_9
 **/
exports.createSnapshot = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "snapshot" : {
    "size" : 0,
    "date_created" : "date_created",
    "os_id" : 6,
    "description" : "description",
    "id" : "id",
    "app_id" : 1,
    "status" : "status"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Create Snapshot from URL
 * Create a new Snapshot from a RAW image located at `url`.
 *
 * body Snapshots_createfromurl_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * returns inline_response_200_9
 **/
exports.createSnapshotCreateFromUrl = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "snapshot" : {
    "size" : 0,
    "date_created" : "date_created",
    "os_id" : 6,
    "description" : "description",
    "id" : "id",
    "app_id" : 1,
    "status" : "status"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Delete Snapshot
 * Delete a Snapshot.
 *
 * snapshotId String The [Snapshot id](#operation/list-snapshots).
 * no response value expected for this operation
 **/
exports.deleteSnapshot = function(snapshotId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Get Snapshot
 * Get information about a Snapshot.
 *
 * snapshotId String The [Snapshot id](#operation/list-snapshots).
 * returns inline_response_200_9
 **/
exports.getSnapshot = function(snapshotId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "snapshot" : {
    "size" : 0,
    "date_created" : "date_created",
    "os_id" : 6,
    "description" : "description",
    "id" : "id",
    "app_id" : 1,
    "status" : "status"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * List Snapshots
 * Get information about all Snapshots in your account.
 *
 * description String Filter the list of Snapshots by `description` (optional)
 * per_page Integer Number of items requested per page. Default is 100 and Max is 500. (optional)
 * cursor String Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination). (optional)
 * returns inline_response_200_10
 **/
exports.listSnapshots = function(description,per_page,cursor) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "snapshots" : [ {
    "size" : 0,
    "date_created" : "date_created",
    "os_id" : 6,
    "description" : "description",
    "id" : "id",
    "app_id" : 1,
    "status" : "status"
  }, {
    "size" : 0,
    "date_created" : "date_created",
    "os_id" : 6,
    "description" : "description",
    "id" : "id",
    "app_id" : 1,
    "status" : "status"
  } ],
  "meta" : {
    "total" : 0,
    "links" : {
      "next" : "next",
      "prev" : "prev"
    }
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Update Snapshot
 * Update the description for a Snapshot.
 *
 * body Snapshots_snapshotid_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * snapshotId String The [Snapshot id](#operation/list-snapshots).
 * no response value expected for this operation
 **/
exports.putSnapshotsSnapshotId = function(body,snapshotId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

