'use strict';


/**
 * Attach Block Storage
 * Attach Block Storage to Instance `instance_id`.
 *
 * body Blockid_attach_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * blockId String The [Block Storage id](#operation/list-blocks).
 * no response value expected for this operation
 **/
exports.attachBlock = function(body,blockId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Create Block Storage
 * Create new Block Storage in a `region` with a size of `size_gb`. Size may range between 10 and 40000 depending on the `block_type`.
 *
 * body Blocks_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * returns inline_response_202
 **/
exports.createBlock = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "block" : {
    "cost" : 0,
    "attached_to_instance" : "attached_to_instance",
    "date_created" : "date_created",
    "size_gb" : 6,
    "id" : "id",
    "label" : "label",
    "region" : "region",
    "mount_id" : "mount_id",
    "status" : "status"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Delete Block Storage
 * Delete Block Storage.
 *
 * blockId String The [Block Storage id](#operation/list-blocks).
 * no response value expected for this operation
 **/
exports.deleteBlock = function(blockId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Detach Block Storage
 * Detach Block Storage.
 *
 * body Blockid_detach_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * blockId String The [Block Storage id](#operation/list-blocks).
 * no response value expected for this operation
 **/
exports.detachBlock = function(body,blockId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Get Block Storage
 * Get information for Block Storage.
 *
 * blockId String The [Block Storage id](#operation/list-blocks).
 * returns inline_response_202
 **/
exports.getBlock = function(blockId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "block" : {
    "cost" : 0,
    "attached_to_instance" : "attached_to_instance",
    "date_created" : "date_created",
    "size_gb" : 6,
    "id" : "id",
    "label" : "label",
    "region" : "region",
    "mount_id" : "mount_id",
    "status" : "status"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * List Block storages
 * List all Block Storage in your account.
 *
 * per_page Integer Number of items requested per page. Default is 100 and Max is 500. (optional)
 * cursor String Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination). (optional)
 * returns inline_response_200_17
 **/
exports.listBlocks = function(per_page,cursor) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "blocks" : [ {
    "cost" : 0,
    "attached_to_instance" : "attached_to_instance",
    "date_created" : "date_created",
    "size_gb" : 6,
    "id" : "id",
    "label" : "label",
    "region" : "region",
    "mount_id" : "mount_id",
    "status" : "status"
  }, {
    "cost" : 0,
    "attached_to_instance" : "attached_to_instance",
    "date_created" : "date_created",
    "size_gb" : 6,
    "id" : "id",
    "label" : "label",
    "region" : "region",
    "mount_id" : "mount_id",
    "status" : "status"
  } ],
  "meta" : {
    "total" : 0,
    "links" : {
      "next" : "next",
      "prev" : "prev"
    }
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Update Block Storage
 * Update information for Block Storage. 
 *
 * body Blocks_blockid_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * blockId String The [Block Storage id](#operation/list-blocks).
 * no response value expected for this operation
 **/
exports.updateBlock = function(body,blockId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

