'use strict';


/**
 * Get Invoice
 * Retrieve specified invoice
 *
 * invoiceId String ID of invoice
 * returns inline_response_200_62
 **/
exports.getInvoice = function(invoiceId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "billing_invoice" : {
    "date" : "date",
    "amount" : 6.027456183070403,
    "balance" : 1.4658129805029452,
    "description" : "description",
    "id" : 0
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Get Invoice Items
 * Retrieve full specified invoice
 *
 * invoiceId String ID of invoice
 * returns inline_response_200_63
 **/
exports.getInvoiceItems = function(invoiceId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "invoice_items" : [ {
    "end_date" : "end_date",
    "product" : "product",
    "total" : 1.4658129805029452,
    "description" : "description",
    "units" : 0.8008281904610115,
    "unit_type" : "unit_type",
    "unit_price" : 6.027456183070403,
    "start_date" : "start_date"
  }, {
    "end_date" : "end_date",
    "product" : "product",
    "total" : 1.4658129805029452,
    "description" : "description",
    "units" : 0.8008281904610115,
    "unit_type" : "unit_type",
    "unit_price" : 6.027456183070403,
    "start_date" : "start_date"
  } ],
  "meta" : {
    "total" : 5.962133916683182,
    "links" : {
      "next" : "next",
      "prev" : "prev"
    }
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * List Billing History
 * Retrieve list of billing history
 *
 * returns inline_response_200_60
 **/
exports.listBillingHistory = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "billing_history" : [ {
    "date" : "date",
    "amount" : 6.027456183070403,
    "balance" : 1.4658129805029452,
    "description" : "description",
    "id" : 0.8008281904610115,
    "type" : "type"
  }, {
    "date" : "date",
    "amount" : 6.027456183070403,
    "balance" : 1.4658129805029452,
    "description" : "description",
    "id" : 0.8008281904610115,
    "type" : "type"
  } ],
  "meta" : {
    "total" : 0,
    "links" : {
      "next" : "next",
      "prev" : "prev"
    }
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * List Invoices
 * Retrieve a list of invoices
 *
 * returns inline_response_200_61
 **/
exports.listInvoices = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "meta" : {
    "total" : 0,
    "links" : {
      "next" : "next",
      "prev" : "prev"
    }
  },
  "billing_invoices" : [ {
    "date" : "date",
    "amount" : 6.027456183070403,
    "balance" : 1.4658129805029452,
    "description" : "description",
    "id" : 0
  }, {
    "date" : "date",
    "amount" : 6.027456183070403,
    "balance" : 1.4658129805029452,
    "description" : "description",
    "id" : 0
  } ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

