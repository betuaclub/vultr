'use strict';


/**
 * Create DNS Domain
 * Create a DNS Domain for `domain`. If no `ip` address is supplied a domain with no records will be created.
 *
 * body Domains_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * returns inline_response_200_25
 **/
exports.createDnsDomain = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "domain" : {
    "date_created" : "date_created",
    "domain" : "domain",
    "dns_sec" : "dns_sec"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Create Record
 * Create a DNS record.
 *
 * body Dnsdomain_records_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * dnsDomain String The [DNS Domain](#operation/list-dns-domains).
 * returns inline_response_201_4
 **/
exports.createDnsDomainRecord = function(body,dnsDomain) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "record" : {
    "data" : "data",
    "name" : "name",
    "id" : "id",
    "type" : "type",
    "priority" : 0,
    "ttl" : 6
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Delete Domain
 * Delete the DNS Domain.
 *
 * dnsDomain String The [DNS Domain](#operation/list-dns-domains).
 * no response value expected for this operation
 **/
exports.deleteDnsDomain = function(dnsDomain) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Delete Record
 * Delete the DNS record.
 *
 * dnsDomain String The [DNS Domain](#operation/list-dns-domains).
 * recordId String The [DNS Record id](#operation/list-dns-domain-records).
 * no response value expected for this operation
 **/
exports.deleteDnsDomainRecord = function(dnsDomain,recordId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Get DNS Domain
 * Get information for the DNS Domain.
 *
 * dnsDomain String The [DNS Domain](#operation/list-dns-domains).
 * returns inline_response_200_25
 **/
exports.getDnsDomain = function(dnsDomain) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "domain" : {
    "date_created" : "date_created",
    "domain" : "domain",
    "dns_sec" : "dns_sec"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Get DNSSec Info
 * Get the DNSSEC information for the DNS Domain.
 *
 * dnsDomain String The [DNS Domain](#operation/list-dns-domains).
 * returns inline_response_200_27
 **/
exports.getDnsDomainDnssec = function(dnsDomain) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "dns_sec" : [ "dns_sec", "dns_sec" ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Get Record
 * Get information for a DNS Record.
 *
 * dnsDomain String The [DNS Domain](#operation/list-dns-domains).
 * recordId String The [DNS Record id](#operation/list-dns-domain-records).
 * returns inline_response_201_4
 **/
exports.getDnsDomainRecord = function(dnsDomain,recordId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "record" : {
    "data" : "data",
    "name" : "name",
    "id" : "id",
    "type" : "type",
    "priority" : 0,
    "ttl" : 6
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Get SOA information
 * Get SOA information for the DNS Domain.
 *
 * dnsDomain String The [DNS Domain](#operation/list-dns-domains).
 * returns inline_response_200_26
 **/
exports.getDnsDomainSoa = function(dnsDomain) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "dns_soa" : {
    "nsprimary" : "nsprimary",
    "email" : "email"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * List Records
 * Get the DNS records for the Domain.
 *
 * dnsDomain String The [DNS Domain](#operation/list-dns-domains).
 * per_page Integer Number of items requested per page. Default is 100 and Max is 500. (optional)
 * cursor String Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination). (optional)
 * returns inline_response_200_28
 **/
exports.listDnsDomainRecords = function(dnsDomain,per_page,cursor) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "records" : [ {
    "data" : "data",
    "name" : "name",
    "id" : "id",
    "type" : "type",
    "priority" : 0,
    "ttl" : 6
  }, {
    "data" : "data",
    "name" : "name",
    "id" : "id",
    "type" : "type",
    "priority" : 0,
    "ttl" : 6
  } ],
  "meta" : {
    "total" : 0,
    "links" : {
      "next" : "next",
      "prev" : "prev"
    }
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * List DNS Domains
 * List all DNS Domains in your account.
 *
 * per_page Integer Number of items requested per page. Default is 100 and Max is 500.  (optional)
 * cursor String Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination). (optional)
 * returns inline_response_200_24
 **/
exports.listDnsDomains = function(per_page,cursor) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "meta" : {
    "total" : 0,
    "links" : {
      "next" : "next",
      "prev" : "prev"
    }
  },
  "domains" : [ {
    "date_created" : "date_created",
    "domain" : "domain",
    "dns_sec" : "dns_sec"
  }, {
    "date_created" : "date_created",
    "domain" : "domain",
    "dns_sec" : "dns_sec"
  } ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Update a DNS Domain
 * Update the DNS Domain. 
 *
 * body Domains_dnsdomain_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * dnsDomain String The [DNS Domain](#operation/list-dns-domains).
 * no response value expected for this operation
 **/
exports.updateDnsDomain = function(body,dnsDomain) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Update Record
 * Update the information for a DNS record. All attributes are optional. If not set, the attributes will retain their original values.
 *
 * body Records_recordid_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * dnsDomain String The [DNS Domain](#operation/list-dns-domains).
 * recordId String The [DNS Record id](#operation/list-dns-domain-records).
 * no response value expected for this operation
 **/
exports.updateDnsDomainRecord = function(body,dnsDomain,recordId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Update SOA information
 * Update the SOA information for the DNS Domain. All attributes are optional. If not set, the attributes will retain their original values.
 *
 * body Dnsdomain_soa_body Include a JSON object in the request body with a content type of **application/json**. (optional)
 * dnsDomain String The [DNS Domain](#operation/list-dns-domains).
 * no response value expected for this operation
 **/
exports.updateDnsDomainSoa = function(body,dnsDomain) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

