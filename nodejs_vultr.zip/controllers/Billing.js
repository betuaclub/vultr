'use strict';

var utils = require('../utils/writer.js');
var Billing = require('../service/BillingService');

module.exports.getInvoice = function getInvoice (req, res, next, invoiceId) {
  Billing.getInvoice(invoiceId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getInvoiceItems = function getInvoiceItems (req, res, next, invoiceId) {
  Billing.getInvoiceItems(invoiceId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.listBillingHistory = function listBillingHistory (req, res, next) {
  Billing.listBillingHistory()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.listInvoices = function listInvoices (req, res, next) {
  Billing.listInvoices()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
