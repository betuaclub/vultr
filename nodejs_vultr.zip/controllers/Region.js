'use strict';

var utils = require('../utils/writer.js');
var Region = require('../service/RegionService');

module.exports.listAvailablePlansRegion = function listAvailablePlansRegion (req, res, next, regionId, type) {
  Region.listAvailablePlansRegion(regionId, type)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.listRegions = function listRegions (req, res, next, per_page, cursor) {
  Region.listRegions(per_page, cursor)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
