'use strict';

var utils = require('../utils/writer.js');
var Snapshot = require('../service/SnapshotService');

module.exports.createSnapshot = function createSnapshot (req, res, next, body) {
  Snapshot.createSnapshot(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.createSnapshotCreateFromUrl = function createSnapshotCreateFromUrl (req, res, next, body) {
  Snapshot.createSnapshotCreateFromUrl(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.deleteSnapshot = function deleteSnapshot (req, res, next, snapshotId) {
  Snapshot.deleteSnapshot(snapshotId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getSnapshot = function getSnapshot (req, res, next, snapshotId) {
  Snapshot.getSnapshot(snapshotId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.listSnapshots = function listSnapshots (req, res, next, description, per_page, cursor) {
  Snapshot.listSnapshots(description, per_page, cursor)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.putSnapshotsSnapshotId = function putSnapshotsSnapshotId (req, res, next, body, snapshotId) {
  Snapshot.putSnapshotsSnapshotId(body, snapshotId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
