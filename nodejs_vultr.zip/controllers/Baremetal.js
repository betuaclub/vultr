'use strict';

var utils = require('../utils/writer.js');
var Baremetal = require('../service/BaremetalService');

module.exports.createBaremetal = function createBaremetal (req, res, next, body) {
  Baremetal.createBaremetal(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.deleteBaremetal = function deleteBaremetal (req, res, next, baremetalId) {
  Baremetal.deleteBaremetal(baremetalId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getBandwidthBaremetal = function getBandwidthBaremetal (req, res, next, baremetalId) {
  Baremetal.getBandwidthBaremetal(baremetalId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getBareMetalUserdata = function getBareMetalUserdata (req, res, next, baremetalId) {
  Baremetal.getBareMetalUserdata(baremetalId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getBareMetalVnc = function getBareMetalVnc (req, res, next, baremetalId) {
  Baremetal.getBareMetalVnc(baremetalId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getBareMetalsUpgrades = function getBareMetalsUpgrades (req, res, next, baremetalId, type) {
  Baremetal.getBareMetalsUpgrades(baremetalId, type)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getBaremetal = function getBaremetal (req, res, next, baremetalId) {
  Baremetal.getBaremetal(baremetalId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getIpv4Baremetal = function getIpv4Baremetal (req, res, next, baremetalId) {
  Baremetal.getIpv4Baremetal(baremetalId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getIpv6Baremetal = function getIpv6Baremetal (req, res, next, baremetalId) {
  Baremetal.getIpv6Baremetal(baremetalId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.haltBaremetal = function haltBaremetal (req, res, next, baremetalId) {
  Baremetal.haltBaremetal(baremetalId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.haltBaremetals = function haltBaremetals (req, res, next, body) {
  Baremetal.haltBaremetals(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.listBaremetals = function listBaremetals (req, res, next, per_page, cursor) {
  Baremetal.listBaremetals(per_page, cursor)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.rebootBareMetals = function rebootBareMetals (req, res, next, body) {
  Baremetal.rebootBareMetals(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.rebootBaremetal = function rebootBaremetal (req, res, next, baremetalId) {
  Baremetal.rebootBaremetal(baremetalId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.reinstallBaremetal = function reinstallBaremetal (req, res, next, baremetalId) {
  Baremetal.reinstallBaremetal(baremetalId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.startBareMetals = function startBareMetals (req, res, next, body) {
  Baremetal.startBareMetals(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.startBaremetal = function startBaremetal (req, res, next, baremetalId) {
  Baremetal.startBaremetal(baremetalId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.updateBaremetal = function updateBaremetal (req, res, next, body, baremetalId) {
  Baremetal.updateBaremetal(body, baremetalId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
