'use strict';

var utils = require('../utils/writer.js');
var Block = require('../service/BlockService');

module.exports.attachBlock = function attachBlock (req, res, next, body, blockId) {
  Block.attachBlock(body, blockId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.createBlock = function createBlock (req, res, next, body) {
  Block.createBlock(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.deleteBlock = function deleteBlock (req, res, next, blockId) {
  Block.deleteBlock(blockId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.detachBlock = function detachBlock (req, res, next, body, blockId) {
  Block.detachBlock(body, blockId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getBlock = function getBlock (req, res, next, blockId) {
  Block.getBlock(blockId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.listBlocks = function listBlocks (req, res, next, per_page, cursor) {
  Block.listBlocks(per_page, cursor)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.updateBlock = function updateBlock (req, res, next, body, blockId) {
  Block.updateBlock(body, blockId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
