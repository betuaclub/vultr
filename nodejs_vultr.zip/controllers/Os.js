'use strict';

var utils = require('../utils/writer.js');
var Os = require('../service/OsService');

module.exports.listOs = function listOs (req, res, next, per_page, cursor) {
  Os.listOs(per_page, cursor)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
