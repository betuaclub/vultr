'use strict';

var utils = require('../utils/writer.js');
var Dns = require('../service/DnsService');

module.exports.createDnsDomain = function createDnsDomain (req, res, next, body) {
  Dns.createDnsDomain(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.createDnsDomainRecord = function createDnsDomainRecord (req, res, next, body, dnsDomain) {
  Dns.createDnsDomainRecord(body, dnsDomain)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.deleteDnsDomain = function deleteDnsDomain (req, res, next, dnsDomain) {
  Dns.deleteDnsDomain(dnsDomain)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.deleteDnsDomainRecord = function deleteDnsDomainRecord (req, res, next, dnsDomain, recordId) {
  Dns.deleteDnsDomainRecord(dnsDomain, recordId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getDnsDomain = function getDnsDomain (req, res, next, dnsDomain) {
  Dns.getDnsDomain(dnsDomain)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getDnsDomainDnssec = function getDnsDomainDnssec (req, res, next, dnsDomain) {
  Dns.getDnsDomainDnssec(dnsDomain)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getDnsDomainRecord = function getDnsDomainRecord (req, res, next, dnsDomain, recordId) {
  Dns.getDnsDomainRecord(dnsDomain, recordId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getDnsDomainSoa = function getDnsDomainSoa (req, res, next, dnsDomain) {
  Dns.getDnsDomainSoa(dnsDomain)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.listDnsDomainRecords = function listDnsDomainRecords (req, res, next, dnsDomain, per_page, cursor) {
  Dns.listDnsDomainRecords(dnsDomain, per_page, cursor)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.listDnsDomains = function listDnsDomains (req, res, next, per_page, cursor) {
  Dns.listDnsDomains(per_page, cursor)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.updateDnsDomain = function updateDnsDomain (req, res, next, body, dnsDomain) {
  Dns.updateDnsDomain(body, dnsDomain)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.updateDnsDomainRecord = function updateDnsDomainRecord (req, res, next, body, dnsDomain, recordId) {
  Dns.updateDnsDomainRecord(body, dnsDomain, recordId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.updateDnsDomainSoa = function updateDnsDomainSoa (req, res, next, body, dnsDomain) {
  Dns.updateDnsDomainSoa(body, dnsDomain)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
