'use strict';

var utils = require('../utils/writer.js');
var Backup = require('../service/BackupService');

module.exports.getBackup = function getBackup (req, res, next, backupId) {
  Backup.getBackup(backupId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.listBackups = function listBackups (req, res, next, instance_id, per_page, cursor) {
  Backup.listBackups(instance_id, per_page, cursor)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
