'use strict';

var utils = require('../utils/writer.js');
var Iso = require('../service/IsoService');

module.exports.createIso = function createIso (req, res, next, body) {
  Iso.createIso(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.deleteIso = function deleteIso (req, res, next, isoId) {
  Iso.deleteIso(isoId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.isoGet = function isoGet (req, res, next, isoId) {
  Iso.isoGet(isoId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.listIsos = function listIsos (req, res, next, per_page, cursor) {
  Iso.listIsos(per_page, cursor)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.listPublicIsos = function listPublicIsos (req, res, next) {
  Iso.listPublicIsos()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
