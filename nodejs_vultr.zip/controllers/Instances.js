'use strict';

var utils = require('../utils/writer.js');
var Instances = require('../service/InstancesService');

module.exports.attachInstanceIso = function attachInstanceIso (req, res, next, body, instanceId) {
  Instances.attachInstanceIso(body, instanceId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.attachInstanceNetwork = function attachInstanceNetwork (req, res, next, body, instanceId) {
  Instances.attachInstanceNetwork(body, instanceId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.attachInstanceVpc = function attachInstanceVpc (req, res, next, body, instanceId) {
  Instances.attachInstanceVpc(body, instanceId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.createInstance = function createInstance (req, res, next, body) {
  Instances.createInstance(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.createInstanceBackupSchedule = function createInstanceBackupSchedule (req, res, next, body, instanceId) {
  Instances.createInstanceBackupSchedule(body, instanceId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.createInstanceIpv4 = function createInstanceIpv4 (req, res, next, body, instanceId) {
  Instances.createInstanceIpv4(body, instanceId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.createInstanceReverseIpv4 = function createInstanceReverseIpv4 (req, res, next, body, instanceId) {
  Instances.createInstanceReverseIpv4(body, instanceId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.createInstanceReverseIpv6 = function createInstanceReverseIpv6 (req, res, next, body, instanceId) {
  Instances.createInstanceReverseIpv6(body, instanceId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.deleteInstance = function deleteInstance (req, res, next, instanceId) {
  Instances.deleteInstance(instanceId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.deleteInstanceIpv4 = function deleteInstanceIpv4 (req, res, next, instanceId, ipv4) {
  Instances.deleteInstanceIpv4(instanceId, ipv4)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.deleteInstanceReverseIpv6 = function deleteInstanceReverseIpv6 (req, res, next, instanceId, ipv6) {
  Instances.deleteInstanceReverseIpv6(instanceId, ipv6)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.detachInstanceIso = function detachInstanceIso (req, res, next, instanceId) {
  Instances.detachInstanceIso(instanceId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.detachInstanceNetwork = function detachInstanceNetwork (req, res, next, body, instanceId) {
  Instances.detachInstanceNetwork(body, instanceId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.detachInstanceVpc = function detachInstanceVpc (req, res, next, body, instanceId) {
  Instances.detachInstanceVpc(body, instanceId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getInstance = function getInstance (req, res, next, instanceId) {
  Instances.getInstance(instanceId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getInstanceBackupSchedule = function getInstanceBackupSchedule (req, res, next, instanceId) {
  Instances.getInstanceBackupSchedule(instanceId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getInstanceBandwidth = function getInstanceBandwidth (req, res, next, instanceId) {
  Instances.getInstanceBandwidth(instanceId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getInstanceIpv4 = function getInstanceIpv4 (req, res, next, instanceId, public_network, per_page, cursor) {
  Instances.getInstanceIpv4(instanceId, public_network, per_page, cursor)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getInstanceIpv6 = function getInstanceIpv6 (req, res, next, instanceId) {
  Instances.getInstanceIpv6(instanceId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getInstanceIsoStatus = function getInstanceIsoStatus (req, res, next, instanceId) {
  Instances.getInstanceIsoStatus(instanceId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getInstanceNeighbors = function getInstanceNeighbors (req, res, next, instanceId) {
  Instances.getInstanceNeighbors(instanceId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getInstanceUpgrades = function getInstanceUpgrades (req, res, next, instanceId, type) {
  Instances.getInstanceUpgrades(instanceId, type)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getInstanceUserdata = function getInstanceUserdata (req, res, next, instanceId) {
  Instances.getInstanceUserdata(instanceId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.haltInstance = function haltInstance (req, res, next, instanceId) {
  Instances.haltInstance(instanceId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.haltInstances = function haltInstances (req, res, next, body) {
  Instances.haltInstances(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.listInstanceIpv6Reverse = function listInstanceIpv6Reverse (req, res, next, instanceId) {
  Instances.listInstanceIpv6Reverse(instanceId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.listInstancePrivateNetworks = function listInstancePrivateNetworks (req, res, next, instanceId, per_page, cursor) {
  Instances.listInstancePrivateNetworks(instanceId, per_page, cursor)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.listInstanceVpcs = function listInstanceVpcs (req, res, next, instanceId, per_page, cursor) {
  Instances.listInstanceVpcs(instanceId, per_page, cursor)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.listInstances = function listInstances (req, res, next, per_page, cursor, tag, label, main_ip, region) {
  Instances.listInstances(per_page, cursor, tag, label, main_ip, region)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.postInstancesInstanceIdIpv4ReverseDefault = function postInstancesInstanceIdIpv4ReverseDefault (req, res, next, body, instanceId) {
  Instances.postInstancesInstanceIdIpv4ReverseDefault(body, instanceId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.rebootInstance = function rebootInstance (req, res, next, instanceId) {
  Instances.rebootInstance(instanceId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.rebootInstances = function rebootInstances (req, res, next, body) {
  Instances.rebootInstances(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.reinstallInstance = function reinstallInstance (req, res, next, body, instanceId) {
  Instances.reinstallInstance(body, instanceId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.restoreInstance = function restoreInstance (req, res, next, body, instanceId) {
  Instances.restoreInstance(body, instanceId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.startInstance = function startInstance (req, res, next, instanceId) {
  Instances.startInstance(instanceId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.startInstances = function startInstances (req, res, next, body) {
  Instances.startInstances(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.updateInstance = function updateInstance (req, res, next, body, instanceId) {
  Instances.updateInstance(body, instanceId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
