'use strict';

var utils = require('../utils/writer.js');
var PrivateNetworks = require('../service/PrivateNetworksService');

module.exports.createNetwork = function createNetwork (req, res, next, body) {
  PrivateNetworks.createNetwork(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.deleteNetwork = function deleteNetwork (req, res, next, networkId) {
  PrivateNetworks.deleteNetwork(networkId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getNetwork = function getNetwork (req, res, next, networkId) {
  PrivateNetworks.getNetwork(networkId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.listNetworks = function listNetworks (req, res, next, per_page, cursor) {
  PrivateNetworks.listNetworks(per_page, cursor)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.updateNetwork = function updateNetwork (req, res, next, body, networkId) {
  PrivateNetworks.updateNetwork(body, networkId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
