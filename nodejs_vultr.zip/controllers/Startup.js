'use strict';

var utils = require('../utils/writer.js');
var Startup = require('../service/StartupService');

module.exports.createStartupScript = function createStartupScript (req, res, next, body) {
  Startup.createStartupScript(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.deleteStartupScript = function deleteStartupScript (req, res, next, startupId) {
  Startup.deleteStartupScript(startupId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getStartupScript = function getStartupScript (req, res, next, startupId) {
  Startup.getStartupScript(startupId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.listStartupScripts = function listStartupScripts (req, res, next, per_page, cursor) {
  Startup.listStartupScripts(per_page, cursor)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.updateStartupScript = function updateStartupScript (req, res, next, body, startupId) {
  Startup.updateStartupScript(body, startupId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
