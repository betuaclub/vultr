'use strict';

var utils = require('../utils/writer.js');
var LoadBalancer = require('../service/LoadBalancerService');

module.exports.createLoadBalancer = function createLoadBalancer (req, res, next, body) {
  LoadBalancer.createLoadBalancer(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.createLoadBalancerForwardingRules = function createLoadBalancerForwardingRules (req, res, next, body, loadBalancerId) {
  LoadBalancer.createLoadBalancerForwardingRules(body, loadBalancerId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.deleteLoadBalancer = function deleteLoadBalancer (req, res, next, loadBalancerId) {
  LoadBalancer.deleteLoadBalancer(loadBalancerId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.deleteLoadBalancerForwardingRule = function deleteLoadBalancerForwardingRule (req, res, next, loadBalancerId, forwardingRuleId) {
  LoadBalancer.deleteLoadBalancerForwardingRule(loadBalancerId, forwardingRuleId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getLoadBalancer = function getLoadBalancer (req, res, next, loadBalancerId) {
  LoadBalancer.getLoadBalancer(loadBalancerId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getLoadBalancerForwardingRule = function getLoadBalancerForwardingRule (req, res, next, loadBalancerId, forwardingRuleId) {
  LoadBalancer.getLoadBalancerForwardingRule(loadBalancerId, forwardingRuleId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getLoadbalancerFirewallRule = function getLoadbalancerFirewallRule (req, res, next, loadbalancerId, firewallRuleId) {
  LoadBalancer.getLoadbalancerFirewallRule(loadbalancerId, firewallRuleId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.listLoadBalancerForwardingRules = function listLoadBalancerForwardingRules (req, res, next, loadBalancerId, per_page, cursor) {
  LoadBalancer.listLoadBalancerForwardingRules(loadBalancerId, per_page, cursor)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.listLoadBalancers = function listLoadBalancers (req, res, next, per_page, cursor) {
  LoadBalancer.listLoadBalancers(per_page, cursor)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.listLoadbalancerFirewallRules = function listLoadbalancerFirewallRules (req, res, next, loadbalancerId, per_page, cursor) {
  LoadBalancer.listLoadbalancerFirewallRules(loadbalancerId, per_page, cursor)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.updateLoadBalancer = function updateLoadBalancer (req, res, next, body, loadBalancerId) {
  LoadBalancer.updateLoadBalancer(body, loadBalancerId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
