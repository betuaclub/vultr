'use strict';

var utils = require('../utils/writer.js');
var Kubernetes = require('../service/KubernetesService');

module.exports.createKubernetesCluster = function createKubernetesCluster (req, res, next, body) {
  Kubernetes.createKubernetesCluster(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.createNodepools = function createNodepools (req, res, next, body, vkeId) {
  Kubernetes.createNodepools(body, vkeId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.deleteKubernetesCluster = function deleteKubernetesCluster (req, res, next, vkeId) {
  Kubernetes.deleteKubernetesCluster(vkeId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.deleteKubernetesClusterVkeIdDeleteWithLinkedResources = function deleteKubernetesClusterVkeIdDeleteWithLinkedResources (req, res, next, vkeId) {
  Kubernetes.deleteKubernetesClusterVkeIdDeleteWithLinkedResources(vkeId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.deleteNodepool = function deleteNodepool (req, res, next, vkeId, nodepoolId) {
  Kubernetes.deleteNodepool(vkeId, nodepoolId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.deleteNodepoolInstance = function deleteNodepoolInstance (req, res, next, vkeId, nodepoolId, nodeId) {
  Kubernetes.deleteNodepoolInstance(vkeId, nodepoolId, nodeId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getKubernetesAvailableUpgrades = function getKubernetesAvailableUpgrades (req, res, next, vkeId) {
  Kubernetes.getKubernetesAvailableUpgrades(vkeId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getKubernetesClusters = function getKubernetesClusters (req, res, next, vkeId) {
  Kubernetes.getKubernetesClusters(vkeId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getKubernetesClustersConfig = function getKubernetesClustersConfig (req, res, next, vkeId) {
  Kubernetes.getKubernetesClustersConfig(vkeId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getKubernetesResources = function getKubernetesResources (req, res, next, vkeId) {
  Kubernetes.getKubernetesResources(vkeId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getKubernetesVersions = function getKubernetesVersions (req, res, next) {
  Kubernetes.getKubernetesVersions()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getNodepool = function getNodepool (req, res, next, vkeId, nodepoolId) {
  Kubernetes.getNodepool(vkeId, nodepoolId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getNodepools = function getNodepools (req, res, next, vkeId) {
  Kubernetes.getNodepools(vkeId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.listKubernetesClusters = function listKubernetesClusters (req, res, next) {
  Kubernetes.listKubernetesClusters()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.recycleNodepoolInstance = function recycleNodepoolInstance (req, res, next, vkeId, nodepoolId, nodeId) {
  Kubernetes.recycleNodepoolInstance(vkeId, nodepoolId, nodeId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.startKubernetesClusterUpgrade = function startKubernetesClusterUpgrade (req, res, next, body, vkeId) {
  Kubernetes.startKubernetesClusterUpgrade(body, vkeId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.updateKubernetesCluster = function updateKubernetesCluster (req, res, next, body, vkeId) {
  Kubernetes.updateKubernetesCluster(body, vkeId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.updateNodepool = function updateNodepool (req, res, next, body, vkeId, nodepoolId) {
  Kubernetes.updateNodepool(body, vkeId, nodepoolId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.updateNodepool = function updateNodepool (req, res, next, body, vkeId, nodepoolId) {
  Kubernetes.updateNodepool(body, vkeId, nodepoolId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
