'use strict';

var utils = require('../utils/writer.js');
var S3 = require('../service/S3Service');

module.exports.createObjectStorage = function createObjectStorage (req, res, next, body) {
  S3.createObjectStorage(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.deleteObjectStorage = function deleteObjectStorage (req, res, next, objectStorageId) {
  S3.deleteObjectStorage(objectStorageId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getObjectStorage = function getObjectStorage (req, res, next, objectStorageId) {
  S3.getObjectStorage(objectStorageId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.listObjectStorageClusters = function listObjectStorageClusters (req, res, next, per_page, cursor) {
  S3.listObjectStorageClusters(per_page, cursor)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.listObjectStorages = function listObjectStorages (req, res, next, per_page, cursor) {
  S3.listObjectStorages(per_page, cursor)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.regenerateObjectStorageKeys = function regenerateObjectStorageKeys (req, res, next, objectStorageId) {
  S3.regenerateObjectStorageKeys(objectStorageId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.updateObjectStorage = function updateObjectStorage (req, res, next, body, objectStorageId) {
  S3.updateObjectStorage(body, objectStorageId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
