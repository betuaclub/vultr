'use strict';

var utils = require('../utils/writer.js');
var VPCs = require('../service/VPCsService');

module.exports.createVpc = function createVpc (req, res, next, body) {
  VPCs.createVpc(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.deleteVpc = function deleteVpc (req, res, next, vpcId) {
  VPCs.deleteVpc(vpcId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getVpc = function getVpc (req, res, next, vpcId) {
  VPCs.getVpc(vpcId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.listVpcs = function listVpcs (req, res, next, per_page, cursor) {
  VPCs.listVpcs(per_page, cursor)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.updateVpc = function updateVpc (req, res, next, body, vpcId) {
  VPCs.updateVpc(body, vpcId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
