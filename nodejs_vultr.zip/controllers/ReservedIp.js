'use strict';

var utils = require('../utils/writer.js');
var ReservedIp = require('../service/ReservedIpService');

module.exports.attachReservedIp = function attachReservedIp (req, res, next, body, reservedIp) {
  ReservedIp.attachReservedIp(body, reservedIp)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.convertReservedIp = function convertReservedIp (req, res, next, body) {
  ReservedIp.convertReservedIp(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.createReservedIp = function createReservedIp (req, res, next, body) {
  ReservedIp.createReservedIp(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.deleteReservedIp = function deleteReservedIp (req, res, next, reservedIp) {
  ReservedIp.deleteReservedIp(reservedIp)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.detachReservedIp = function detachReservedIp (req, res, next, reservedIp) {
  ReservedIp.detachReservedIp(reservedIp)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getReservedIp = function getReservedIp (req, res, next, reservedIp) {
  ReservedIp.getReservedIp(reservedIp)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.listReservedIps = function listReservedIps (req, res, next, per_page, cursor) {
  ReservedIp.listReservedIps(per_page, cursor)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.patchReservedIpsReservedIp = function patchReservedIpsReservedIp (req, res, next, body, reservedIp) {
  ReservedIp.patchReservedIpsReservedIp(body, reservedIp)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
