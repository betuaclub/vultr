'use strict';

var utils = require('../utils/writer.js');
var Firewall = require('../service/FirewallService');

module.exports.createFirewallGroup = function createFirewallGroup (req, res, next, body) {
  Firewall.createFirewallGroup(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.deleteFirewallGroup = function deleteFirewallGroup (req, res, next, firewallGroupId) {
  Firewall.deleteFirewallGroup(firewallGroupId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.deleteFirewallGroupRule = function deleteFirewallGroupRule (req, res, next, firewallGroupId, firewallRuleId) {
  Firewall.deleteFirewallGroupRule(firewallGroupId, firewallRuleId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getFirewallGroup = function getFirewallGroup (req, res, next, firewallGroupId) {
  Firewall.getFirewallGroup(firewallGroupId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getFirewallGroupRule = function getFirewallGroupRule (req, res, next, firewallGroupId, firewallRuleId) {
  Firewall.getFirewallGroupRule(firewallGroupId, firewallRuleId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.listFirewallGroupRules = function listFirewallGroupRules (req, res, next, firewallGroupId, per_page, cursor) {
  Firewall.listFirewallGroupRules(firewallGroupId, per_page, cursor)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.listFirewallGroups = function listFirewallGroups (req, res, next, per_page, cursor) {
  Firewall.listFirewallGroups(per_page, cursor)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.postFirewallsFirewallGroupIdRules = function postFirewallsFirewallGroupIdRules (req, res, next, body, firewallGroupId) {
  Firewall.postFirewallsFirewallGroupIdRules(body, firewallGroupId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.updateFirewallGroup = function updateFirewallGroup (req, res, next, body, firewallGroupId) {
  Firewall.updateFirewallGroup(body, firewallGroupId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
