'use strict';

var utils = require('../utils/writer.js');
var Plans = require('../service/PlansService');

module.exports.listMetalPlans = function listMetalPlans (req, res, next, per_page, cursor) {
  Plans.listMetalPlans(per_page, cursor)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.listPlans = function listPlans (req, res, next, type, per_page, cursor, os) {
  Plans.listPlans(type, per_page, cursor, os)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
