'use strict';

var utils = require('../utils/writer.js');
var Ssh = require('../service/SshService');

module.exports.createSshKey = function createSshKey (req, res, next, body) {
  Ssh.createSshKey(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.deleteSshKey = function deleteSshKey (req, res, next, sshKeyId) {
  Ssh.deleteSshKey(sshKeyId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getSshKey = function getSshKey (req, res, next, sshKeyId) {
  Ssh.getSshKey(sshKeyId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.listSshKeys = function listSshKeys (req, res, next, per_page, cursor) {
  Ssh.listSshKeys(per_page, cursor)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.updateSshKey = function updateSshKey (req, res, next, body, sshKeyId) {
  Ssh.updateSshKey(body, sshKeyId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
