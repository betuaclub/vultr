import connexion
import six

from swagger_server.models.inline_response20010 import InlineResponse20010  # noqa: E501
from swagger_server.models.inline_response2009 import InlineResponse2009  # noqa: E501
from swagger_server.models.snapshots_body import SnapshotsBody  # noqa: E501
from swagger_server.models.snapshots_createfromurl_body import SnapshotsCreatefromurlBody  # noqa: E501
from swagger_server.models.snapshots_snapshotid_body import SnapshotsSnapshotidBody  # noqa: E501
from swagger_server import util


def create_snapshot(body=None):  # noqa: E501
    """Create Snapshot

    Create a new Snapshot for &#x60;instance_id&#x60;. # noqa: E501

    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: InlineResponse2009
    """
    if connexion.request.is_json:
        body = SnapshotsBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def create_snapshot_create_from_url(body=None):  # noqa: E501
    """Create Snapshot from URL

    Create a new Snapshot from a RAW image located at &#x60;url&#x60;. # noqa: E501

    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: InlineResponse2009
    """
    if connexion.request.is_json:
        body = SnapshotsCreatefromurlBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def delete_snapshot(snapshot_id):  # noqa: E501
    """Delete Snapshot

    Delete a Snapshot. # noqa: E501

    :param snapshot_id: The [Snapshot id](#operation/list-snapshots).
    :type snapshot_id: str

    :rtype: None
    """
    return 'do some magic!'


def get_snapshot(snapshot_id):  # noqa: E501
    """Get Snapshot

    Get information about a Snapshot. # noqa: E501

    :param snapshot_id: The [Snapshot id](#operation/list-snapshots).
    :type snapshot_id: str

    :rtype: InlineResponse2009
    """
    return 'do some magic!'


def list_snapshots(description=None, per_page=None, cursor=None):  # noqa: E501
    """List Snapshots

    Get information about all Snapshots in your account. # noqa: E501

    :param description: Filter the list of Snapshots by &#x60;description&#x60;
    :type description: str
    :param per_page: Number of items requested per page. Default is 100 and Max is 500.
    :type per_page: int
    :param cursor: Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination).
    :type cursor: str

    :rtype: InlineResponse20010
    """
    return 'do some magic!'


def put_snapshots_snapshot_id(snapshot_id, body=None):  # noqa: E501
    """Update Snapshot

    Update the description for a Snapshot. # noqa: E501

    :param snapshot_id: The [Snapshot id](#operation/list-snapshots).
    :type snapshot_id: str
    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        body = SnapshotsSnapshotidBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'
