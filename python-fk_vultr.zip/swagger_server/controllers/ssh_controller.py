import connexion
import six

from swagger_server.models.inline_response2007 import InlineResponse2007  # noqa: E501
from swagger_server.models.inline_response2008 import InlineResponse2008  # noqa: E501
from swagger_server.models.sshkeys_body import SshkeysBody  # noqa: E501
from swagger_server.models.sshkeys_sshkeyid_body import SshkeysSshkeyidBody  # noqa: E501
from swagger_server import util


def create_ssh_key(body=None):  # noqa: E501
    """Create SSH key

    Create a new SSH Key for use with future instances. This does not update any running instances. # noqa: E501

    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: InlineResponse2007
    """
    if connexion.request.is_json:
        body = SshkeysBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def delete_ssh_key(ssh_key_id):  # noqa: E501
    """Delete SSH Key

    Delete an SSH Key. # noqa: E501

    :param ssh_key_id: The [SSH Key id](#operation/list-ssh-keys).
    :type ssh_key_id: str

    :rtype: None
    """
    return 'do some magic!'


def get_ssh_key(ssh_key_id):  # noqa: E501
    """Get SSH Key

    Get information about an SSH Key. # noqa: E501

    :param ssh_key_id: The [SSH Key id](#operation/list-ssh-keys).
    :type ssh_key_id: str

    :rtype: InlineResponse2007
    """
    return 'do some magic!'


def list_ssh_keys(per_page=None, cursor=None):  # noqa: E501
    """List SSH Keys

    List all SSH Keys in your account. # noqa: E501

    :param per_page: Number of items requested per page. Default is 100 and Max is 500. 
    :type per_page: int
    :param cursor: Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination).
    :type cursor: str

    :rtype: InlineResponse2008
    """
    return 'do some magic!'


def update_ssh_key(ssh_key_id, body=None):  # noqa: E501
    """Update SSH Key

    Update an SSH Key. The attributes &#x60;name&#x60; and &#x60;ssh_key&#x60; are optional. If not set, the attributes will retain their original values. New deployments will use the updated key, but this action does not update previously deployed instances. # noqa: E501

    :param ssh_key_id: The [SSH Key id](#operation/list-ssh-keys).
    :type ssh_key_id: str
    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        body = SshkeysSshkeyidBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'
