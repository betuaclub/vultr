import connexion
import six

from swagger_server.models.dnsdomain_records_body import DnsdomainRecordsBody  # noqa: E501
from swagger_server.models.dnsdomain_soa_body import DnsdomainSoaBody  # noqa: E501
from swagger_server.models.domains_body import DomainsBody  # noqa: E501
from swagger_server.models.domains_dnsdomain_body import DomainsDnsdomainBody  # noqa: E501
from swagger_server.models.inline_response20024 import InlineResponse20024  # noqa: E501
from swagger_server.models.inline_response20025 import InlineResponse20025  # noqa: E501
from swagger_server.models.inline_response20026 import InlineResponse20026  # noqa: E501
from swagger_server.models.inline_response20027 import InlineResponse20027  # noqa: E501
from swagger_server.models.inline_response20028 import InlineResponse20028  # noqa: E501
from swagger_server.models.inline_response2014 import InlineResponse2014  # noqa: E501
from swagger_server.models.records_recordid_body import RecordsRecordidBody  # noqa: E501
from swagger_server import util


def create_dns_domain(body=None):  # noqa: E501
    """Create DNS Domain

    Create a DNS Domain for &#x60;domain&#x60;. If no &#x60;ip&#x60; address is supplied a domain with no records will be created. # noqa: E501

    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: InlineResponse20025
    """
    if connexion.request.is_json:
        body = DomainsBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def create_dns_domain_record(dns_domain, body=None):  # noqa: E501
    """Create Record

    Create a DNS record. # noqa: E501

    :param dns_domain: The [DNS Domain](#operation/list-dns-domains).
    :type dns_domain: str
    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: InlineResponse2014
    """
    if connexion.request.is_json:
        body = DnsdomainRecordsBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def delete_dns_domain(dns_domain):  # noqa: E501
    """Delete Domain

    Delete the DNS Domain. # noqa: E501

    :param dns_domain: The [DNS Domain](#operation/list-dns-domains).
    :type dns_domain: str

    :rtype: None
    """
    return 'do some magic!'


def delete_dns_domain_record(dns_domain, record_id):  # noqa: E501
    """Delete Record

    Delete the DNS record. # noqa: E501

    :param dns_domain: The [DNS Domain](#operation/list-dns-domains).
    :type dns_domain: str
    :param record_id: The [DNS Record id](#operation/list-dns-domain-records).
    :type record_id: str

    :rtype: None
    """
    return 'do some magic!'


def get_dns_domain(dns_domain):  # noqa: E501
    """Get DNS Domain

    Get information for the DNS Domain. # noqa: E501

    :param dns_domain: The [DNS Domain](#operation/list-dns-domains).
    :type dns_domain: str

    :rtype: InlineResponse20025
    """
    return 'do some magic!'


def get_dns_domain_dnssec(dns_domain):  # noqa: E501
    """Get DNSSec Info

    Get the DNSSEC information for the DNS Domain. # noqa: E501

    :param dns_domain: The [DNS Domain](#operation/list-dns-domains).
    :type dns_domain: str

    :rtype: InlineResponse20027
    """
    return 'do some magic!'


def get_dns_domain_record(dns_domain, record_id):  # noqa: E501
    """Get Record

    Get information for a DNS Record. # noqa: E501

    :param dns_domain: The [DNS Domain](#operation/list-dns-domains).
    :type dns_domain: str
    :param record_id: The [DNS Record id](#operation/list-dns-domain-records).
    :type record_id: str

    :rtype: InlineResponse2014
    """
    return 'do some magic!'


def get_dns_domain_soa(dns_domain):  # noqa: E501
    """Get SOA information

    Get SOA information for the DNS Domain. # noqa: E501

    :param dns_domain: The [DNS Domain](#operation/list-dns-domains).
    :type dns_domain: str

    :rtype: InlineResponse20026
    """
    return 'do some magic!'


def list_dns_domain_records(dns_domain, per_page=None, cursor=None):  # noqa: E501
    """List Records

    Get the DNS records for the Domain. # noqa: E501

    :param dns_domain: The [DNS Domain](#operation/list-dns-domains).
    :type dns_domain: str
    :param per_page: Number of items requested per page. Default is 100 and Max is 500.
    :type per_page: int
    :param cursor: Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination).
    :type cursor: str

    :rtype: InlineResponse20028
    """
    return 'do some magic!'


def list_dns_domains(per_page=None, cursor=None):  # noqa: E501
    """List DNS Domains

    List all DNS Domains in your account. # noqa: E501

    :param per_page: Number of items requested per page. Default is 100 and Max is 500. 
    :type per_page: int
    :param cursor: Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination).
    :type cursor: str

    :rtype: InlineResponse20024
    """
    return 'do some magic!'


def update_dns_domain(dns_domain, body=None):  # noqa: E501
    """Update a DNS Domain

    Update the DNS Domain.  # noqa: E501

    :param dns_domain: The [DNS Domain](#operation/list-dns-domains).
    :type dns_domain: str
    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        body = DomainsDnsdomainBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def update_dns_domain_record(dns_domain, record_id, body=None):  # noqa: E501
    """Update Record

    Update the information for a DNS record. All attributes are optional. If not set, the attributes will retain their original values. # noqa: E501

    :param dns_domain: The [DNS Domain](#operation/list-dns-domains).
    :type dns_domain: str
    :param record_id: The [DNS Record id](#operation/list-dns-domain-records).
    :type record_id: str
    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        body = RecordsRecordidBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def update_dns_domain_soa(dns_domain, body=None):  # noqa: E501
    """Update SOA information

    Update the SOA information for the DNS Domain. All attributes are optional. If not set, the attributes will retain their original values. # noqa: E501

    :param dns_domain: The [DNS Domain](#operation/list-dns-domains).
    :type dns_domain: str
    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        body = DnsdomainSoaBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'
