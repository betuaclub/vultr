import connexion
import six

from swagger_server.models.inline_response20022 import InlineResponse20022  # noqa: E501
from swagger_server.models.inline_response20023 import InlineResponse20023  # noqa: E501
from swagger_server.models.inline_response2013 import InlineResponse2013  # noqa: E501
from swagger_server.models.inline_response2021 import InlineResponse2021  # noqa: E501
from swagger_server.models.objectstorage_body import ObjectstorageBody  # noqa: E501
from swagger_server.models.objectstorage_objectstorageid_body import ObjectstorageObjectstorageidBody  # noqa: E501
from swagger_server import util


def create_object_storage(body=None):  # noqa: E501
    """Create Object Storage

    Create new Object Storage. The &#x60;cluster_id&#x60; attribute is required. # noqa: E501

    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: InlineResponse2021
    """
    if connexion.request.is_json:
        body = ObjectstorageBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def delete_object_storage(object_storage_id):  # noqa: E501
    """Delete Object Storage

    Delete an Object Storage. # noqa: E501

    :param object_storage_id: The [Object Storage id](#operation/list-object-storages).
    :type object_storage_id: str

    :rtype: None
    """
    return 'do some magic!'


def get_object_storage(object_storage_id):  # noqa: E501
    """Get Object Storage

    Get information about an Object Storage. # noqa: E501

    :param object_storage_id: The [Object Storage id](#operation/list-object-storages).
    :type object_storage_id: str

    :rtype: InlineResponse2021
    """
    return 'do some magic!'


def list_object_storage_clusters(per_page=None, cursor=None):  # noqa: E501
    """Get All Clusters

    Get a list of all Object Storage Clusters. # noqa: E501

    :param per_page: Number of items requested per page. Default is 100 and Max is 500.
    :type per_page: int
    :param cursor: Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination).
    :type cursor: str

    :rtype: InlineResponse20023
    """
    return 'do some magic!'


def list_object_storages(per_page=None, cursor=None):  # noqa: E501
    """List Object Storages

    Get a list of all Object Storage in your account. # noqa: E501

    :param per_page: Number of items requested per page. Default is 100 and Max is 500.
    :type per_page: int
    :param cursor: Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination).
    :type cursor: str

    :rtype: InlineResponse20022
    """
    return 'do some magic!'


def regenerate_object_storage_keys(object_storage_id):  # noqa: E501
    """Regenerate Object Storage Keys

    Regenerate the keys for an Object Storage. # noqa: E501

    :param object_storage_id: The [Object Storage id](#operation/list-object-storages).
    :type object_storage_id: str

    :rtype: InlineResponse2013
    """
    return 'do some magic!'


def update_object_storage(object_storage_id, body=None):  # noqa: E501
    """Update Object Storage

    Update the label for an Object Storage. # noqa: E501

    :param object_storage_id: The [Object Storage id](#operation/list-object-storages).
    :type object_storage_id: str
    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        body = ObjectstorageObjectstorageidBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'
