import connexion
import six

from swagger_server.models.inline_response200 import InlineResponse200  # noqa: E501
from swagger_server.models.inline_response2001 import InlineResponse2001  # noqa: E501
from swagger_server.models.privatenetworks_body import PrivatenetworksBody  # noqa: E501
from swagger_server.models.privatenetworks_networkid_body import PrivatenetworksNetworkidBody  # noqa: E501
from swagger_server import util


def create_network(body=None):  # noqa: E501
    """Create a Private Network

    Create a new Private Network in a &#x60;region&#x60;.  **Deprecated**: Use [Create VPC](#operation/create-vpc) instead.      Private networks should use [RFC1918 private address space](https://tools.ietf.org/html/rfc1918):      10.0.0.0    - 10.255.255.255  (10/8 prefix)     172.16.0.0  - 172.31.255.255  (172.16/12 prefix)     192.168.0.0 - 192.168.255.255 (192.168/16 prefix)  # noqa: E501

    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: InlineResponse200
    """
    if connexion.request.is_json:
        body = PrivatenetworksBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def delete_network(network_id):  # noqa: E501
    """Delete a private network

    Delete a Private Network.&lt;br&gt;&lt;br&gt;**Deprecated**: Use [Delete VPC](#operation/delete-vpc) instead. # noqa: E501

    :param network_id: The [Network id](#operation/list-networks).
    :type network_id: str

    :rtype: None
    """
    return 'do some magic!'


def get_network(network_id):  # noqa: E501
    """Get a private network

    Get information about a Private Network.&lt;br&gt;&lt;br&gt;**Deprecated**: Use [Get VPC](#operation/get-vpc) instead.  # noqa: E501

    :param network_id: The [Network id](#operation/list-networks).
    :type network_id: str

    :rtype: InlineResponse200
    """
    return 'do some magic!'


def list_networks(per_page=None, cursor=None):  # noqa: E501
    """List Private Networks

    Get a list of all Private Networks in your account.&lt;br&gt;&lt;br&gt;**Deprecated**: Use [List VPCs](#operation/list-vpcs) instead. # noqa: E501

    :param per_page: Number of items requested per page. Default is 100 and Max is 500.
    :type per_page: int
    :param cursor: Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination).
    :type cursor: str

    :rtype: InlineResponse2001
    """
    return 'do some magic!'


def update_network(network_id, body=None):  # noqa: E501
    """Update a Private Network

    Update information for a Private Network.&lt;br&gt;&lt;br&gt;**Deprecated**: Use [Update VPC](#operation/update-vpc) instead. # noqa: E501

    :param network_id: The [Network id](#operation/list-networks).
    :type network_id: str
    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        body = PrivatenetworksNetworkidBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'
