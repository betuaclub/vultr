import connexion
import six

from swagger_server.models.inline_response20038 import InlineResponse20038  # noqa: E501
from swagger_server.models.inline_response20039 import InlineResponse20039  # noqa: E501
from swagger_server.models.inline_response20040 import InlineResponse20040  # noqa: E501
from swagger_server.models.inline_response20042 import InlineResponse20042  # noqa: E501
from swagger_server.models.inline_response20043 import InlineResponse20043  # noqa: E501
from swagger_server.models.inline_response20044 import InlineResponse20044  # noqa: E501
from swagger_server.models.inline_response20045 import InlineResponse20045  # noqa: E501
from swagger_server.models.inline_response20046 import InlineResponse20046  # noqa: E501
from swagger_server.models.inline_response20047 import InlineResponse20047  # noqa: E501
from swagger_server.models.inline_response20048 import InlineResponse20048  # noqa: E501
from swagger_server.models.inline_response20050 import InlineResponse20050  # noqa: E501
from swagger_server.models.inline_response20051 import InlineResponse20051  # noqa: E501
from swagger_server.models.inline_response2024 import InlineResponse2024  # noqa: E501
from swagger_server.models.inline_response2025 import InlineResponse2025  # noqa: E501
from swagger_server.models.inline_response2026 import InlineResponse2026  # noqa: E501
from swagger_server.models.inline_response2027 import InlineResponse2027  # noqa: E501
from swagger_server.models.instanceid_backupschedule_body import InstanceidBackupscheduleBody  # noqa: E501
from swagger_server.models.instanceid_ipv4_body import InstanceidIpv4Body  # noqa: E501
from swagger_server.models.instanceid_reinstall_body import InstanceidReinstallBody  # noqa: E501
from swagger_server.models.instanceid_restore_body import InstanceidRestoreBody  # noqa: E501
from swagger_server.models.instances_body import InstancesBody  # noqa: E501
from swagger_server.models.instances_halt_body import InstancesHaltBody  # noqa: E501
from swagger_server.models.instances_instanceid_body import InstancesInstanceidBody  # noqa: E501
from swagger_server.models.instances_reboot_body import InstancesRebootBody  # noqa: E501
from swagger_server.models.instances_start_body import InstancesStartBody  # noqa: E501
from swagger_server.models.ipv4_reverse_body import Ipv4ReverseBody  # noqa: E501
from swagger_server.models.ipv6_reverse_body import Ipv6ReverseBody  # noqa: E501
from swagger_server.models.iso_attach_body import IsoAttachBody  # noqa: E501
from swagger_server.models.privatenetworks_attach_body import PrivatenetworksAttachBody  # noqa: E501
from swagger_server.models.privatenetworks_detach_body import PrivatenetworksDetachBody  # noqa: E501
from swagger_server.models.reverse_default_body import ReverseDefaultBody  # noqa: E501
from swagger_server.models.vpcs_attach_body import VpcsAttachBody  # noqa: E501
from swagger_server.models.vpcs_detach_body import VpcsDetachBody  # noqa: E501
from swagger_server import util


def attach_instance_iso(instance_id, body=None):  # noqa: E501
    """Attach ISO to Instance

    Attach an ISO to an Instance. # noqa: E501

    :param instance_id: 
    :type instance_id: str
    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: InlineResponse2025
    """
    if connexion.request.is_json:
        body = IsoAttachBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def attach_instance_network(instance_id, body=None):  # noqa: E501
    """Attach Private Network to Instance

    Attach Private Network to an Instance.&lt;br&gt;&lt;br&gt;**Deprecated**: use [Attach VPC to Instance](#operation/attach-instance-vpc) instead. # noqa: E501

    :param instance_id: The [Instance ID](#operation/list-instances).
    :type instance_id: str
    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        body = PrivatenetworksAttachBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def attach_instance_vpc(instance_id, body=None):  # noqa: E501
    """Attach VPC to Instance

    Attach a VPC to an Instance. # noqa: E501

    :param instance_id: The [Instance ID](#operation/list-instances).
    :type instance_id: str
    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        body = VpcsAttachBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def create_instance(body=None):  # noqa: E501
    """Create Instance

    Create a new VPS Instance in a &#x60;region&#x60; with the desired &#x60;plan&#x60;. Choose one of the following to deploy the instance:  * &#x60;os_id&#x60; * &#x60;iso_id&#x60; * &#x60;snapshot_id&#x60; * &#x60;app_id&#x60; * &#x60;image_id&#x60;  Supply other attributes as desired. # noqa: E501

    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: InlineResponse2024
    """
    if connexion.request.is_json:
        body = InstancesBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def create_instance_backup_schedule(instance_id, body=None):  # noqa: E501
    """Set Instance Backup Schedule

    Set the backup schedule for an Instance in UTC. The &#x60;type&#x60; is required. # noqa: E501

    :param instance_id: The [Instance ID](#operation/list-instances).
    :type instance_id: str
    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        body = InstanceidBackupscheduleBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def create_instance_ipv4(instance_id, body=None):  # noqa: E501
    """Create IPv4

    Create an IPv4 address for an Instance. # noqa: E501

    :param instance_id: The [Instance ID](#operation/list-instances).
    :type instance_id: str
    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: object
    """
    if connexion.request.is_json:
        body = InstanceidIpv4Body.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def create_instance_reverse_ipv4(instance_id, body=None):  # noqa: E501
    """Create Instance Reverse IPv4

    Create a reverse IPv4 entry for an Instance. The &#x60;ip&#x60; and &#x60;reverse&#x60; attributes are required.  # noqa: E501

    :param instance_id: The [Instance ID](#operation/list-instances).
    :type instance_id: str
    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        body = Ipv4ReverseBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def create_instance_reverse_ipv6(instance_id, body=None):  # noqa: E501
    """Create Instance Reverse IPv6

    Create a reverse IPv6 entry for an Instance. The &#x60;ip&#x60; and &#x60;reverse&#x60; attributes are required. IP address must be in full, expanded format. # noqa: E501

    :param instance_id: The [Instance ID](#operation/list-instances).
    :type instance_id: str
    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        body = Ipv6ReverseBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def delete_instance(instance_id):  # noqa: E501
    """Delete Instance

    Delete an Instance. # noqa: E501

    :param instance_id: The [Instance ID](#operation/list-instances).
    :type instance_id: str

    :rtype: None
    """
    return 'do some magic!'


def delete_instance_ipv4(instance_id, ipv4):  # noqa: E501
    """Delete IPv4 Address

    Delete an IPv4 address from an Instance. # noqa: E501

    :param instance_id: The [Instance ID](#operation/list-instances).
    :type instance_id: str
    :param ipv4: The IPv4 address.
    :type ipv4: str

    :rtype: None
    """
    return 'do some magic!'


def delete_instance_reverse_ipv6(instance_id, ipv6):  # noqa: E501
    """Delete Instance Reverse IPv6

    Delete the reverse IPv6 for an Instance. # noqa: E501

    :param instance_id: The [Instance ID](#operation/list-instances).
    :type instance_id: str
    :param ipv6: The IPv6 address.
    :type ipv6: str

    :rtype: None
    """
    return 'do some magic!'


def detach_instance_iso(instance_id):  # noqa: E501
    """Detach ISO from instance

    Detach the ISO from an Instance. # noqa: E501

    :param instance_id: The [Instance ID](#operation/list-instances).
    :type instance_id: str

    :rtype: InlineResponse2026
    """
    return 'do some magic!'


def detach_instance_network(instance_id, body=None):  # noqa: E501
    """Detach Private Network from Instance.

    Detach Private Network from an Instance.&lt;br&gt;&lt;br&gt;**Deprecated**: use [Detach VPC from Instance](#operation/detach-instance-vpc) instead. # noqa: E501

    :param instance_id: The [Instance ID](#operation/list-instances).
    :type instance_id: str
    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        body = PrivatenetworksDetachBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def detach_instance_vpc(instance_id, body=None):  # noqa: E501
    """Detach VPC from Instance

    Detach a VPC from an Instance. # noqa: E501

    :param instance_id: The [Instance ID](#operation/list-instances).
    :type instance_id: str
    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        body = VpcsDetachBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def get_instance(instance_id):  # noqa: E501
    """Get Instance

    Get information about an Instance. # noqa: E501

    :param instance_id: The [Instance ID](#operation/list-instances).
    :type instance_id: str

    :rtype: InlineResponse2024
    """
    return 'do some magic!'


def get_instance_backup_schedule(instance_id):  # noqa: E501
    """Get Instance Backup Schedule

    Get the backup schedule for an Instance. # noqa: E501

    :param instance_id: The [Instance ID](#operation/list-instances).
    :type instance_id: str

    :rtype: InlineResponse20047
    """
    return 'do some magic!'


def get_instance_bandwidth(instance_id):  # noqa: E501
    """Instance Bandwidth

    Get bandwidth information about an Instance.&lt;br&gt;&lt;br&gt;The &#x60;bandwidth&#x60; object in a successful response contains objects representing a day in the month. The date is denoted by the nested object keys. Days begin and end in the UTC timezone. The bandwidth utilization data contained within the date object is refreshed periodically. We do not recommend using this endpoint to gather real-time metrics. # noqa: E501

    :param instance_id: The [Instance ID](#operation/list-instances).
    :type instance_id: str

    :rtype: InlineResponse20040
    """
    return 'do some magic!'


def get_instance_ipv4(instance_id, public_network=None, per_page=None, cursor=None):  # noqa: E501
    """List Instance IPv4 Information

    List the IPv4 information for an Instance. # noqa: E501

    :param instance_id: The [Instance ID](#operation/list-instances).
    :type instance_id: str
    :param public_network: If &#x60;true&#x60;, includes information about the public network adapter (such as MAC address) with the &#x60;main_ip&#x60; entry.
    :type public_network: bool
    :param per_page: Number of items requested per page. Default is 100 and Max is 500. 
    :type per_page: int
    :param cursor: Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination).
    :type cursor: str

    :rtype: InlineResponse20038
    """
    return 'do some magic!'


def get_instance_ipv6(instance_id):  # noqa: E501
    """Get Instance IPv6 Information

    Get the IPv6 information for an VPS Instance. # noqa: E501

    :param instance_id: The [Instance ID](#operation/list-instances).
    :type instance_id: str

    :rtype: InlineResponse20039
    """
    return 'do some magic!'


def get_instance_iso_status(instance_id):  # noqa: E501
    """Get Instance ISO Status

    Get the ISO status for an Instance. # noqa: E501

    :param instance_id: The [Instance ID](#operation/list-instances).
    :type instance_id: str

    :rtype: InlineResponse20046
    """
    return 'do some magic!'


def get_instance_neighbors(instance_id):  # noqa: E501
    """Get Instance neighbors

    Get a list of other instances in the same location as this Instance. # noqa: E501

    :param instance_id: The [Instance ID](#operation/list-instances).
    :type instance_id: str

    :rtype: InlineResponse20043
    """
    return 'do some magic!'


def get_instance_upgrades(instance_id, type=None):  # noqa: E501
    """Get Available Instance Upgrades

    Get available upgrades for an Instance # noqa: E501

    :param instance_id: The [Instance ID](#operation/list-instances).
    :type instance_id: str
    :param type: Filter upgrade by type:  - all (applications, os, plans) - applications - os - plans
    :type type: str

    :rtype: InlineResponse20051
    """
    return 'do some magic!'


def get_instance_userdata(instance_id):  # noqa: E501
    """Get Instance User Data

    Get the user-supplied, base64 encoded [user data](https://www.vultr.com/docs/manage-instance-user-data-with-the-vultr-metadata-api/) for an Instance. # noqa: E501

    :param instance_id: The [Instance ID](#operation/list-instances).
    :type instance_id: str

    :rtype: InlineResponse20050
    """
    return 'do some magic!'


def halt_instance(instance_id):  # noqa: E501
    """Halt Instance

    Halt an Instance. # noqa: E501

    :param instance_id: The [Instance ID](#operation/list-instances).
    :type instance_id: str

    :rtype: None
    """
    return 'do some magic!'


def halt_instances(body=None):  # noqa: E501
    """Halt Instances

    Halt Instances. # noqa: E501

    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        body = InstancesHaltBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def list_instance_ipv6_reverse(instance_id):  # noqa: E501
    """List Instance IPv6 Reverse

    List the reverse IPv6 information for an Instance. # noqa: E501

    :param instance_id: The [Instance ID](#operation/list-instances).
    :type instance_id: str

    :rtype: InlineResponse20048
    """
    return 'do some magic!'


def list_instance_private_networks(instance_id, per_page=None, cursor=None):  # noqa: E501
    """List instance Private Networks

    **Deprecated**: use [List Instance VPCs](#operation/list-instance-vpcs) instead.&lt;br&gt;&lt;br&gt;List the private networks for an Instance. # noqa: E501

    :param instance_id: The [Instance ID](#operation/list-instances).
    :type instance_id: str
    :param per_page: Number of items requested per page. Default is 100 and Max is 500.
    :type per_page: int
    :param cursor: Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination).
    :type cursor: str

    :rtype: InlineResponse20044
    """
    return 'do some magic!'


def list_instance_vpcs(instance_id, per_page=None, cursor=None):  # noqa: E501
    """List instance VPCs

    List the VPCs for an Instance. # noqa: E501

    :param instance_id: The [Instance ID](#operation/list-instances).
    :type instance_id: str
    :param per_page: Number of items requested per page. Default is 100 and Max is 500.
    :type per_page: int
    :param cursor: Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination).
    :type cursor: str

    :rtype: InlineResponse20045
    """
    return 'do some magic!'


def list_instances(per_page=None, cursor=None, tag=None, label=None, main_ip=None, region=None):  # noqa: E501
    """List Instances

    List all VPS instances in your account. # noqa: E501

    :param per_page: Number of items requested per page. Default is 100 and Max is 500.
    :type per_page: int
    :param cursor: Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination).
    :type cursor: str
    :param tag: Filter by specific tag.
    :type tag: str
    :param label: Filter by label.
    :type label: str
    :param main_ip: Filter by main ip address.
    :type main_ip: str
    :param region: Filter by [Region id](#operation/list-regions).
    :type region: str

    :rtype: InlineResponse20042
    """
    return 'do some magic!'


def post_instances_instance_id_ipv4_reverse_default(instance_id, body=None):  # noqa: E501
    """Set Default Reverse DNS Entry

    Set a reverse DNS entry for an IPv4 address # noqa: E501

    :param instance_id: The [Instance ID](#operation/list-instances).
    :type instance_id: str
    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        body = ReverseDefaultBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def reboot_instance(instance_id):  # noqa: E501
    """Reboot Instance

    Reboot an Instance. # noqa: E501

    :param instance_id: The [Instance ID](#operation/list-instances).
    :type instance_id: str

    :rtype: None
    """
    return 'do some magic!'


def reboot_instances(body=None):  # noqa: E501
    """Reboot instances

    Reboot Instances. # noqa: E501

    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        body = InstancesRebootBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def reinstall_instance(instance_id, body=None):  # noqa: E501
    """Reinstall Instance

    Reinstall an Instance using an optional &#x60;hostname&#x60;.  **Note:** This action may take a few extra seconds to complete. # noqa: E501

    :param instance_id: The [Instance ID](#operation/list-instances).
    :type instance_id: str
    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: InlineResponse2024
    """
    if connexion.request.is_json:
        body = InstanceidReinstallBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def restore_instance(instance_id, body=None):  # noqa: E501
    """Restore Instance

    Restore an Instance from either &#x60;backup_id&#x60; or &#x60;snapshot_id&#x60;. # noqa: E501

    :param instance_id: The [Instance ID](#operation/list-instances).
    :type instance_id: str
    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: InlineResponse2027
    """
    if connexion.request.is_json:
        body = InstanceidRestoreBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def start_instance(instance_id):  # noqa: E501
    """Start instance

    Start an Instance. # noqa: E501

    :param instance_id: The [Instance ID](#operation/list-instances).
    :type instance_id: str

    :rtype: None
    """
    return 'do some magic!'


def start_instances(body=None):  # noqa: E501
    """Start instances

    Start Instances. # noqa: E501

    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        body = InstancesStartBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def update_instance(instance_id, body=None):  # noqa: E501
    """Update Instance

    Update information for an Instance. All attributes are optional. If not set, the attributes will retain their original values.  **Note:** Changing &#x60;os_id&#x60;, &#x60;app_id&#x60; or &#x60;image_id&#x60; may take a few extra seconds to complete. # noqa: E501

    :param instance_id: The [Instance ID](#operation/list-instances).
    :type instance_id: str
    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: InlineResponse2024
    """
    if connexion.request.is_json:
        body = InstancesInstanceidBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'
