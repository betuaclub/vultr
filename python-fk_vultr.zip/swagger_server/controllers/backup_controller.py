import connexion
import six

from swagger_server.models.inline_response20016 import InlineResponse20016  # noqa: E501
from swagger_server.models.inline_response20049 import InlineResponse20049  # noqa: E501
from swagger_server import util


def get_backup(backup_id):  # noqa: E501
    """Get a Backup

    Get the information for the Backup. # noqa: E501

    :param backup_id: The [Backup id](#operation/list-backups).
    :type backup_id: str

    :rtype: InlineResponse20049
    """
    return 'do some magic!'


def list_backups(instance_id=None, per_page=None, cursor=None):  # noqa: E501
    """List Backups

    Get information about Backups in your account. # noqa: E501

    :param instance_id: Filter the backup list by [Instance id](#operation/list-instances).
    :type instance_id: str
    :param per_page: Number of items requested per page. Default is 100 and Max is 500.
    :type per_page: int
    :param cursor: Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination).
    :type cursor: str

    :rtype: InlineResponse20016
    """
    return 'do some magic!'
