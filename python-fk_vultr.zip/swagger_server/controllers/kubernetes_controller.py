import connexion
import six

from swagger_server.models.clusters_vkeid_body import ClustersVkeidBody  # noqa: E501
from swagger_server.models.inline_response20054 import InlineResponse20054  # noqa: E501
from swagger_server.models.inline_response20055 import InlineResponse20055  # noqa: E501
from swagger_server.models.inline_response20056 import InlineResponse20056  # noqa: E501
from swagger_server.models.inline_response20057 import InlineResponse20057  # noqa: E501
from swagger_server.models.inline_response20058 import InlineResponse20058  # noqa: E501
from swagger_server.models.inline_response20059 import InlineResponse20059  # noqa: E501
from swagger_server.models.inline_response2015 import InlineResponse2015  # noqa: E501
from swagger_server.models.inline_response2016 import InlineResponse2016  # noqa: E501
from swagger_server.models.kubernetes_clusters_body import KubernetesClustersBody  # noqa: E501
from swagger_server.models.nodepools_nodepoolid_body import NodepoolsNodepoolidBody  # noqa: E501
from swagger_server.models.nodepools_nodepoolid_body1 import NodepoolsNodepoolidBody1  # noqa: E501
from swagger_server.models.vkeid_nodepools_body import VkeidNodepoolsBody  # noqa: E501
from swagger_server.models.vkeid_upgrades_body import VkeidUpgradesBody  # noqa: E501
from swagger_server import util


def create_kubernetes_cluster(body=None):  # noqa: E501
    """Create Kubernetes Cluster

    Create Kubernetes Cluster # noqa: E501

    :param body: Request Body
    :type body: dict | bytes

    :rtype: InlineResponse2015
    """
    if connexion.request.is_json:
        body = KubernetesClustersBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def create_nodepools(vke_id, body=None):  # noqa: E501
    """Create NodePool

    Create NodePool for a Existing Kubernetes Cluster # noqa: E501

    :param vke_id: The [VKE ID](#operation/list-kubernetes-clusters).
    :type vke_id: str
    :param body: Request Body
    :type body: dict | bytes

    :rtype: InlineResponse2016
    """
    if connexion.request.is_json:
        body = VkeidNodepoolsBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def delete_kubernetes_cluster(vke_id):  # noqa: E501
    """Delete Kubernetes Cluster

    Delete Kubernetes Cluster # noqa: E501

    :param vke_id: The [VKE ID](#operation/list-kubernetes-clusters).
    :type vke_id: str

    :rtype: None
    """
    return 'do some magic!'


def delete_kubernetes_cluster_vke_id_delete_with_linked_resources(vke_id):  # noqa: E501
    """Delete VKE Cluster and All Related Resources

    Delete Kubernetes Cluster and all related resources.  # noqa: E501

    :param vke_id: 
    :type vke_id: str

    :rtype: None
    """
    return 'do some magic!'


def delete_nodepool(vke_id, nodepool_id):  # noqa: E501
    """Delete Nodepool

    Delete a NodePool from a Kubernetes Cluster # noqa: E501

    :param vke_id: The [VKE ID](#operation/list-kubernetes-clusters).
    :type vke_id: str
    :param nodepool_id: The [NodePool ID](#operation/get-nodepools).
    :type nodepool_id: str

    :rtype: None
    """
    return 'do some magic!'


def delete_nodepool_instance(vke_id, nodepool_id, node_id):  # noqa: E501
    """Delete NodePool Instance

    Delete a single nodepool instance from a given Nodepool # noqa: E501

    :param vke_id: The [VKE ID](#operation/list-kubernetes-clusters).
    :type vke_id: str
    :param nodepool_id: The [NodePool ID](#operation/get-nodepools).
    :type nodepool_id: str
    :param node_id: The [Instance ID](#operation/list-instances).
    :type node_id: str

    :rtype: None
    """
    return 'do some magic!'


def get_kubernetes_available_upgrades(vke_id):  # noqa: E501
    """Get Kubernetes Available Upgrades

    Get the available upgrades for the specified Kubernetes cluster. # noqa: E501

    :param vke_id: The [VKE ID](#operation/list-kubernetes-clusters).
    :type vke_id: str

    :rtype: InlineResponse20056
    """
    return 'do some magic!'


def get_kubernetes_clusters(vke_id):  # noqa: E501
    """Get Kubernetes Cluster

    Get Kubernetes Cluster # noqa: E501

    :param vke_id: The [VKE ID](#operation/list-kubernetes-clusters).
    :type vke_id: str

    :rtype: InlineResponse2015
    """
    return 'do some magic!'


def get_kubernetes_clusters_config(vke_id):  # noqa: E501
    """Get Kubernetes Cluster Kubeconfig

    Get Kubernetes Cluster Kubeconfig # noqa: E501

    :param vke_id: The [VKE ID](#operation/list-kubernetes-clusters).
    :type vke_id: str

    :rtype: InlineResponse20058
    """
    return 'do some magic!'


def get_kubernetes_resources(vke_id):  # noqa: E501
    """Get Kubernetes Resources

    Get the block storage volumes and load balancers deployed by the specified Kubernetes cluster. # noqa: E501

    :param vke_id: The [VKE ID](#operation/list-kubernetes-clusters).
    :type vke_id: str

    :rtype: InlineResponse20055
    """
    return 'do some magic!'


def get_kubernetes_versions():  # noqa: E501
    """Get Kubernetes Versions

    Get a list of supported Kubernetes versions # noqa: E501


    :rtype: InlineResponse20059
    """
    return 'do some magic!'


def get_nodepool(vke_id, nodepool_id):  # noqa: E501
    """Get NodePool

    Get Nodepool from a Kubernetes Cluster # noqa: E501

    :param vke_id: The [VKE ID](#operation/list-kubernetes-clusters).
    :type vke_id: str
    :param nodepool_id: The [NodePool ID](#operation/get-nodepools).
    :type nodepool_id: str

    :rtype: InlineResponse2016
    """
    return 'do some magic!'


def get_nodepools(vke_id):  # noqa: E501
    """List NodePools

    List all available NodePools on a Kubernetes Cluster # noqa: E501

    :param vke_id: The [VKE ID](#operation/list-kubernetes-clusters).
    :type vke_id: str

    :rtype: InlineResponse20057
    """
    return 'do some magic!'


def list_kubernetes_clusters():  # noqa: E501
    """List all Kubernetes Clusters

    List all Kubernetes clusters currently deployed # noqa: E501


    :rtype: InlineResponse20054
    """
    return 'do some magic!'


def recycle_nodepool_instance(vke_id, nodepool_id, node_id):  # noqa: E501
    """Recycle a NodePool Instance

    Recycle a specific NodePool Instance # noqa: E501

    :param vke_id: The [VKE ID](#operation/list-kubernetes-clusters).
    :type vke_id: str
    :param nodepool_id: The [NodePool ID](#operation/get-nodepools).
    :type nodepool_id: str
    :param node_id: Node ID
    :type node_id: str

    :rtype: None
    """
    return 'do some magic!'


def start_kubernetes_cluster_upgrade(vke_id, body=None):  # noqa: E501
    """Start Kubernetes Cluster Upgrade

    Start a Kubernetes cluster upgrade. # noqa: E501

    :param vke_id: The [VKE ID](#operation/list-kubernetes-clusters).
    :type vke_id: str
    :param body: Request Body
    :type body: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        body = VkeidUpgradesBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def update_kubernetes_cluster(vke_id, body=None):  # noqa: E501
    """Update Kubernetes Cluster

    Update Kubernetes Cluster # noqa: E501

    :param vke_id: The [VKE ID](#operation/list-kubernetes-clusters).
    :type vke_id: str
    :param body: Request Body
    :type body: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        body = ClustersVkeidBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def update_nodepool(vke_id, nodepool_id, body=None):  # noqa: E501
    """Update Nodepool

    Update a Nodepool on a Kubernetes Cluster # noqa: E501

    :param vke_id: The [VKE ID](#operation/list-kubernetes-clusters).
    :type vke_id: str
    :param nodepool_id: The [NodePool ID](#operation/get-nodepools).
    :type nodepool_id: str
    :param body: Request Body
    :type body: dict | bytes

    :rtype: InlineResponse2016
    """
    if connexion.request.is_json:
        body = NodepoolsNodepoolidBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def update_nodepool(vke_id, nodepool_id, body=None):  # noqa: E501
    """Update Nodepool

    Update a Nodepool on a Kubernetes Cluster # noqa: E501

    :param vke_id: The [VKE ID](#operation/list-kubernetes-clusters).
    :type vke_id: str
    :param nodepool_id: The [NodePool ID](#operation/get-nodepools).
    :type nodepool_id: str
    :param body: Request Body
    :type body: dict | bytes

    :rtype: InlineResponse2016
    """
    if connexion.request.is_json:
        body = NodepoolsNodepoolidBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'
