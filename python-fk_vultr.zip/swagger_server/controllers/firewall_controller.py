import connexion
import six

from swagger_server.models.firewallgroupid_rules_body import FirewallgroupidRulesBody  # noqa: E501
from swagger_server.models.firewalls_body import FirewallsBody  # noqa: E501
from swagger_server.models.firewalls_firewallgroupid_body import FirewallsFirewallgroupidBody  # noqa: E501
from swagger_server.models.inline_response20018 import InlineResponse20018  # noqa: E501
from swagger_server.models.inline_response20019 import InlineResponse20019  # noqa: E501
from swagger_server.models.inline_response201 import InlineResponse201  # noqa: E501
from swagger_server.models.inline_response2011 import InlineResponse2011  # noqa: E501
from swagger_server import util


def create_firewall_group(body=None):  # noqa: E501
    """Create Firewall Group

    Create a new Firewall Group. # noqa: E501

    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: InlineResponse201
    """
    if connexion.request.is_json:
        body = FirewallsBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def delete_firewall_group(firewall_group_id):  # noqa: E501
    """Delete Firewall Group

    Delete a Firewall Group. # noqa: E501

    :param firewall_group_id: The [Firewall Group id](#operation/list-firewall-groups).
    :type firewall_group_id: str

    :rtype: None
    """
    return 'do some magic!'


def delete_firewall_group_rule(firewall_group_id, firewall_rule_id):  # noqa: E501
    """Delete Firewall Rule

    Delete a Firewall Rule. # noqa: E501

    :param firewall_group_id: The [Firewall Group id](#operation/list-firewall-groups).
    :type firewall_group_id: str
    :param firewall_rule_id: The [Firewall Rule id](#operation/list-firewall-group-rules).
    :type firewall_rule_id: str

    :rtype: None
    """
    return 'do some magic!'


def get_firewall_group(firewall_group_id):  # noqa: E501
    """Get Firewall Group

    Get information for a Firewall Group. # noqa: E501

    :param firewall_group_id: The [Firewall Group id](#operation/list-firewall-groups).
    :type firewall_group_id: str

    :rtype: InlineResponse201
    """
    return 'do some magic!'


def get_firewall_group_rule(firewall_group_id, firewall_rule_id):  # noqa: E501
    """Get Firewall Rule

    Get a Firewall Rule. # noqa: E501

    :param firewall_group_id: The [Firewall Group id](#operation/list-firewall-groups).
    :type firewall_group_id: str
    :param firewall_rule_id: The [Firewall Rule id](#operation/list-firewall-group-rules).
    :type firewall_rule_id: str

    :rtype: InlineResponse2011
    """
    return 'do some magic!'


def list_firewall_group_rules(firewall_group_id, per_page=None, cursor=None):  # noqa: E501
    """List Firewall Rules

    Get the Firewall Rules for a Firewall Group. # noqa: E501

    :param firewall_group_id: The [Firewall Group id](#operation/list-firewall-groups).
    :type firewall_group_id: str
    :param per_page: Number of items requested per page. Default is 100 and Max is 500.
    :type per_page: int
    :param cursor: Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination).
    :type cursor: str

    :rtype: InlineResponse20019
    """
    return 'do some magic!'


def list_firewall_groups(per_page=None, cursor=None):  # noqa: E501
    """List Firewall Groups

    Get a list of all Firewall Groups. # noqa: E501

    :param per_page: Number of items requested per page. Default is 100 and Max is 500.
    :type per_page: int
    :param cursor: Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination).
    :type cursor: str

    :rtype: InlineResponse20018
    """
    return 'do some magic!'


def post_firewalls_firewall_group_id_rules(firewall_group_id, body=None):  # noqa: E501
    """Create Firewall Rules

    Create a Firewall Rule for a Firewall Group. The attributes &#x60;ip_type&#x60;, &#x60;protocol&#x60;, &#x60;subnet&#x60;, and &#x60;subnet_size&#x60; are required. # noqa: E501

    :param firewall_group_id: The [Firewall Group id](#operation/list-firewall-groups).
    :type firewall_group_id: str
    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: InlineResponse2011
    """
    if connexion.request.is_json:
        body = FirewallgroupidRulesBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def update_firewall_group(firewall_group_id, body=None):  # noqa: E501
    """Update Firewall Group

    Update information for a Firewall Group. # noqa: E501

    :param firewall_group_id: The [Firewall Group id](#operation/list-firewall-groups).
    :type firewall_group_id: str
    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        body = FirewallsFirewallgroupidBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'
