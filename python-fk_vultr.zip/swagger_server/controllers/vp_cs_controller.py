import connexion
import six

from swagger_server.models.inline_response2002 import InlineResponse2002  # noqa: E501
from swagger_server.models.inline_response2003 import InlineResponse2003  # noqa: E501
from swagger_server.models.vpcs_body import VpcsBody  # noqa: E501
from swagger_server.models.vpcs_vpcid_body import VpcsVpcidBody  # noqa: E501
from swagger_server import util


def create_vpc(body=None):  # noqa: E501
    """Create a VPC

    Create a new VPC in a &#x60;region&#x60;. VPCs should use [RFC1918 private address space](https://tools.ietf.org/html/rfc1918):      10.0.0.0    - 10.255.255.255  (10/8 prefix)     172.16.0.0  - 172.31.255.255  (172.16/12 prefix)     192.168.0.0 - 192.168.255.255 (192.168/16 prefix)  # noqa: E501

    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: InlineResponse2002
    """
    if connexion.request.is_json:
        body = VpcsBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def delete_vpc(vpc_id):  # noqa: E501
    """Delete a VPC

    Delete a VPC. # noqa: E501

    :param vpc_id: The [VPC ID](#operation/list-vpcs).
    :type vpc_id: str

    :rtype: None
    """
    return 'do some magic!'


def get_vpc(vpc_id):  # noqa: E501
    """Get a VPC

    Get information about a VPC. # noqa: E501

    :param vpc_id: The [VPC ID](#operation/list-vpcs).
    :type vpc_id: str

    :rtype: InlineResponse2002
    """
    return 'do some magic!'


def list_vpcs(per_page=None, cursor=None):  # noqa: E501
    """List VPCs

    Get a list of all VPCs in your account. # noqa: E501

    :param per_page: Number of items requested per page. Default is 100 and Max is 500.
    :type per_page: int
    :param cursor: Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination).
    :type cursor: str

    :rtype: InlineResponse2003
    """
    return 'do some magic!'


def update_vpc(vpc_id, body=None):  # noqa: E501
    """Update a VPC

    Update information for a VPC. # noqa: E501

    :param vpc_id: The [VPC ID](#operation/list-vpcs).
    :type vpc_id: str
    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        body = VpcsVpcidBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'
