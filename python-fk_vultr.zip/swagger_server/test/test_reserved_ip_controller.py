# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.inline_response20011 import InlineResponse20011  # noqa: E501
from swagger_server.models.inline_response20012 import InlineResponse20012  # noqa: E501
from swagger_server.models.reservedip_attach_body import ReservedipAttachBody  # noqa: E501
from swagger_server.models.reservedips_body import ReservedipsBody  # noqa: E501
from swagger_server.models.reservedips_convert_body import ReservedipsConvertBody  # noqa: E501
from swagger_server.models.reservedips_reservedip_body import ReservedipsReservedipBody  # noqa: E501
from swagger_server.test import BaseTestCase


class TestReservedIpController(BaseTestCase):
    """ReservedIpController integration test stubs"""

    def test_attach_reserved_ip(self):
        """Test case for attach_reserved_ip

        Attach Reserved IP
        """
        body = ReservedipAttachBody()
        response = self.client.open(
            '/v2/reserved-ips/{reserved-ip}/attach'.format(reserved_ip='reserved_ip_example'),
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_convert_reserved_ip(self):
        """Test case for convert_reserved_ip

        Convert Instance IP to Reserved IP
        """
        body = ReservedipsConvertBody()
        response = self.client.open(
            '/v2/reserved-ips/convert',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_create_reserved_ip(self):
        """Test case for create_reserved_ip

        Create Reserved IP
        """
        body = ReservedipsBody()
        response = self.client.open(
            '/v2/reserved-ips',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_delete_reserved_ip(self):
        """Test case for delete_reserved_ip

        Delete Reserved IP
        """
        response = self.client.open(
            '/v2/reserved-ips/{reserved-ip}'.format(reserved_ip='reserved_ip_example'),
            method='DELETE')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_detach_reserved_ip(self):
        """Test case for detach_reserved_ip

        Detach Reserved IP
        """
        response = self.client.open(
            '/v2/reserved-ips/{reserved-ip}/detach'.format(reserved_ip='reserved_ip_example'),
            method='POST')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_reserved_ip(self):
        """Test case for get_reserved_ip

        Get Reserved IP
        """
        response = self.client.open(
            '/v2/reserved-ips/{reserved-ip}'.format(reserved_ip='reserved_ip_example'),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_list_reserved_ips(self):
        """Test case for list_reserved_ips

        List Reserved IPs
        """
        query_string = [('per_page', 56),
                        ('cursor', 'cursor_example')]
        response = self.client.open(
            '/v2/reserved-ips',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_patch_reserved_ips_reserved_ip(self):
        """Test case for patch_reserved_ips_reserved_ip

        Update Reserved IP
        """
        body = ReservedipsReservedipBody()
        response = self.client.open(
            '/v2/reserved-ips/{reserved-ip}'.format(reserved_ip='reserved_ip_example'),
            method='PATCH',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
