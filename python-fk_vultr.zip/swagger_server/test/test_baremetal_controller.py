# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.baremetals_baremetalid_body import BaremetalsBaremetalidBody  # noqa: E501
from swagger_server.models.baremetals_body import BaremetalsBody  # noqa: E501
from swagger_server.models.baremetals_halt_body import BaremetalsHaltBody  # noqa: E501
from swagger_server.models.baremetals_reboot_body import BaremetalsRebootBody  # noqa: E501
from swagger_server.models.baremetals_start_body import BaremetalsStartBody  # noqa: E501
from swagger_server.models.inline_response20036 import InlineResponse20036  # noqa: E501
from swagger_server.models.inline_response20037 import InlineResponse20037  # noqa: E501
from swagger_server.models.inline_response20038 import InlineResponse20038  # noqa: E501
from swagger_server.models.inline_response20039 import InlineResponse20039  # noqa: E501
from swagger_server.models.inline_response20040 import InlineResponse20040  # noqa: E501
from swagger_server.models.inline_response20041 import InlineResponse20041  # noqa: E501
from swagger_server.models.inline_response20052 import InlineResponse20052  # noqa: E501
from swagger_server.models.inline_response20053 import InlineResponse20053  # noqa: E501
from swagger_server.models.inline_response2023 import InlineResponse2023  # noqa: E501
from swagger_server.test import BaseTestCase


class TestBaremetalController(BaseTestCase):
    """BaremetalController integration test stubs"""

    def test_create_baremetal(self):
        """Test case for create_baremetal

        Create Bare Metal Instance
        """
        body = BaremetalsBody()
        response = self.client.open(
            '/v2/bare-metals',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_delete_baremetal(self):
        """Test case for delete_baremetal

        Delete Bare Metal
        """
        response = self.client.open(
            '/v2/bare-metals/{baremetal-id}'.format(baremetal_id='baremetal_id_example'),
            method='DELETE')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_bandwidth_baremetal(self):
        """Test case for get_bandwidth_baremetal

        Bare Metal Bandwidth
        """
        response = self.client.open(
            '/v2/bare-metals/{baremetal-id}/bandwidth'.format(baremetal_id='baremetal_id_example'),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_bare_metal_userdata(self):
        """Test case for get_bare_metal_userdata

        Get Bare Metal User Data
        """
        response = self.client.open(
            '/v2/bare-metals/{baremetal-id}/user-data'.format(baremetal_id='baremetal_id_example'),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_bare_metal_vnc(self):
        """Test case for get_bare_metal_vnc

        Get VNC URL for a Bare Metal
        """
        response = self.client.open(
            '/v2/bare-metals/{baremetal-id}/vnc'.format(baremetal_id='baremetal_id_example'),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_bare_metals_upgrades(self):
        """Test case for get_bare_metals_upgrades

        Get Available Bare Metal Upgrades
        """
        query_string = [('type', 'type_example')]
        response = self.client.open(
            '/v2/bare-metals/{baremetal-id}/upgrades'.format(baremetal_id='baremetal_id_example'),
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_baremetal(self):
        """Test case for get_baremetal

        Get Bare Metal
        """
        response = self.client.open(
            '/v2/bare-metals/{baremetal-id}'.format(baremetal_id='baremetal_id_example'),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_ipv4_baremetal(self):
        """Test case for get_ipv4_baremetal

        Bare Metal IPv4 Addresses
        """
        response = self.client.open(
            '/v2/bare-metals/{baremetal-id}/ipv4'.format(baremetal_id='baremetal_id_example'),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_ipv6_baremetal(self):
        """Test case for get_ipv6_baremetal

        Bare Metal IPv6 Addresses
        """
        response = self.client.open(
            '/v2/bare-metals/{baremetal-id}/ipv6'.format(baremetal_id='baremetal_id_example'),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_halt_baremetal(self):
        """Test case for halt_baremetal

        Halt Bare Metal
        """
        response = self.client.open(
            '/v2/bare-metals/{baremetal-id}/halt'.format(baremetal_id='baremetal_id_example'),
            method='POST')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_halt_baremetals(self):
        """Test case for halt_baremetals

        Halt Bare Metals
        """
        body = BaremetalsHaltBody()
        response = self.client.open(
            '/v2/bare-metals/halt',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_list_baremetals(self):
        """Test case for list_baremetals

        List Bare Metal Instances
        """
        query_string = [('per_page', 56),
                        ('cursor', 'cursor_example')]
        response = self.client.open(
            '/v2/bare-metals',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_reboot_bare_metals(self):
        """Test case for reboot_bare_metals

        Reboot Bare Metals
        """
        body = BaremetalsRebootBody()
        response = self.client.open(
            '/v2/bare-metals/reboot',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_reboot_baremetal(self):
        """Test case for reboot_baremetal

        Reboot Bare Metal
        """
        response = self.client.open(
            '/v2/bare-metals/{baremetal-id}/reboot'.format(baremetal_id='baremetal_id_example'),
            method='POST')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_reinstall_baremetal(self):
        """Test case for reinstall_baremetal

        Reinstall Bare Metal
        """
        response = self.client.open(
            '/v2/bare-metals/{baremetal-id}/reinstall'.format(baremetal_id='baremetal_id_example'),
            method='POST')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_start_bare_metals(self):
        """Test case for start_bare_metals

        Start Bare Metals
        """
        body = BaremetalsStartBody()
        response = self.client.open(
            '/v2/bare-metals/start',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_start_baremetal(self):
        """Test case for start_baremetal

        Start Bare Metal
        """
        response = self.client.open(
            '/v2/bare-metals/{baremetal-id}/start'.format(baremetal_id='baremetal_id_example'),
            method='POST')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_update_baremetal(self):
        """Test case for update_baremetal

        Update Bare Metal
        """
        body = BaremetalsBaremetalidBody()
        response = self.client.open(
            '/v2/bare-metals/{baremetal-id}'.format(baremetal_id='baremetal_id_example'),
            method='PATCH',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
