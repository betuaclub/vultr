# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.inline_response2004 import InlineResponse2004  # noqa: E501
from swagger_server.models.user import User  # noqa: E501
from swagger_server.models.users_body import UsersBody  # noqa: E501
from swagger_server.models.users_userid_body import UsersUseridBody  # noqa: E501
from swagger_server.test import BaseTestCase


class TestUsersController(BaseTestCase):
    """UsersController integration test stubs"""

    def test_create_user(self):
        """Test case for create_user

        Create User
        """
        body = UsersBody()
        response = self.client.open(
            '/v2/users',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_delete_user(self):
        """Test case for delete_user

        Delete User
        """
        response = self.client.open(
            '/v2/users/{user-id}'.format(user_id='user_id_example'),
            method='DELETE')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_user(self):
        """Test case for get_user

        Get User
        """
        response = self.client.open(
            '/v2/users/{user-id}'.format(user_id='user_id_example'),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_list_users(self):
        """Test case for list_users

        Get Users
        """
        query_string = [('per_page', 1.2),
                        ('cursor', 'cursor_example')]
        response = self.client.open(
            '/v2/users',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_update_user(self):
        """Test case for update_user

        Update User
        """
        body = UsersUseridBody()
        response = self.client.open(
            '/v2/users/{user-id}'.format(user_id='user_id_example'),
            method='PATCH',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
