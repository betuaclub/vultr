# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.inline_response2007 import InlineResponse2007  # noqa: E501
from swagger_server.models.inline_response2008 import InlineResponse2008  # noqa: E501
from swagger_server.models.sshkeys_body import SshkeysBody  # noqa: E501
from swagger_server.models.sshkeys_sshkeyid_body import SshkeysSshkeyidBody  # noqa: E501
from swagger_server.test import BaseTestCase


class TestSshController(BaseTestCase):
    """SshController integration test stubs"""

    def test_create_ssh_key(self):
        """Test case for create_ssh_key

        Create SSH key
        """
        body = SshkeysBody()
        response = self.client.open(
            '/v2/ssh-keys',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_delete_ssh_key(self):
        """Test case for delete_ssh_key

        Delete SSH Key
        """
        response = self.client.open(
            '/v2/ssh-keys/{ssh-key-id}'.format(ssh_key_id='ssh_key_id_example'),
            method='DELETE')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_ssh_key(self):
        """Test case for get_ssh_key

        Get SSH Key
        """
        response = self.client.open(
            '/v2/ssh-keys/{ssh-key-id}'.format(ssh_key_id='ssh_key_id_example'),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_list_ssh_keys(self):
        """Test case for list_ssh_keys

        List SSH Keys
        """
        query_string = [('per_page', 56),
                        ('cursor', 'cursor_example')]
        response = self.client.open(
            '/v2/ssh-keys',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_update_ssh_key(self):
        """Test case for update_ssh_key

        Update SSH Key
        """
        body = SshkeysSshkeyidBody()
        response = self.client.open(
            '/v2/ssh-keys/{ssh-key-id}'.format(ssh_key_id='ssh_key_id_example'),
            method='PATCH',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
