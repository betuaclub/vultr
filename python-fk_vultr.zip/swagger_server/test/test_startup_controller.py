# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.inline_response2005 import InlineResponse2005  # noqa: E501
from swagger_server.models.inline_response2006 import InlineResponse2006  # noqa: E501
from swagger_server.models.startupscripts_body import StartupscriptsBody  # noqa: E501
from swagger_server.models.startupscripts_startupid_body import StartupscriptsStartupidBody  # noqa: E501
from swagger_server.test import BaseTestCase


class TestStartupController(BaseTestCase):
    """StartupController integration test stubs"""

    def test_create_startup_script(self):
        """Test case for create_startup_script

        Create Startup Script
        """
        body = StartupscriptsBody()
        response = self.client.open(
            '/v2/startup-scripts',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_delete_startup_script(self):
        """Test case for delete_startup_script

        Delete Startup Script
        """
        response = self.client.open(
            '/v2/startup-scripts/{startup-id}'.format(startup_id='startup_id_example'),
            method='DELETE')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_startup_script(self):
        """Test case for get_startup_script

        Get Startup Script
        """
        response = self.client.open(
            '/v2/startup-scripts/{startup-id}'.format(startup_id='startup_id_example'),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_list_startup_scripts(self):
        """Test case for list_startup_scripts

        List Startup Scripts
        """
        query_string = [('per_page', 56),
                        ('cursor', 'cursor_example')]
        response = self.client.open(
            '/v2/startup-scripts',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_update_startup_script(self):
        """Test case for update_startup_script

        Update Startup Script
        """
        body = StartupscriptsStartupidBody()
        response = self.client.open(
            '/v2/startup-scripts/{startup-id}'.format(startup_id='startup_id_example'),
            method='PATCH',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
