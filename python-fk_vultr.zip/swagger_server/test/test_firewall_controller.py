# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.firewallgroupid_rules_body import FirewallgroupidRulesBody  # noqa: E501
from swagger_server.models.firewalls_body import FirewallsBody  # noqa: E501
from swagger_server.models.firewalls_firewallgroupid_body import FirewallsFirewallgroupidBody  # noqa: E501
from swagger_server.models.inline_response20018 import InlineResponse20018  # noqa: E501
from swagger_server.models.inline_response20019 import InlineResponse20019  # noqa: E501
from swagger_server.models.inline_response201 import InlineResponse201  # noqa: E501
from swagger_server.models.inline_response2011 import InlineResponse2011  # noqa: E501
from swagger_server.test import BaseTestCase


class TestFirewallController(BaseTestCase):
    """FirewallController integration test stubs"""

    def test_create_firewall_group(self):
        """Test case for create_firewall_group

        Create Firewall Group
        """
        body = FirewallsBody()
        response = self.client.open(
            '/v2/firewalls',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_delete_firewall_group(self):
        """Test case for delete_firewall_group

        Delete Firewall Group
        """
        response = self.client.open(
            '/v2/firewalls/{firewall-group-id}'.format(firewall_group_id='firewall_group_id_example'),
            method='DELETE')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_delete_firewall_group_rule(self):
        """Test case for delete_firewall_group_rule

        Delete Firewall Rule
        """
        response = self.client.open(
            '/v2/firewalls/{firewall-group-id}/rules/{firewall-rule-id}'.format(firewall_group_id='firewall_group_id_example', firewall_rule_id='firewall_rule_id_example'),
            method='DELETE')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_firewall_group(self):
        """Test case for get_firewall_group

        Get Firewall Group
        """
        response = self.client.open(
            '/v2/firewalls/{firewall-group-id}'.format(firewall_group_id='firewall_group_id_example'),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_firewall_group_rule(self):
        """Test case for get_firewall_group_rule

        Get Firewall Rule
        """
        response = self.client.open(
            '/v2/firewalls/{firewall-group-id}/rules/{firewall-rule-id}'.format(firewall_group_id='firewall_group_id_example', firewall_rule_id='firewall_rule_id_example'),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_list_firewall_group_rules(self):
        """Test case for list_firewall_group_rules

        List Firewall Rules
        """
        query_string = [('per_page', 56),
                        ('cursor', 'cursor_example')]
        response = self.client.open(
            '/v2/firewalls/{firewall-group-id}/rules'.format(firewall_group_id='firewall_group_id_example'),
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_list_firewall_groups(self):
        """Test case for list_firewall_groups

        List Firewall Groups
        """
        query_string = [('per_page', 56),
                        ('cursor', 'cursor_example')]
        response = self.client.open(
            '/v2/firewalls',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_post_firewalls_firewall_group_id_rules(self):
        """Test case for post_firewalls_firewall_group_id_rules

        Create Firewall Rules
        """
        body = FirewallgroupidRulesBody()
        response = self.client.open(
            '/v2/firewalls/{firewall-group-id}/rules'.format(firewall_group_id='firewall_group_id_example'),
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_update_firewall_group(self):
        """Test case for update_firewall_group

        Update Firewall Group
        """
        body = FirewallsFirewallgroupidBody()
        response = self.client.open(
            '/v2/firewalls/{firewall-group-id}'.format(firewall_group_id='firewall_group_id_example'),
            method='PUT',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
