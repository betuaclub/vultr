<?php
/**
 * InstancesInstanceidBody
 *
 * PHP version 5
 *
 * @category Class
 * @package  Swagger\Client
 * @author   Swagger Codegen team
 * @link     https://github.com/swagger-api/swagger-codegen
 */

/**
 * Vultr API
 *
 * # Introduction  The Vultr API v2 is a set of HTTP endpoints that adhere to RESTful design principles and CRUD actions with predictable URIs. It uses standard HTTP response codes, authentication, and verbs. The API has consistent and well-formed JSON requests and responses with cursor-based pagination to simplify list handling. Error messages are descriptive and easy to understand. All functions of the Vultr customer portal are accessible via the API, enabling you to script complex unattended scenarios with any tool fluent in HTTP.  ## Requests  Communicate with the API by making an HTTP request at the correct endpoint. The chosen method determines the action taken.  | Method | Usage | | ------ | ------------- | | DELETE | Use the DELETE method to destroy a resource in your account. If it is not found, the operation will return a 4xx error and an appropriate message. | | GET | To retrieve information about a resource, use the GET method. The data is returned as a JSON object. GET methods are read-only and do not affect any resources. | | PATCH | Some resources support partial modification with PATCH, which modifies specific attributes without updating the entire object representation. | | POST | Issue a POST method to create a new object. Include all needed attributes in the request body encoded as JSON. | | PUT | Use the PUT method to update information about a resource. PUT will set new values on the item without regard to their current values. |  **Rate Limit:** Vultr safeguards the API against bursts of incoming traffic based on the request's IP address to ensure stability for all users. If your application sends more than 30 requests per second, the API may return HTTP status code 429.  ## Response Codes  We use standard HTTP response codes to show the success or failure of requests. Response codes in the 2xx range indicate success, while codes in the 4xx range indicate an error, such as an authorization failure or a malformed request. All 4xx errors will return a JSON response object with an `error` attribute explaining the error. Codes in the 5xx range indicate a server-side problem preventing Vultr from fulfilling your request.  | Response | Description | | ------ | ------------- | | 200 OK | The response contains your requested information. | | 201 Created | Your request was accepted. The resource was created. | | 202 Accepted | Your request was accepted. The resource was created or updated. | | 204 No Content | Your request succeeded, there is no additional information returned. | | 400 Bad Request | Your request was malformed. | | 401 Unauthorized | You did not supply valid authentication credentials. | | 403 Forbidden | You are not allowed to perform that action. | | 404 Not Found | No results were found for your request. | | 429 Too Many Requests | Your request exceeded the API rate limit. | | 500 Internal Server Error | We were unable to perform the request due to server-side problems. |  ## Meta and Pagination  Many API calls will return a `meta` object with paging information.  ### Definitions  | Term | Description | | ------ | ------------- | | List | All items available from your request. | | Page | A subset of a List. Choose the size of a Page with the `per_page` parameter. | | Total | The `total` attribute indicates the number of items in the full List.| | Cursor | Use the `cursor` query parameter to select a next or previous Page. | | Next & Prev | Use the `next` and `prev` attributes of the `links` meta object as `cursor` values. |  ### How to use Paging  You can request paging by setting the `per_page` query parameter.  ### Paging Example  > These examples have abbreviated attributes and sample values. Your actual `cursor` values will be encoded alphanumeric strings.  To return a Page with the first two Plans in the List:      curl \"https://api.vultr.com/v2/plans?per_page=2\" \\       -X GET \\       -H \"Authorization: Bearer ${VULTR_API_KEY}\"  The API returns an object similar to this:      {         \"plans\": [             {                 \"id\": \"vc2-1c-2gb\",                 \"vcpu_count\": 1,                 \"ram\": 2048,                 \"locations\": []             },             {                 \"id\": \"vc2-24c-97gb\",                 \"vcpu_count\": 24,                 \"ram\": 98304,                 \"locations\": []             }         ],         \"meta\": {             \"total\": 19,             \"links\": {                 \"next\": \"WxYzExampleNext\",                 \"prev\": \"WxYzExamplePrev\"             }         }     }  The object contains two plans. The `total` attribute indicates that 19 plans are available in the List. To navigate forward in the List, use the `next` value (**WxYzExampleNext** in this example) as your `cursor` query parameter.      curl \"https://api.vultr.com/v2/plans?per_page=2&cursor=WxYzExampleNext\" \\       -X GET       -H \"Authorization: Bearer ${VULTR_API_KEY}\"  Likewise, you can use the example `prev` value **WxYzExamplePrev** to navigate backward.  ## Parameters  You can pass information to the API with three different types of parameters.  ### Path parameters  Some API calls require variable parameters as part of the endpoint path. For example, to retrieve information about a user, supply the `user-id` in the endpoint.      curl \"https://api.vultr.com/v2/users/{user-id}\" \\       -X GET \\       -H \"Authorization: Bearer ${VULTR_API_KEY}\"  ### Query parameters  Some API calls allow filtering with query parameters. For example, the `/v2/plans` endpoint supports a `type` query parameter. Setting `type=vhf` instructs the API only to return High Frequency Compute plans in the list. You'll find more specifics about valid filters in the endpoint documentation below.      curl \"https://api.vultr.com/v2/plans?type=vhf\" \\       -X GET \\       -H \"Authorization: Bearer ${VULTR_API_KEY}\"  You can also combine filtering with paging. Use the `per_page` parameter to retreive a subset of vhf plans.      curl \"https://api.vultr.com/v2/plans?type=vhf&per_page=2\" \\       -X GET \\       -H \"Authorization: Bearer ${VULTR_API_KEY}\"  ### Request Body  PUT, POST, and PATCH methods may include an object in the request body with a content type of **application/json**. The documentation for each endpoint below has more information about the expected object.  ## API Example Conventions  The examples in this documentation use `curl`, a command-line HTTP client, to demonstrate useage. Linux and macOS computers usually have curl installed by default, and it's [available for download](https://curl.se/download.html) on all popular platforms including Windows.  Each example is split across multiple lines with the `\\` character, which is compatible with a `bash` terminal. A typical example looks like this:      curl \"https://api.vultr.com/v2/domains\" \\       -X POST \\       -H \"Authorization: Bearer ${VULTR_API_KEY}\" \\       -H \"Content-Type: application/json\" \\       --data '{         \"domain\" : \"example.com\",         \"ip\" : \"192.0.2.123\"       }'  * The `-X` parameter sets the request method. For consistency, we show the method on all examples, even though it's not explicitly required for GET methods. * The `-H` lines set required HTTP headers. These examples are formatted to expand the VULTR\\_API\\_KEY environment variable for your convenience. * Examples that require a JSON object in the request body pass the required data via the `--data` parameter.  All values in this guide are examples. Do not rely on the OS or Plan IDs listed in this guide; use the appropriate endpoint to retreive values before creating resources.  # Authentication  <!-- ReDoc-Inject: <security-definitions> -->
 *
 * OpenAPI spec version: 2.0
 * Contact: opensource@vultr.com
 * Generated by: https://github.com/swagger-api/swagger-codegen.git
 * Swagger Codegen version: 3.0.35
 */
/**
 * NOTE: This class is auto generated by the swagger code generator program.
 * https://github.com/swagger-api/swagger-codegen
 * Do not edit the class manually.
 */

namespace Swagger\Client\Model;

use \ArrayAccess;
use \Swagger\Client\ObjectSerializer;

/**
 * InstancesInstanceidBody Class Doc Comment
 *
 * @category Class
 * @package  Swagger\Client
 * @author   Swagger Codegen team
 * @link     https://github.com/swagger-api/swagger-codegen
 */
class InstancesInstanceidBody implements ModelInterface, ArrayAccess
{
    const DISCRIMINATOR = null;

    /**
      * The original name of the model.
      *
      * @var string
      */
    protected static $swaggerModelName = 'instances_instanceid_body';

    /**
      * Array of property to type mappings. Used for (de)serialization
      *
      * @var string[]
      */
    protected static $swaggerTypes = [
        'app_id' => 'int',
'image_id' => 'string',
'backups' => 'string',
'firewall_group_id' => 'string',
'enable_ipv6' => 'bool',
'os_id' => 'string',
'user_data' => 'string',
'tag' => 'string',
'plan' => 'string',
'ddos_protection' => 'bool',
'attach_private_network' => 'string[]',
'attach_vpc' => 'string[]',
'detach_private_network' => 'string[]',
'detach_vpc' => 'string[]',
'enable_private_network' => 'bool',
'enable_vpc' => 'bool',
'label' => 'string',
'tags' => 'string[]'    ];

    /**
      * Array of property to format mappings. Used for (de)serialization
      *
      * @var string[]
      */
    protected static $swaggerFormats = [
        'app_id' => null,
'image_id' => null,
'backups' => null,
'firewall_group_id' => null,
'enable_ipv6' => null,
'os_id' => null,
'user_data' => null,
'tag' => null,
'plan' => null,
'ddos_protection' => null,
'attach_private_network' => null,
'attach_vpc' => null,
'detach_private_network' => null,
'detach_vpc' => null,
'enable_private_network' => null,
'enable_vpc' => null,
'label' => null,
'tags' => null    ];

    /**
     * Array of property to type mappings. Used for (de)serialization
     *
     * @return array
     */
    public static function swaggerTypes()
    {
        return self::$swaggerTypes;
    }

    /**
     * Array of property to format mappings. Used for (de)serialization
     *
     * @return array
     */
    public static function swaggerFormats()
    {
        return self::$swaggerFormats;
    }

    /**
     * Array of attributes where the key is the local name,
     * and the value is the original name
     *
     * @var string[]
     */
    protected static $attributeMap = [
        'app_id' => 'app_id',
'image_id' => 'image_id',
'backups' => 'backups',
'firewall_group_id' => 'firewall_group_id',
'enable_ipv6' => 'enable_ipv6',
'os_id' => 'os_id',
'user_data' => 'user_data',
'tag' => 'tag',
'plan' => 'plan',
'ddos_protection' => 'ddos_protection',
'attach_private_network' => 'attach_private_network',
'attach_vpc' => 'attach_vpc',
'detach_private_network' => 'detach_private_network',
'detach_vpc' => 'detach_vpc',
'enable_private_network' => 'enable_private_network',
'enable_vpc' => 'enable_vpc',
'label' => 'label',
'tags' => 'tags'    ];

    /**
     * Array of attributes to setter functions (for deserialization of responses)
     *
     * @var string[]
     */
    protected static $setters = [
        'app_id' => 'setAppId',
'image_id' => 'setImageId',
'backups' => 'setBackups',
'firewall_group_id' => 'setFirewallGroupId',
'enable_ipv6' => 'setEnableIpv6',
'os_id' => 'setOsId',
'user_data' => 'setUserData',
'tag' => 'setTag',
'plan' => 'setPlan',
'ddos_protection' => 'setDdosProtection',
'attach_private_network' => 'setAttachPrivateNetwork',
'attach_vpc' => 'setAttachVpc',
'detach_private_network' => 'setDetachPrivateNetwork',
'detach_vpc' => 'setDetachVpc',
'enable_private_network' => 'setEnablePrivateNetwork',
'enable_vpc' => 'setEnableVpc',
'label' => 'setLabel',
'tags' => 'setTags'    ];

    /**
     * Array of attributes to getter functions (for serialization of requests)
     *
     * @var string[]
     */
    protected static $getters = [
        'app_id' => 'getAppId',
'image_id' => 'getImageId',
'backups' => 'getBackups',
'firewall_group_id' => 'getFirewallGroupId',
'enable_ipv6' => 'getEnableIpv6',
'os_id' => 'getOsId',
'user_data' => 'getUserData',
'tag' => 'getTag',
'plan' => 'getPlan',
'ddos_protection' => 'getDdosProtection',
'attach_private_network' => 'getAttachPrivateNetwork',
'attach_vpc' => 'getAttachVpc',
'detach_private_network' => 'getDetachPrivateNetwork',
'detach_vpc' => 'getDetachVpc',
'enable_private_network' => 'getEnablePrivateNetwork',
'enable_vpc' => 'getEnableVpc',
'label' => 'getLabel',
'tags' => 'getTags'    ];

    /**
     * Array of attributes where the key is the local name,
     * and the value is the original name
     *
     * @return array
     */
    public static function attributeMap()
    {
        return self::$attributeMap;
    }

    /**
     * Array of attributes to setter functions (for deserialization of responses)
     *
     * @return array
     */
    public static function setters()
    {
        return self::$setters;
    }

    /**
     * Array of attributes to getter functions (for serialization of requests)
     *
     * @return array
     */
    public static function getters()
    {
        return self::$getters;
    }

    /**
     * The original name of the model.
     *
     * @return string
     */
    public function getModelName()
    {
        return self::$swaggerModelName;
    }

    

    /**
     * Associative array for storing property values
     *
     * @var mixed[]
     */
    protected $container = [];

    /**
     * Constructor
     *
     * @param mixed[] $data Associated array of property values
     *                      initializing the model
     */
    public function __construct(array $data = null)
    {
        $this->container['app_id'] = isset($data['app_id']) ? $data['app_id'] : null;
        $this->container['image_id'] = isset($data['image_id']) ? $data['image_id'] : null;
        $this->container['backups'] = isset($data['backups']) ? $data['backups'] : null;
        $this->container['firewall_group_id'] = isset($data['firewall_group_id']) ? $data['firewall_group_id'] : null;
        $this->container['enable_ipv6'] = isset($data['enable_ipv6']) ? $data['enable_ipv6'] : null;
        $this->container['os_id'] = isset($data['os_id']) ? $data['os_id'] : null;
        $this->container['user_data'] = isset($data['user_data']) ? $data['user_data'] : null;
        $this->container['tag'] = isset($data['tag']) ? $data['tag'] : null;
        $this->container['plan'] = isset($data['plan']) ? $data['plan'] : null;
        $this->container['ddos_protection'] = isset($data['ddos_protection']) ? $data['ddos_protection'] : null;
        $this->container['attach_private_network'] = isset($data['attach_private_network']) ? $data['attach_private_network'] : null;
        $this->container['attach_vpc'] = isset($data['attach_vpc']) ? $data['attach_vpc'] : null;
        $this->container['detach_private_network'] = isset($data['detach_private_network']) ? $data['detach_private_network'] : null;
        $this->container['detach_vpc'] = isset($data['detach_vpc']) ? $data['detach_vpc'] : null;
        $this->container['enable_private_network'] = isset($data['enable_private_network']) ? $data['enable_private_network'] : null;
        $this->container['enable_vpc'] = isset($data['enable_vpc']) ? $data['enable_vpc'] : null;
        $this->container['label'] = isset($data['label']) ? $data['label'] : null;
        $this->container['tags'] = isset($data['tags']) ? $data['tags'] : null;
    }

    /**
     * Show all the invalid properties with reasons.
     *
     * @return array invalid properties with reasons
     */
    public function listInvalidProperties()
    {
        $invalidProperties = [];

        return $invalidProperties;
    }

    /**
     * Validate all the properties in the model
     * return true if all passed
     *
     * @return bool True if all properties are valid
     */
    public function valid()
    {
        return count($this->listInvalidProperties()) === 0;
    }


    /**
     * Gets app_id
     *
     * @return int
     */
    public function getAppId()
    {
        return $this->container['app_id'];
    }

    /**
     * Sets app_id
     *
     * @param int $app_id Reinstall the instance with this [Application id](#operation/list-applications).
     *
     * @return $this
     */
    public function setAppId($app_id)
    {
        $this->container['app_id'] = $app_id;

        return $this;
    }

    /**
     * Gets image_id
     *
     * @return string
     */
    public function getImageId()
    {
        return $this->container['image_id'];
    }

    /**
     * Sets image_id
     *
     * @param string $image_id Reinstall the instance with this [Application image_id](#operation/list-applications).
     *
     * @return $this
     */
    public function setImageId($image_id)
    {
        $this->container['image_id'] = $image_id;

        return $this;
    }

    /**
     * Gets backups
     *
     * @return string
     */
    public function getBackups()
    {
        return $this->container['backups'];
    }

    /**
     * Sets backups
     *
     * @param string $backups Enable automatic backups for the instance.  * enabled * disabled
     *
     * @return $this
     */
    public function setBackups($backups)
    {
        $this->container['backups'] = $backups;

        return $this;
    }

    /**
     * Gets firewall_group_id
     *
     * @return string
     */
    public function getFirewallGroupId()
    {
        return $this->container['firewall_group_id'];
    }

    /**
     * Sets firewall_group_id
     *
     * @param string $firewall_group_id The [Firewall Group id](#operation/list-firewall-groups) to attach to this Instance.
     *
     * @return $this
     */
    public function setFirewallGroupId($firewall_group_id)
    {
        $this->container['firewall_group_id'] = $firewall_group_id;

        return $this;
    }

    /**
     * Gets enable_ipv6
     *
     * @return bool
     */
    public function getEnableIpv6()
    {
        return $this->container['enable_ipv6'];
    }

    /**
     * Sets enable_ipv6
     *
     * @param bool $enable_ipv6 Enable IPv6.  * true * false
     *
     * @return $this
     */
    public function setEnableIpv6($enable_ipv6)
    {
        $this->container['enable_ipv6'] = $enable_ipv6;

        return $this;
    }

    /**
     * Gets os_id
     *
     * @return string
     */
    public function getOsId()
    {
        return $this->container['os_id'];
    }

    /**
     * Sets os_id
     *
     * @param string $os_id Reinstall the instance with this [ISO id](#operation/list-isos).
     *
     * @return $this
     */
    public function setOsId($os_id)
    {
        $this->container['os_id'] = $os_id;

        return $this;
    }

    /**
     * Gets user_data
     *
     * @return string
     */
    public function getUserData()
    {
        return $this->container['user_data'];
    }

    /**
     * Sets user_data
     *
     * @param string $user_data The user-supplied, base64 encoded [user data](https://www.vultr.com/docs/manage-instance-user-data-with-the-vultr-metadata-api/) to attach to this instance.
     *
     * @return $this
     */
    public function setUserData($user_data)
    {
        $this->container['user_data'] = $user_data;

        return $this;
    }

    /**
     * Gets tag
     *
     * @return string
     */
    public function getTag()
    {
        return $this->container['tag'];
    }

    /**
     * Sets tag
     *
     * @param string $tag Use `tags` instead. The user-supplied tag.
     *
     * @return $this
     */
    public function setTag($tag)
    {
        $this->container['tag'] = $tag;

        return $this;
    }

    /**
     * Gets plan
     *
     * @return string
     */
    public function getPlan()
    {
        return $this->container['plan'];
    }

    /**
     * Sets plan
     *
     * @param string $plan Upgrade the instance with this [Plan id](#operation/list-plans).
     *
     * @return $this
     */
    public function setPlan($plan)
    {
        $this->container['plan'] = $plan;

        return $this;
    }

    /**
     * Gets ddos_protection
     *
     * @return bool
     */
    public function getDdosProtection()
    {
        return $this->container['ddos_protection'];
    }

    /**
     * Sets ddos_protection
     *
     * @param bool $ddos_protection Enable DDoS Protection (there is an additional charge for this).  * true * false
     *
     * @return $this
     */
    public function setDdosProtection($ddos_protection)
    {
        $this->container['ddos_protection'] = $ddos_protection;

        return $this;
    }

    /**
     * Gets attach_private_network
     *
     * @return string[]
     */
    public function getAttachPrivateNetwork()
    {
        return $this->container['attach_private_network'];
    }

    /**
     * Sets attach_private_network
     *
     * @param string[] $attach_private_network Use `attach_vpc` instead. An array of [Private Network ids](#operation/list-networks) to attach to this Instance. This parameter takes precedence over `enable_private_network`. Please choose one parameter.
     *
     * @return $this
     */
    public function setAttachPrivateNetwork($attach_private_network)
    {
        $this->container['attach_private_network'] = $attach_private_network;

        return $this;
    }

    /**
     * Gets attach_vpc
     *
     * @return string[]
     */
    public function getAttachVpc()
    {
        return $this->container['attach_vpc'];
    }

    /**
     * Sets attach_vpc
     *
     * @param string[] $attach_vpc An array of [VPC IDs](#operation/list-vpcs) to attach to this Instance. This parameter takes precedence over `enable_vpc`. Please choose one parameter.
     *
     * @return $this
     */
    public function setAttachVpc($attach_vpc)
    {
        $this->container['attach_vpc'] = $attach_vpc;

        return $this;
    }

    /**
     * Gets detach_private_network
     *
     * @return string[]
     */
    public function getDetachPrivateNetwork()
    {
        return $this->container['detach_private_network'];
    }

    /**
     * Sets detach_private_network
     *
     * @param string[] $detach_private_network Use `detach_vpc` instead. An array of [Private Network ids](#operation/list-networks) to detach from this Instance. This parameter takes precedence over `enable_private_network`.
     *
     * @return $this
     */
    public function setDetachPrivateNetwork($detach_private_network)
    {
        $this->container['detach_private_network'] = $detach_private_network;

        return $this;
    }

    /**
     * Gets detach_vpc
     *
     * @return string[]
     */
    public function getDetachVpc()
    {
        return $this->container['detach_vpc'];
    }

    /**
     * Sets detach_vpc
     *
     * @param string[] $detach_vpc An array of [VPC IDs](#operation/list-vpcs) to detach from this Instance. This parameter takes precedence over `enable_vpc`.
     *
     * @return $this
     */
    public function setDetachVpc($detach_vpc)
    {
        $this->container['detach_vpc'] = $detach_vpc;

        return $this;
    }

    /**
     * Gets enable_private_network
     *
     * @return bool
     */
    public function getEnablePrivateNetwork()
    {
        return $this->container['enable_private_network'];
    }

    /**
     * Sets enable_private_network
     *
     * @param bool $enable_private_network Use `enable_vpc` instead.  If `true`, private networking support will be added to the new server.  This parameter attaches a single network. When no network exists in the region, it will be automatically created.  If there are multiple private networks in the instance's region, use `attach_private_network` instead to specify a network.
     *
     * @return $this
     */
    public function setEnablePrivateNetwork($enable_private_network)
    {
        $this->container['enable_private_network'] = $enable_private_network;

        return $this;
    }

    /**
     * Gets enable_vpc
     *
     * @return bool
     */
    public function getEnableVpc()
    {
        return $this->container['enable_vpc'];
    }

    /**
     * Sets enable_vpc
     *
     * @param bool $enable_vpc If `true`, VPC support will be added to the new server.  This parameter attaches a single VPC. When no VPC exists in the region, it will be automatically created.  If there are multiple VPCs in the instance's region, use `attach_vpc` instead to specify a VPC.
     *
     * @return $this
     */
    public function setEnableVpc($enable_vpc)
    {
        $this->container['enable_vpc'] = $enable_vpc;

        return $this;
    }

    /**
     * Gets label
     *
     * @return string
     */
    public function getLabel()
    {
        return $this->container['label'];
    }

    /**
     * Sets label
     *
     * @param string $label The user supplied label
     *
     * @return $this
     */
    public function setLabel($label)
    {
        $this->container['label'] = $label;

        return $this;
    }

    /**
     * Gets tags
     *
     * @return string[]
     */
    public function getTags()
    {
        return $this->container['tags'];
    }

    /**
     * Sets tags
     *
     * @param string[] $tags Tags to apply to the instance
     *
     * @return $this
     */
    public function setTags($tags)
    {
        $this->container['tags'] = $tags;

        return $this;
    }
    /**
     * Returns true if offset exists. False otherwise.
     *
     * @param integer $offset Offset
     *
     * @return boolean
     */
    public function offsetExists($offset)
    {
        return isset($this->container[$offset]);
    }

    /**
     * Gets offset.
     *
     * @param integer $offset Offset
     *
     * @return mixed
     */
    public function offsetGet($offset)
    {
        return isset($this->container[$offset]) ? $this->container[$offset] : null;
    }

    /**
     * Sets value based on offset.
     *
     * @param integer $offset Offset
     * @param mixed   $value  Value to be set
     *
     * @return void
     */
    public function offsetSet($offset, $value)
    {
        if (is_null($offset)) {
            $this->container[] = $value;
        } else {
            $this->container[$offset] = $value;
        }
    }

    /**
     * Unsets offset.
     *
     * @param integer $offset Offset
     *
     * @return void
     */
    public function offsetUnset($offset)
    {
        unset($this->container[$offset]);
    }

    /**
     * Gets the string presentation of the object
     *
     * @return string
     */
    public function __toString()
    {
        if (defined('JSON_PRETTY_PRINT')) { // use JSON pretty print
            return json_encode(
                ObjectSerializer::sanitizeForSerialization($this),
                JSON_PRETTY_PRINT
            );
        }

        return json_encode(ObjectSerializer::sanitizeForSerialization($this));
    }
}
