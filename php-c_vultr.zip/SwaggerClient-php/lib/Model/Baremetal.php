<?php
/**
 * Baremetal
 *
 * PHP version 5
 *
 * @category Class
 * @package  Swagger\Client
 * @author   Swagger Codegen team
 * @link     https://github.com/swagger-api/swagger-codegen
 */

/**
 * Vultr API
 *
 * # Introduction  The Vultr API v2 is a set of HTTP endpoints that adhere to RESTful design principles and CRUD actions with predictable URIs. It uses standard HTTP response codes, authentication, and verbs. The API has consistent and well-formed JSON requests and responses with cursor-based pagination to simplify list handling. Error messages are descriptive and easy to understand. All functions of the Vultr customer portal are accessible via the API, enabling you to script complex unattended scenarios with any tool fluent in HTTP.  ## Requests  Communicate with the API by making an HTTP request at the correct endpoint. The chosen method determines the action taken.  | Method | Usage | | ------ | ------------- | | DELETE | Use the DELETE method to destroy a resource in your account. If it is not found, the operation will return a 4xx error and an appropriate message. | | GET | To retrieve information about a resource, use the GET method. The data is returned as a JSON object. GET methods are read-only and do not affect any resources. | | PATCH | Some resources support partial modification with PATCH, which modifies specific attributes without updating the entire object representation. | | POST | Issue a POST method to create a new object. Include all needed attributes in the request body encoded as JSON. | | PUT | Use the PUT method to update information about a resource. PUT will set new values on the item without regard to their current values. |  **Rate Limit:** Vultr safeguards the API against bursts of incoming traffic based on the request's IP address to ensure stability for all users. If your application sends more than 30 requests per second, the API may return HTTP status code 429.  ## Response Codes  We use standard HTTP response codes to show the success or failure of requests. Response codes in the 2xx range indicate success, while codes in the 4xx range indicate an error, such as an authorization failure or a malformed request. All 4xx errors will return a JSON response object with an `error` attribute explaining the error. Codes in the 5xx range indicate a server-side problem preventing Vultr from fulfilling your request.  | Response | Description | | ------ | ------------- | | 200 OK | The response contains your requested information. | | 201 Created | Your request was accepted. The resource was created. | | 202 Accepted | Your request was accepted. The resource was created or updated. | | 204 No Content | Your request succeeded, there is no additional information returned. | | 400 Bad Request | Your request was malformed. | | 401 Unauthorized | You did not supply valid authentication credentials. | | 403 Forbidden | You are not allowed to perform that action. | | 404 Not Found | No results were found for your request. | | 429 Too Many Requests | Your request exceeded the API rate limit. | | 500 Internal Server Error | We were unable to perform the request due to server-side problems. |  ## Meta and Pagination  Many API calls will return a `meta` object with paging information.  ### Definitions  | Term | Description | | ------ | ------------- | | List | All items available from your request. | | Page | A subset of a List. Choose the size of a Page with the `per_page` parameter. | | Total | The `total` attribute indicates the number of items in the full List.| | Cursor | Use the `cursor` query parameter to select a next or previous Page. | | Next & Prev | Use the `next` and `prev` attributes of the `links` meta object as `cursor` values. |  ### How to use Paging  You can request paging by setting the `per_page` query parameter.  ### Paging Example  > These examples have abbreviated attributes and sample values. Your actual `cursor` values will be encoded alphanumeric strings.  To return a Page with the first two Plans in the List:      curl \"https://api.vultr.com/v2/plans?per_page=2\" \\       -X GET \\       -H \"Authorization: Bearer ${VULTR_API_KEY}\"  The API returns an object similar to this:      {         \"plans\": [             {                 \"id\": \"vc2-1c-2gb\",                 \"vcpu_count\": 1,                 \"ram\": 2048,                 \"locations\": []             },             {                 \"id\": \"vc2-24c-97gb\",                 \"vcpu_count\": 24,                 \"ram\": 98304,                 \"locations\": []             }         ],         \"meta\": {             \"total\": 19,             \"links\": {                 \"next\": \"WxYzExampleNext\",                 \"prev\": \"WxYzExamplePrev\"             }         }     }  The object contains two plans. The `total` attribute indicates that 19 plans are available in the List. To navigate forward in the List, use the `next` value (**WxYzExampleNext** in this example) as your `cursor` query parameter.      curl \"https://api.vultr.com/v2/plans?per_page=2&cursor=WxYzExampleNext\" \\       -X GET       -H \"Authorization: Bearer ${VULTR_API_KEY}\"  Likewise, you can use the example `prev` value **WxYzExamplePrev** to navigate backward.  ## Parameters  You can pass information to the API with three different types of parameters.  ### Path parameters  Some API calls require variable parameters as part of the endpoint path. For example, to retrieve information about a user, supply the `user-id` in the endpoint.      curl \"https://api.vultr.com/v2/users/{user-id}\" \\       -X GET \\       -H \"Authorization: Bearer ${VULTR_API_KEY}\"  ### Query parameters  Some API calls allow filtering with query parameters. For example, the `/v2/plans` endpoint supports a `type` query parameter. Setting `type=vhf` instructs the API only to return High Frequency Compute plans in the list. You'll find more specifics about valid filters in the endpoint documentation below.      curl \"https://api.vultr.com/v2/plans?type=vhf\" \\       -X GET \\       -H \"Authorization: Bearer ${VULTR_API_KEY}\"  You can also combine filtering with paging. Use the `per_page` parameter to retreive a subset of vhf plans.      curl \"https://api.vultr.com/v2/plans?type=vhf&per_page=2\" \\       -X GET \\       -H \"Authorization: Bearer ${VULTR_API_KEY}\"  ### Request Body  PUT, POST, and PATCH methods may include an object in the request body with a content type of **application/json**. The documentation for each endpoint below has more information about the expected object.  ## API Example Conventions  The examples in this documentation use `curl`, a command-line HTTP client, to demonstrate useage. Linux and macOS computers usually have curl installed by default, and it's [available for download](https://curl.se/download.html) on all popular platforms including Windows.  Each example is split across multiple lines with the `\\` character, which is compatible with a `bash` terminal. A typical example looks like this:      curl \"https://api.vultr.com/v2/domains\" \\       -X POST \\       -H \"Authorization: Bearer ${VULTR_API_KEY}\" \\       -H \"Content-Type: application/json\" \\       --data '{         \"domain\" : \"example.com\",         \"ip\" : \"192.0.2.123\"       }'  * The `-X` parameter sets the request method. For consistency, we show the method on all examples, even though it's not explicitly required for GET methods. * The `-H` lines set required HTTP headers. These examples are formatted to expand the VULTR\\_API\\_KEY environment variable for your convenience. * Examples that require a JSON object in the request body pass the required data via the `--data` parameter.  All values in this guide are examples. Do not rely on the OS or Plan IDs listed in this guide; use the appropriate endpoint to retreive values before creating resources.  # Authentication  <!-- ReDoc-Inject: <security-definitions> -->
 *
 * OpenAPI spec version: 2.0
 * Contact: opensource@vultr.com
 * Generated by: https://github.com/swagger-api/swagger-codegen.git
 * Swagger Codegen version: 3.0.35
 */
/**
 * NOTE: This class is auto generated by the swagger code generator program.
 * https://github.com/swagger-api/swagger-codegen
 * Do not edit the class manually.
 */

namespace Swagger\Client\Model;

use \ArrayAccess;
use \Swagger\Client\ObjectSerializer;

/**
 * Baremetal Class Doc Comment
 *
 * @category Class
 * @description Bare Metal information.
 * @package  Swagger\Client
 * @author   Swagger Codegen team
 * @link     https://github.com/swagger-api/swagger-codegen
 */
class Baremetal implements ModelInterface, ArrayAccess
{
    const DISCRIMINATOR = null;

    /**
      * The original name of the model.
      *
      * @var string
      */
    protected static $swaggerModelName = 'baremetal';

    /**
      * Array of property to type mappings. Used for (de)serialization
      *
      * @var string[]
      */
    protected static $swaggerTypes = [
        'id' => 'string',
'os' => 'string',
'ram' => 'string',
'disk' => 'string',
'main_ip' => 'string',
'cpu_count' => 'int',
'region' => 'string',
'default_password' => 'string',
'date_created' => 'string',
'status' => 'string',
'netmask_v4' => 'string',
'gateway_v4' => 'string',
'plan' => 'string',
'label' => 'string',
'tag' => 'string',
'os_id' => 'int',
'app_id' => 'int',
'image_id' => 'string',
'v6_network' => 'string',
'v6_main_ip' => 'string',
'v6_network_size' => 'int',
'mac_address' => 'int',
'tags' => 'string[]'    ];

    /**
      * Array of property to format mappings. Used for (de)serialization
      *
      * @var string[]
      */
    protected static $swaggerFormats = [
        'id' => null,
'os' => null,
'ram' => null,
'disk' => null,
'main_ip' => null,
'cpu_count' => null,
'region' => null,
'default_password' => null,
'date_created' => null,
'status' => null,
'netmask_v4' => null,
'gateway_v4' => null,
'plan' => null,
'label' => null,
'tag' => null,
'os_id' => null,
'app_id' => null,
'image_id' => null,
'v6_network' => null,
'v6_main_ip' => null,
'v6_network_size' => null,
'mac_address' => null,
'tags' => null    ];

    /**
     * Array of property to type mappings. Used for (de)serialization
     *
     * @return array
     */
    public static function swaggerTypes()
    {
        return self::$swaggerTypes;
    }

    /**
     * Array of property to format mappings. Used for (de)serialization
     *
     * @return array
     */
    public static function swaggerFormats()
    {
        return self::$swaggerFormats;
    }

    /**
     * Array of attributes where the key is the local name,
     * and the value is the original name
     *
     * @var string[]
     */
    protected static $attributeMap = [
        'id' => 'id',
'os' => 'os',
'ram' => 'ram',
'disk' => 'disk',
'main_ip' => 'main_ip',
'cpu_count' => 'cpu_count',
'region' => 'region',
'default_password' => 'default_password',
'date_created' => 'date_created',
'status' => 'status',
'netmask_v4' => 'netmask_v4',
'gateway_v4' => 'gateway_v4',
'plan' => 'plan',
'label' => 'label',
'tag' => 'tag',
'os_id' => 'os_id',
'app_id' => 'app_id',
'image_id' => 'image_id',
'v6_network' => 'v6_network',
'v6_main_ip' => 'v6_main_ip',
'v6_network_size' => 'v6_network_size',
'mac_address' => 'mac_address',
'tags' => 'tags'    ];

    /**
     * Array of attributes to setter functions (for deserialization of responses)
     *
     * @var string[]
     */
    protected static $setters = [
        'id' => 'setId',
'os' => 'setOs',
'ram' => 'setRam',
'disk' => 'setDisk',
'main_ip' => 'setMainIp',
'cpu_count' => 'setCpuCount',
'region' => 'setRegion',
'default_password' => 'setDefaultPassword',
'date_created' => 'setDateCreated',
'status' => 'setStatus',
'netmask_v4' => 'setNetmaskV4',
'gateway_v4' => 'setGatewayV4',
'plan' => 'setPlan',
'label' => 'setLabel',
'tag' => 'setTag',
'os_id' => 'setOsId',
'app_id' => 'setAppId',
'image_id' => 'setImageId',
'v6_network' => 'setV6Network',
'v6_main_ip' => 'setV6MainIp',
'v6_network_size' => 'setV6NetworkSize',
'mac_address' => 'setMacAddress',
'tags' => 'setTags'    ];

    /**
     * Array of attributes to getter functions (for serialization of requests)
     *
     * @var string[]
     */
    protected static $getters = [
        'id' => 'getId',
'os' => 'getOs',
'ram' => 'getRam',
'disk' => 'getDisk',
'main_ip' => 'getMainIp',
'cpu_count' => 'getCpuCount',
'region' => 'getRegion',
'default_password' => 'getDefaultPassword',
'date_created' => 'getDateCreated',
'status' => 'getStatus',
'netmask_v4' => 'getNetmaskV4',
'gateway_v4' => 'getGatewayV4',
'plan' => 'getPlan',
'label' => 'getLabel',
'tag' => 'getTag',
'os_id' => 'getOsId',
'app_id' => 'getAppId',
'image_id' => 'getImageId',
'v6_network' => 'getV6Network',
'v6_main_ip' => 'getV6MainIp',
'v6_network_size' => 'getV6NetworkSize',
'mac_address' => 'getMacAddress',
'tags' => 'getTags'    ];

    /**
     * Array of attributes where the key is the local name,
     * and the value is the original name
     *
     * @return array
     */
    public static function attributeMap()
    {
        return self::$attributeMap;
    }

    /**
     * Array of attributes to setter functions (for deserialization of responses)
     *
     * @return array
     */
    public static function setters()
    {
        return self::$setters;
    }

    /**
     * Array of attributes to getter functions (for serialization of requests)
     *
     * @return array
     */
    public static function getters()
    {
        return self::$getters;
    }

    /**
     * The original name of the model.
     *
     * @return string
     */
    public function getModelName()
    {
        return self::$swaggerModelName;
    }

    

    /**
     * Associative array for storing property values
     *
     * @var mixed[]
     */
    protected $container = [];

    /**
     * Constructor
     *
     * @param mixed[] $data Associated array of property values
     *                      initializing the model
     */
    public function __construct(array $data = null)
    {
        $this->container['id'] = isset($data['id']) ? $data['id'] : null;
        $this->container['os'] = isset($data['os']) ? $data['os'] : null;
        $this->container['ram'] = isset($data['ram']) ? $data['ram'] : null;
        $this->container['disk'] = isset($data['disk']) ? $data['disk'] : null;
        $this->container['main_ip'] = isset($data['main_ip']) ? $data['main_ip'] : null;
        $this->container['cpu_count'] = isset($data['cpu_count']) ? $data['cpu_count'] : null;
        $this->container['region'] = isset($data['region']) ? $data['region'] : null;
        $this->container['default_password'] = isset($data['default_password']) ? $data['default_password'] : null;
        $this->container['date_created'] = isset($data['date_created']) ? $data['date_created'] : null;
        $this->container['status'] = isset($data['status']) ? $data['status'] : null;
        $this->container['netmask_v4'] = isset($data['netmask_v4']) ? $data['netmask_v4'] : null;
        $this->container['gateway_v4'] = isset($data['gateway_v4']) ? $data['gateway_v4'] : null;
        $this->container['plan'] = isset($data['plan']) ? $data['plan'] : null;
        $this->container['label'] = isset($data['label']) ? $data['label'] : null;
        $this->container['tag'] = isset($data['tag']) ? $data['tag'] : null;
        $this->container['os_id'] = isset($data['os_id']) ? $data['os_id'] : null;
        $this->container['app_id'] = isset($data['app_id']) ? $data['app_id'] : null;
        $this->container['image_id'] = isset($data['image_id']) ? $data['image_id'] : null;
        $this->container['v6_network'] = isset($data['v6_network']) ? $data['v6_network'] : null;
        $this->container['v6_main_ip'] = isset($data['v6_main_ip']) ? $data['v6_main_ip'] : null;
        $this->container['v6_network_size'] = isset($data['v6_network_size']) ? $data['v6_network_size'] : null;
        $this->container['mac_address'] = isset($data['mac_address']) ? $data['mac_address'] : null;
        $this->container['tags'] = isset($data['tags']) ? $data['tags'] : null;
    }

    /**
     * Show all the invalid properties with reasons.
     *
     * @return array invalid properties with reasons
     */
    public function listInvalidProperties()
    {
        $invalidProperties = [];

        return $invalidProperties;
    }

    /**
     * Validate all the properties in the model
     * return true if all passed
     *
     * @return bool True if all properties are valid
     */
    public function valid()
    {
        return count($this->listInvalidProperties()) === 0;
    }


    /**
     * Gets id
     *
     * @return string
     */
    public function getId()
    {
        return $this->container['id'];
    }

    /**
     * Sets id
     *
     * @param string $id A unique ID for the Bare Metal instance.
     *
     * @return $this
     */
    public function setId($id)
    {
        $this->container['id'] = $id;

        return $this;
    }

    /**
     * Gets os
     *
     * @return string
     */
    public function getOs()
    {
        return $this->container['os'];
    }

    /**
     * Sets os
     *
     * @param string $os The [Operating System name](#operation/list-os).
     *
     * @return $this
     */
    public function setOs($os)
    {
        $this->container['os'] = $os;

        return $this;
    }

    /**
     * Gets ram
     *
     * @return string
     */
    public function getRam()
    {
        return $this->container['ram'];
    }

    /**
     * Sets ram
     *
     * @param string $ram Text description of the instances' RAM.
     *
     * @return $this
     */
    public function setRam($ram)
    {
        $this->container['ram'] = $ram;

        return $this;
    }

    /**
     * Gets disk
     *
     * @return string
     */
    public function getDisk()
    {
        return $this->container['disk'];
    }

    /**
     * Sets disk
     *
     * @param string $disk Text description of the instances' disk configuration.
     *
     * @return $this
     */
    public function setDisk($disk)
    {
        $this->container['disk'] = $disk;

        return $this;
    }

    /**
     * Gets main_ip
     *
     * @return string
     */
    public function getMainIp()
    {
        return $this->container['main_ip'];
    }

    /**
     * Sets main_ip
     *
     * @param string $main_ip The main IPv4 address.
     *
     * @return $this
     */
    public function setMainIp($main_ip)
    {
        $this->container['main_ip'] = $main_ip;

        return $this;
    }

    /**
     * Gets cpu_count
     *
     * @return int
     */
    public function getCpuCount()
    {
        return $this->container['cpu_count'];
    }

    /**
     * Sets cpu_count
     *
     * @param int $cpu_count Number of CPUs.
     *
     * @return $this
     */
    public function setCpuCount($cpu_count)
    {
        $this->container['cpu_count'] = $cpu_count;

        return $this;
    }

    /**
     * Gets region
     *
     * @return string
     */
    public function getRegion()
    {
        return $this->container['region'];
    }

    /**
     * Sets region
     *
     * @param string $region The [Region id](#operation/list-regions) where the instance is located.
     *
     * @return $this
     */
    public function setRegion($region)
    {
        $this->container['region'] = $region;

        return $this;
    }

    /**
     * Gets default_password
     *
     * @return string
     */
    public function getDefaultPassword()
    {
        return $this->container['default_password'];
    }

    /**
     * Sets default_password
     *
     * @param string $default_password The default password assigned at deployment.
     *
     * @return $this
     */
    public function setDefaultPassword($default_password)
    {
        $this->container['default_password'] = $default_password;

        return $this;
    }

    /**
     * Gets date_created
     *
     * @return string
     */
    public function getDateCreated()
    {
        return $this->container['date_created'];
    }

    /**
     * Sets date_created
     *
     * @param string $date_created The date this instance was created.
     *
     * @return $this
     */
    public function setDateCreated($date_created)
    {
        $this->container['date_created'] = $date_created;

        return $this;
    }

    /**
     * Gets status
     *
     * @return string
     */
    public function getStatus()
    {
        return $this->container['status'];
    }

    /**
     * Sets status
     *
     * @param string $status The current status.  * active * pending * suspended
     *
     * @return $this
     */
    public function setStatus($status)
    {
        $this->container['status'] = $status;

        return $this;
    }

    /**
     * Gets netmask_v4
     *
     * @return string
     */
    public function getNetmaskV4()
    {
        return $this->container['netmask_v4'];
    }

    /**
     * Sets netmask_v4
     *
     * @param string $netmask_v4 The IPv4 netmask in dot-decimal notation.
     *
     * @return $this
     */
    public function setNetmaskV4($netmask_v4)
    {
        $this->container['netmask_v4'] = $netmask_v4;

        return $this;
    }

    /**
     * Gets gateway_v4
     *
     * @return string
     */
    public function getGatewayV4()
    {
        return $this->container['gateway_v4'];
    }

    /**
     * Sets gateway_v4
     *
     * @param string $gateway_v4 The IPv4 gateway address.
     *
     * @return $this
     */
    public function setGatewayV4($gateway_v4)
    {
        $this->container['gateway_v4'] = $gateway_v4;

        return $this;
    }

    /**
     * Gets plan
     *
     * @return string
     */
    public function getPlan()
    {
        return $this->container['plan'];
    }

    /**
     * Sets plan
     *
     * @param string $plan The [Bare Metal Plan id](#operation/list-metal-plans) used by this instance.
     *
     * @return $this
     */
    public function setPlan($plan)
    {
        $this->container['plan'] = $plan;

        return $this;
    }

    /**
     * Gets label
     *
     * @return string
     */
    public function getLabel()
    {
        return $this->container['label'];
    }

    /**
     * Sets label
     *
     * @param string $label The user-supplied label for this instance.
     *
     * @return $this
     */
    public function setLabel($label)
    {
        $this->container['label'] = $label;

        return $this;
    }

    /**
     * Gets tag
     *
     * @return string
     */
    public function getTag()
    {
        return $this->container['tag'];
    }

    /**
     * Sets tag
     *
     * @param string $tag Use `tags` instead. The user-supplied tag for this instance.
     *
     * @return $this
     */
    public function setTag($tag)
    {
        $this->container['tag'] = $tag;

        return $this;
    }

    /**
     * Gets os_id
     *
     * @return int
     */
    public function getOsId()
    {
        return $this->container['os_id'];
    }

    /**
     * Sets os_id
     *
     * @param int $os_id The [Operating System id](#operation/list-os).
     *
     * @return $this
     */
    public function setOsId($os_id)
    {
        $this->container['os_id'] = $os_id;

        return $this;
    }

    /**
     * Gets app_id
     *
     * @return int
     */
    public function getAppId()
    {
        return $this->container['app_id'];
    }

    /**
     * Sets app_id
     *
     * @param int $app_id The [Application id](#operation/list-applications).
     *
     * @return $this
     */
    public function setAppId($app_id)
    {
        $this->container['app_id'] = $app_id;

        return $this;
    }

    /**
     * Gets image_id
     *
     * @return string
     */
    public function getImageId()
    {
        return $this->container['image_id'];
    }

    /**
     * Sets image_id
     *
     * @param string $image_id The [Application image_id](#operation/list-applications).
     *
     * @return $this
     */
    public function setImageId($image_id)
    {
        $this->container['image_id'] = $image_id;

        return $this;
    }

    /**
     * Gets v6_network
     *
     * @return string
     */
    public function getV6Network()
    {
        return $this->container['v6_network'];
    }

    /**
     * Sets v6_network
     *
     * @param string $v6_network The IPv6 network size in bits.
     *
     * @return $this
     */
    public function setV6Network($v6_network)
    {
        $this->container['v6_network'] = $v6_network;

        return $this;
    }

    /**
     * Gets v6_main_ip
     *
     * @return string
     */
    public function getV6MainIp()
    {
        return $this->container['v6_main_ip'];
    }

    /**
     * Sets v6_main_ip
     *
     * @param string $v6_main_ip The main IPv6 network address.
     *
     * @return $this
     */
    public function setV6MainIp($v6_main_ip)
    {
        $this->container['v6_main_ip'] = $v6_main_ip;

        return $this;
    }

    /**
     * Gets v6_network_size
     *
     * @return int
     */
    public function getV6NetworkSize()
    {
        return $this->container['v6_network_size'];
    }

    /**
     * Sets v6_network_size
     *
     * @param int $v6_network_size The IPv6 subnet.
     *
     * @return $this
     */
    public function setV6NetworkSize($v6_network_size)
    {
        $this->container['v6_network_size'] = $v6_network_size;

        return $this;
    }

    /**
     * Gets mac_address
     *
     * @return int
     */
    public function getMacAddress()
    {
        return $this->container['mac_address'];
    }

    /**
     * Sets mac_address
     *
     * @param int $mac_address The MAC address for a Bare Metal server
     *
     * @return $this
     */
    public function setMacAddress($mac_address)
    {
        $this->container['mac_address'] = $mac_address;

        return $this;
    }

    /**
     * Gets tags
     *
     * @return string[]
     */
    public function getTags()
    {
        return $this->container['tags'];
    }

    /**
     * Sets tags
     *
     * @param string[] $tags Tags to apply to the instance
     *
     * @return $this
     */
    public function setTags($tags)
    {
        $this->container['tags'] = $tags;

        return $this;
    }
    /**
     * Returns true if offset exists. False otherwise.
     *
     * @param integer $offset Offset
     *
     * @return boolean
     */
    public function offsetExists($offset)
    {
        return isset($this->container[$offset]);
    }

    /**
     * Gets offset.
     *
     * @param integer $offset Offset
     *
     * @return mixed
     */
    public function offsetGet($offset)
    {
        return isset($this->container[$offset]) ? $this->container[$offset] : null;
    }

    /**
     * Sets value based on offset.
     *
     * @param integer $offset Offset
     * @param mixed   $value  Value to be set
     *
     * @return void
     */
    public function offsetSet($offset, $value)
    {
        if (is_null($offset)) {
            $this->container[] = $value;
        } else {
            $this->container[$offset] = $value;
        }
    }

    /**
     * Unsets offset.
     *
     * @param integer $offset Offset
     *
     * @return void
     */
    public function offsetUnset($offset)
    {
        unset($this->container[$offset]);
    }

    /**
     * Gets the string presentation of the object
     *
     * @return string
     */
    public function __toString()
    {
        if (defined('JSON_PRETTY_PRINT')) { // use JSON pretty print
            return json_encode(
                ObjectSerializer::sanitizeForSerialization($this),
                JSON_PRETTY_PRINT
            );
        }

        return json_encode(ObjectSerializer::sanitizeForSerialization($this));
    }
}
