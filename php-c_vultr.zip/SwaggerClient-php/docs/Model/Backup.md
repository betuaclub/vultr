# Backup

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **string** | A unique ID for the backup. | [optional] 
**date_created** | **string** | The date the backup was created. | [optional] 
**description** | **string** | The user-supplied description of this backup. | [optional] 
**size** | **int** | The size of the backup in Bytes. | [optional] 
**status** | **string** | The Backup status.  * complete * pending | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

