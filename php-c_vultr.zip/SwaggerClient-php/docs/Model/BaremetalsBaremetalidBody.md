# BaremetalsBaremetalidBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**user_data** | **string** | The user-supplied, base64 encoded [user data](https://www.vultr.com/docs/manage-instance-user-data-with-the-vultr-metadata-api/) to attach to this instance. | [optional] 
**label** | **string** | The user-supplied label. | [optional] 
**tag** | **string** | Use &#x60;tags&#x60; instead. The user-supplied tag. | [optional] 
**os_id** | **int** | If supplied, reinstall the instance using this [Operating System id](#operation/list-os). | [optional] 
**app_id** | **int** | If supplied, reinstall the instance using this [Application id](#operation/list-applications). | [optional] 
**image_id** | **string** | If supplied, reinstall the instance using this [Application image_id](#operation/list-applications). | [optional] 
**enable_ipv6** | **bool** | Enable IPv6.  * true * false | [optional] 
**tags** | **string[]** | Tags to apply to the instance | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

