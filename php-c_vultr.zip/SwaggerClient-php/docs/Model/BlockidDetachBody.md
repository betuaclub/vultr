# BlockidDetachBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**live** | **bool** | Detach Block Storage without restarting the Instance.  |   | Value | Description | | - | ----- | ----------- | |   | true | Detach live, do not restart the instance. | |   | false | Restart the instance and detach the Block Storage. | | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

