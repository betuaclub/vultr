# BlocksBlockidBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**label** | **string** | The user-supplied label. | [optional] 
**size_gb** | **int** | New size of the Block Storage in GB. Size may range between 10 and 40000 depending on the &#x60;block_type&#x60;. | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

