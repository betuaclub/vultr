# Blockstorage

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **string** | A unique ID for the Block Storage. | [optional] 
**cost** | **int** | The monthly cost of this Block Storage. | [optional] 
**status** | **string** | The current status of this Block Storage.  * active | [optional] 
**size_gb** | **int** | Size of the Block Storage in GB. | [optional] 
**region** | **string** | The [Region id](#operation/list-regions) where the Block Storage is located. | [optional] 
**attached_to_instance** | **string** | The [Instance id](#operation/list-instances) with this Block Storage attached. | [optional] 
**date_created** | **string** | The date this Block Storage was created. | [optional] 
**label** | **string** | The user-supplied label. | [optional] 
**mount_id** | **string** | An ID associated with the instance, when mounted the ID can be found in /dev/disk/by-id prefixed with virtio. | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

