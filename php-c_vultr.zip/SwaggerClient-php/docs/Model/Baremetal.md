# Baremetal

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **string** | A unique ID for the Bare Metal instance. | [optional] 
**os** | **string** | The [Operating System name](#operation/list-os). | [optional] 
**ram** | **string** | Text description of the instances&#x27; RAM. | [optional] 
**disk** | **string** | Text description of the instances&#x27; disk configuration. | [optional] 
**main_ip** | **string** | The main IPv4 address. | [optional] 
**cpu_count** | **int** | Number of CPUs. | [optional] 
**region** | **string** | The [Region id](#operation/list-regions) where the instance is located. | [optional] 
**default_password** | **string** | The default password assigned at deployment. | [optional] 
**date_created** | **string** | The date this instance was created. | [optional] 
**status** | **string** | The current status.  * active * pending * suspended | [optional] 
**netmask_v4** | **string** | The IPv4 netmask in dot-decimal notation. | [optional] 
**gateway_v4** | **string** | The IPv4 gateway address. | [optional] 
**plan** | **string** | The [Bare Metal Plan id](#operation/list-metal-plans) used by this instance. | [optional] 
**label** | **string** | The user-supplied label for this instance. | [optional] 
**tag** | **string** | Use &#x60;tags&#x60; instead. The user-supplied tag for this instance. | [optional] 
**os_id** | **int** | The [Operating System id](#operation/list-os). | [optional] 
**app_id** | **int** | The [Application id](#operation/list-applications). | [optional] 
**image_id** | **string** | The [Application image_id](#operation/list-applications). | [optional] 
**v6_network** | **string** | The IPv6 network size in bits. | [optional] 
**v6_main_ip** | **string** | The main IPv6 network address. | [optional] 
**v6_network_size** | **int** | The IPv6 subnet. | [optional] 
**mac_address** | **int** | The MAC address for a Bare Metal server | [optional] 
**tags** | **string[]** | Tags to apply to the instance | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

