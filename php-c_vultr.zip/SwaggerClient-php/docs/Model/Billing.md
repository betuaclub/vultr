# Billing

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **float** | ID of the billing history item | [optional] 
**date** | **string** | Date billing history item was generated | [optional] 
**type** | **string** | Type of billing history item | [optional] 
**description** | **string** | Description of billing history item | [optional] 
**amount** | **float** | Amount for the billing history item in dollars | [optional] 
**balance** | **float** | The accounts balance in dollars | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

