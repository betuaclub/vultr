# Account

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** | Your user name. | [optional] 
**email** | **string** | Your email address. | [optional] 
**acls** | **string[]** | An array of permission granted. * manage\\_users * subscriptions_view * subscriptions * billing * support * provisioning * dns * abuse * upgrade * firewall * alerts * objstore * loadbalancer | [optional] 
**balance** | **float** | Your current account balance. | [optional] 
**pending_charges** | **float** | Unbilled charges for this month. | [optional] 
**last_payment_date** | **string** | Date of your last payment. | [optional] 
**last_payment_amount** | **float** | The amount of your last payment. | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

