# BaremetalsBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**region** | **string** | The [Region id](#operation/list-regions) to create the instance. | 
**plan** | **string** | The [Bare Metal plan id](#operation/list-metal-plans) to use for this instance. | 
**script_id** | **string** | The [Startup Script id](#operation/list-startup-scripts) to use for this instance. | [optional] 
**enable_ipv6** | **bool** | Enable IPv6.  * true * false | [optional] 
**sshkey_id** | **string[]** | The [SSH Key id](#operation/list-ssh-keys) to install on this instance. | [optional] 
**user_data** | **string** | The user-supplied, base64 encoded [user data](https://www.vultr.com/docs/manage-instance-user-data-with-the-vultr-metadata-api/) for this Instance. | [optional] 
**label** | **string** | The user-supplied label. | [optional] 
**activation_email** | **bool** | Notify by email after deployment.  * true * false (default) | [optional] 
**hostname** | **string** | The user-supplied hostname to use when deploying this instance. | [optional] 
**tag** | **string** | Use &#x60;tags&#x60; instead. The user-supplied tag. | [optional] 
**reserved_ipv4** | **string** | The [Reserved IP id](#operation/list-reserved-ips) for this instance. | [optional] 
**os_id** | **int** | If supplied, deploy the instance using this [Operating System id](#operation/list-os). | [optional] 
**snapshot_id** | **string** | If supplied, deploy the instance using this [Snapshot ID](#operation/list-snapshots). | [optional] 
**app_id** | **int** | If supplied, deploy the instance using this [Application id](#operation/list-applications). | [optional] 
**image_id** | **string** | If supplied, deploy the instance using this [Application image_id](#operation/list-applications). | [optional] 
**persistent_pxe** | **bool** | Enable persistent PXE.  * true * false (default) | [optional] 
**tags** | **string[]** | Tags to apply to the instance | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

