# BaremetalIpv6

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ip** | **string** | A unique ID for the IPv6 address. | [optional] 
**network** | **string** | The IPv6 subnet. | [optional] 
**network_size** | **int** | The IPv6 network size in bits. | [optional] 
**type** | **string** | The type of IP address.  * main_ip | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

