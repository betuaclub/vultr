# Application

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | A unique ID for the application. | [optional] 
**name** | **string** | The application name. | [optional] 
**short_name** | **string** | The short application name. | [optional] 
**deploy_name** | **string** | A long description of the application. | [optional] 
**type** | **string** | The type of application.  * one-click - use app_id to deploy one-click applications. * marketplace - use image_id to deploy marketplace applications. | [optional] 
**vendor** | **string** | The application vendor name. | [optional] 
**image_id** | **string** | A unique ID for marketplace applications. | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

