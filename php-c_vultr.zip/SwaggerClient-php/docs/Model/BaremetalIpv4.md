# BaremetalIpv4

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ip** | **string** | The IPv4 address. | [optional] 
**netmask** | **string** | The IPv4 netmask in dot-decimal notation. | [optional] 
**gateway** | **string** | The gateway IP address. | [optional] 
**type** | **string** | The type of IP address.  * main_ip | [optional] 
**reverse** | **string** | The reverse DNS information for this IP address. | [optional] 
**mac_address** | **string** | The MAC address associated with this IP address. | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

